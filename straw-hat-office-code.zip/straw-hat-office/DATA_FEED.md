# Pixel Office: data feeds

The office reads the public Google Sheet `125TloDi-xWce5NyGbKupJELfDkSGgJnguE3MZJepa_U` through gviz JSONP, which works from `file://`. It refreshes every 3 minutes (`CONFIG.refreshMinutes`).
If the sheet can't be reached, it falls back to the snapshot embedded at build time (`snapshot.json`).

**Tab names and headers must match exactly** (case-insensitive headers, no extra spaces). gviz returns the *first* tab when a tab name doesn't exist, so the page validates every tab by its required headers and ignores it if they are missing.

Missing optional tabs are fine. The page shows "tab not found" and uses local or derived data instead. It never makes up values.

## Existing tabs (in use)

| Tab | Columns used | Drives |
|---|---|---|
| `OCTOBER 2026 PURCHASES` (first tab) | A store, B product, C quantity, D total BRL (Taberna Geek entered at its negotiated R$44,500), the first column whose header contains `date`/`data` (now L `PURCHASE DATE`, dd/mm/yyyy); F–J summary block (no longer used for US$: since v4.1 every US$ figure is R$ ÷ 5.14, the funders' partner rate, fixed in `CONFIG.brlPerUsd`) | **The single number source (v3.1)**: current pallet = lines dated on/after `CONFIG.palletStartDate` (2026-10-08; undated lines are kept and flagged). Items, purchase lines, stores, spend, ≈USD, commission (5%), cargo hold and the header pallet line all use these same lines |
| `OCTOBER 2026 SHIPPING` | `ORDER #`, `ORDER DATE`, `STORE`, `PRODUCT`, `QUANTITY`, `ORDER TOTAL BRL`, `SHIPPED BY STORE (Y/N)`, `CARRIER`, `TRACKING CODE`, `ESTIMATED DELIVERY`, `RECEIVED IN SP (Y/N)`, `SEALED & UNDAMAGED (Y/N)`, `PALLET #`, `STATUS` | Treasure-map stages, the small "on pallet: N items" count (non-cancelled rows with `PALLET #` filled; the cargo-hold crate stack draws one crate per such order, max 9), the "Pallet shipped" achievement. It no longer drives the main pallet numbers |
| `OCTOBER 2026 EXPENSES` | (not used by the office yet) | – |

**Treasure-map stages** come from SHIPPING. Each row gets the first stage that matches:

1. `cancelled`: STATUS contains "cancel".
2. `us`: STATUS says "US warehouse" or "arrived in/at US".
3. `pallet`: PALLET # is filled.
4. `storage`: RECEIVED IN SP = Y.
5. `delivered_unmatched`: an UNMATCHED row whose STATUS says delivered.
6. `transit`: SHIPPED BY STORE = Y.
7. `unpaid`: STATUS contains "awaiting payment".
8. `store`: everything else.

## Hosted mode: crew tabs from /crew.json (v3.2)
When the page is served over **https** (the Access-locked site straw-hat-office.pages.dev), the crew tabs
(CREW STATUS, JOBS, SUMMARIES, BRIEFING, NEWS, BRAINSTORMS, plus CREW CHAT) are read from `/crew.json`
on every refresh (every 3 min) instead of gviz. `/crew.json` is synced every ~10 min from the PRIVATE sheet
"Straw Hat Crew Board" (`10DeM9dRNrlM96pbdDC7Z1EKDVBbnFqgWQLjWrS0Eb6I`) into Cloudflare KV (see DEPLOY.md, "Crew sync").
Shape: `{synced_at: ISO -03:00, tabs: {CREW_STATUS: [{crew_id,...}], JOBS: [...], ..., CREW_CHAT: [{time,from,to,message,event_ref,kind}]}}`.
The live pill adds `· CREW SYNCED HH:MM BRT`. CREW CHAT rows land in `FEEDS.chat`. The crew chat was removed in v4.1 (owner), so no UI uses them. RELEASES and PALLET are optional tabs that are synced only.
On `file://`, or if `/crew.json` fails (offline, Access session expired, bad JSON), each tab falls back to the old
gviz path exactly as before. The tracker tabs (PURCHASES/SHIPPING) are always read from gviz, unchanged.

## Optional tabs (create them to unlock live features)

### `CREW STATUS`: one row per crew member
| column | example | notes |
|---|---|---|
| `crew_id` | `chopper` | required: luffy, nami, zoro, usopp, sanji, chopper, robin, brook, jinbe, frankie, law |
| `status` | `Watching Liga for deals` | the plain "Doing now" line in the crew status panel and the bubble. Blank -> the state word (Working, Resting, …) |
| `state` | `working` / `idle` / `resting` | the only source of the shown state (dot + word next to each face). Blank or anything else shows as **Resting**; the app never invents one |
| `decision` | `Approve 2 OP17 cases at R$11,200?` | **blank = no decision needed; text = the question.** Non-blank puts the bot under **Needs your decision** at the top of the crew status panel, flags it, and rings its Den Den Mushi until read |
| `event_type` | `deal_found` | chopper `deal_found`, usopp `release_found`, robin `margin_report`, nami `growth_idea`, zoro `shipment_update`, jinbe `books_updated`, sanji `supplier_deal`, brook `community_pulse`, luffy `summary_sent`, frankie `ui_shipped`, law `qa_report` |
| `event_id` | `2026-10-20-01` | **change it to fire the animation once**. The same id never replays. Every new id counts as a real delivery (weekly MVP, "10 deals under average") |
| `event_at` | `2026-10-20 10:15` | optional. Accepted: ISO with a zone (`2026-10-20T10:15:00-03:00`), `YYYY-MM-DD HH:MM` or `DD/MM/YYYY HH:MM` (both read as **São Paulo time, -03:00**, whatever the viewer's time zone). An unreadable value shows "time unknown" and never breaks the log |
| `event_text` | `OP17 case 22% below avg` | shown in the bubble and log |
| `discount` | `22` | % below average. A `deal_found` with discount ≥ `CONFIG.bigDealPct` (15) fires fireworks and Chopper runs to Luffy. If empty, a "NN%" in event_text is used for the fireworks only. **The TOP DEAL chip on the money card needs a numeric `discount` > 0** (and `event_at`/`updated_at` less than 24 h old); a deal with only "22% below avg" in its text never reaches the chip. Prices in event_text may be written `R$ 1.234,56` or `R$1,234.56` |
| `updated_at` | `2026-10-20 10:15` | used as the event time when `event_at` is blank |

### `JOBS`: bounty board scrolls
`job_id`, `posted_at`, `task`, `assignee` (crew_id), `status` (posted/accepted/doing/done/cancelled), `result`, `result_link` (http/https only).
A new job_id that isn't done or cancelled sends the assignee to the notice board. Jobs posted inside the page live in this browser's localStorage only.

### `SUMMARIES`: Friday summary replay
`date`, `text`. The newest row is replayed by Luffy at the mast after the Friday morning meeting, or from EVENTS & PREVIEWS. Sentences become bubbles.

### `BRIEFING`: morning meeting plan
`date`, `line`. One row per bubble. The meeting uses today's rows, or the latest date if today has none.
Without this tab (or `briefing` in status.json), Luffy reads out the crew's current statuses.

### `NEWS`: message in a bottle
`headline` (required), `source`, `link`, `date`. Bottles only appear when this tab has rows. Headlines are shown exactly as written.


### BRAINSTORMS (optional, new)
Columns: `session_id`, `time`, `speaker`, `message`, `idea`, `sources` (the first three are required, or the tab is ignored; `sources`, added in v4.2, is kept on each line but not shown yet).
- Rows are grouped by `session_id`. Each row is a line the speaker says in the break room. A non-empty `idea` adds a sticky note to the idea board.
- Without rows in this tab the board says "No brainstorms yet" (v4.1: the example sessions were removed).
- Upvotes are saved only on this device, in localStorage (`pixelOffice.votes` / `pixelOffice.myvotes`).
- A crew member counts as ON BREAK when their CREW STATUS `state` is anything other than `working`. They walk to the break room, and once two or more crew are there they talk through a session.

## Local-only and simulated data (labelled in the UI)
* **Energy/mood** is simulated. It drains while working and recovers resting on the lawn or eating at meal times (08:00, 12:00, 19:00 BRT).
* **Friendship** is local. It grows from meetings, brainstorms (crew idling next to each other) and banter combos.
* **Jobs posted in-page, read decisions, event history, weekly MVP** are stored in localStorage under keys prefixed `pixelOffice.`.
* **Seasonal decor** follows the São Paulo month (Oct Halloween, Dec Christmas, Feb Carnival, Jun Festa Junina). You can override it in EVENTS & PREVIEWS.
* **Schedules**: morning meeting at 09:00 BRT on weekdays; Friday MVP ceremony after 16:00 BRT, only if real deliveries were logged that week; rare sea events at random, about one every 10 min.

- **Day/night** follows São Paulo time: dark 20:00–05:00, dawn 05–07, dusk 17:30–20:00. You can override it under EVENTS & PREVIEWS → TIME OF DAY; overrides are labelled "(preview)".
- **Weather** is the live current weather for São Paulo from Open-Meteo (no key), refreshed every 15 min. Overrides are under EVENTS & PREVIEWS → WEATHER and are labelled "(preview)".
- **Treasure vault**: the gold pile in the cargo hold scales with the real 5% commission. When the order count from the SHIPPING tab goes up, the new row plays its arrival: coins fall in, Zoro stows the crate, the crew cheer and a toast shows the real row. REPLAY LAST PURCHASE replays the latest real row without logging anything.
- **Break preview**: "Send 4 crew on break (preview)" only changes their state in the browser. It is not data.


## Removed in v3.1 (owner decisions, 2026-10-18)
* **Pallet goal** (the 500-item placeholder, progress bar and goal-scaled crates). The header shows plain numbers: `since 8 Oct: N items · R$ X · ≈US$ Y`, plus `on pallet: N items`.
* **Mini-games** (fishing, treasure diving, Usopp's cannon, card packs, break-room quiz). The source is archived in `archive_minigames/`. Old `pixelOffice.best.*`, `fish*`, `cards`, `packs.*` keys stay in localStorage, but nothing reads them.
* **Ship upgrades** (lanterns, pennants, gold sail trim, the lion's golden crown, observation deck). They were computed live and never stored, so there are no keys to clean up. The lion figurehead itself is now part of the base ship art.
* **Wanted posters** (per-crew bounty posters and `CONFIG.bountyPerDelivery`). The side panel that used to say "WANTED" is now **CREW COMMISSION** and shows the same 5% figure.
