# Extra v3 features requested by the user (ADD ALL)
Also see the per-character signature event animations message (deal_found, release_found, margin_report, growth_idea, shipment_update, books_updated, supplier_deal, community_pulse, summary_sent) with a preview button in each panel.

## Productive
- Bounty board for jobs: user posts a task in-page (stored localStorage + shown); crew member assigned walks to station; results shown as scrolls. Also read optional sheet tab 'JOBS' (job_id, posted_at, task, assignee, status, result, result_link).
- Den Den Mushi on each desk rings (animation + optional sound) when that crew member has a pending decision for the boss (CREW STATUS state = needs_decision); click to read it.
- Morning crew meeting at the mast (~9am SP time) with Luffy's plan in bubbles (from CREW STATUS/briefing data); Friday summary replay as captain's speech (sheet tab 'SUMMARIES': date, text).
- Treasure map panel: São Paulo Liga stores -> storage -> US warehouse with moving ship icons driven by Zoro's 'OCTOBER 2026 SHIPPING' tab statuses (read if available).
- Price-alert fireworks over ship when a deal event marks big discount; Chopper runs to Luffy.

## Life and personality
- Mood/energy meter per crew; busy crew tire, rest in break room; Sanji serves meals at SP meal times.
- Friendship levels grow from brainstorm co-attendance; special banter and combo animations (Zoro vs Sanji bickering, Luffy+Usopp goofing).
- Rare random events: Sea King passes, storm, Marine ship on horizon, message in a bottle carrying a real TCG news headline from Brook's feed (no invented news; skip if none).
- Seasonal outfits/decor (Halloween in Oct, Christmas Dec, etc.).

## Rewards and progress
- Wanted posters per crew member with bounty growing from real deliveries (count of events per crew).
- Ship upgrades unlocked by real milestones (e.g. commission R$15k new sail; pallet shipped new room).
- Achievements + trophy shelf (First R$10k, Pallet shipped, 10 deals under average...).
- Weekly MVP crowned Friday from real event counts, little deck ceremony.

## Mini-games
- Fishing (already planned), treasure diving, Usopp cannon target practice.
- Virtual card-pack opening: one pack per real new purchase (fun collectables, original art).
- Break-room crew quiz: trivia from the user's real tracker numbers.

Document every feed tab in DATA_FEED.md. Never invent business data; label examples clearly.
