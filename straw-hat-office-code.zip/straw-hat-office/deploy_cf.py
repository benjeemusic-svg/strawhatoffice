#!/usr/bin/env python3
"""Generate the Cloudflare connector code that deploys a single HTML file to
Cloudflare Pages project 'straw-hat-office' (protected by Cloudflare Access).

Usage:
  python3 deploy_cf.py                       # production (main), ./index.html
  python3 deploy_cf.py --branch preview      # preview deployment
  python3 deploy_cf.py --file deploy/placeholder.html

It writes deploy/execute_code.js. Then call the Cloudflare connector:
  CallDynamicTool namespace=user-Cloudflare toolName=execute
    arguments={"account_id": "4018a531e6c8218f03593e05f7c9b596",
               "code": "$file:/workspace/pixel-office/deploy/execute_code.js"}

KV: the Pages project has KV namespace 'straw-hat-crew'
(38a00144cc3d4956907ec52f9e89e330) bound as CREW in production + preview
(project deployment_configs). The worker serves GET /crew.json from KV key 'crew'.

How it works: the page is embedded in a Pages advanced-mode `_worker.js`
(empty static-asset manifest), uploaded in one multipart request to
POST /accounts/{id}/pages/projects/straw-hat-office/deployments. This avoids
the separate asset-upload JWT step, which the connector sandbox can't do.
"""
import argparse, hashlib, json, os, sys

HERE = os.path.dirname(os.path.abspath(__file__))
ACCOUNT_ID = "4018a531e6c8218f03593e05f7c9b596"
PROJECT = "straw-hat-office"

ap = argparse.ArgumentParser()
ap.add_argument("--file", default=os.path.join(HERE, "index.html"))
ap.add_argument("--branch", default="main", help="main = production; anything else = preview")
ap.add_argument("--message", default=None)
a = ap.parse_args()

html = open(a.file, encoding="utf-8").read()
if 'name="robots"' not in html and "name=robots" not in html:
    html = html.replace("<head>", '<head><meta name="robots" content="noindex,nofollow">', 1)
digest = hashlib.sha256(html.encode()).hexdigest()[:12]
size = len(html.encode())
if size > 20 * 1024 * 1024:
    sys.exit("HTML too large for a single worker (%d bytes)" % size)

worker = (
    "const HTML = " + json.dumps(html) + ";\n"
    "const H = {'content-type':'text/html; charset=utf-8','cache-control':'no-cache',"
    "'x-robots-tag':'noindex, nofollow','x-content-type-options':'nosniff','referrer-policy':'no-referrer'};\n"
    "export default { async fetch(req, env) {\n"
    "  const u = new URL(req.url);\n"
    "  if (u.pathname === '/crew.json') {\n"
    "    const J = {'content-type':'application/json; charset=utf-8','cache-control':'no-store','x-robots-tag':'noindex, nofollow','x-content-type-options':'nosniff'};\n"
    "    if (!env || !env.CREW) return new Response('{\"error\":\"kv_not_bound\"}', {status:503, headers:J});\n"
    "    const v = await env.CREW.get('crew');\n"
    "    if (v === null) return new Response('{\"error\":\"not_synced\"}', {status:404, headers:J});\n"
    "    return new Response(req.method === 'HEAD' ? null : v, {headers:J});\n"
    "  }\n"
    "  if (u.pathname === '/robots.txt') return new Response('User-agent: *\\nDisallow: /\\n', {headers:{'content-type':'text/plain'}});\n"
    "  if (u.pathname === '/favicon.ico') return new Response(null, {status:204});\n"
    "  return new Response(req.method === 'HEAD' ? null : HTML, {headers: H});\n"
    "} };\n"
)

msg = a.message or "deploy %s (%s, sha %s)" % (os.path.basename(a.file), a.branch, digest)
code = """async () => {
  const worker = %s;
  const fields = { manifest: '{}', branch: %s, commit_message: %s, commit_dirty: 'true' };
  const b = 'SHO' + Date.now();
  const parts = [];
  for (const [k, v] of Object.entries(fields)) parts.push(`--${b}\\r\\nContent-Disposition: form-data; name="${k}"\\r\\n\\r\\n${v}\\r\\n`);
  parts.push(`--${b}\\r\\nContent-Disposition: form-data; name="_worker.js"; filename="_worker.js"\\r\\nContent-Type: application/javascript+module\\r\\n\\r\\n${worker}\\r\\n`);
  parts.push(`--${b}--\\r\\n`);
  const r = await cloudflare.request({ method: 'POST', path: `/accounts/%s/pages/projects/%s/deployments`,
    body: parts.join(''), contentType: `multipart/form-data; boundary=${b}`, rawBody: true });
  const d = r.result || {};
  return { success: r.success, errors: r.errors, id: d.id, url: d.url, environment: d.environment,
           aliases: d.aliases, stage: d.latest_stage, sha: %s };
}""" % (json.dumps(worker), json.dumps(a.branch), json.dumps(msg), ACCOUNT_ID, PROJECT, json.dumps(digest))

out = os.path.join(HERE, "deploy", "execute_code.js")
os.makedirs(os.path.dirname(out), exist_ok=True)
open(out, "w", encoding="utf-8").write(code)
print("wrote %s (%d bytes) for %s -> branch %s, html sha %s" % (out, len(code), a.file, a.branch, digest))
