#!/usr/bin/env python3
"""v4.2 MARGINS tab icon, drawn in-house on the 32-colour v4 palette (STYLE-GUIDE.md): 16x16 art px, light from the top-left,
sel-out (top/left = the material's own dark tone, bottom/right = ink), shown at 2x (32x32) like the other hud.png tab icons.
Three rising bars in the health-light colours (red, gold, green) on an ink baseline.   python3 tools/v42_icon.py"""
from PIL import Image
import os
P={'ink':(0x2b,0x1d,0x18),'red':(0xb8,0x34,0x2f),'redD':(0x7a,0x25,0x23),'gold':(0xe9,0xb8,0x4c),'goldD':(0xa7,0x7a,0x2e),
   'green':(0x58,0x7a,0x43),'greenD':(0x34,0x50,0x2f),'greenL':(0x8b,0xa4,0x5f),'cream':(0xf1,0xe2,0xbb),'woodD':(0x4b,0x32,0x26),'orange':(0xd2,0x7a,0x3c),'tan':(0xdc,0xb9,0x87)}
im=Image.new('RGBA',(16,16),(0,0,0,0)); px=im.load()
def put(x,y,c): px[x,y]=P[c]+(255,)
def bar(x0,x1,top,base,hi,dark):
    for x in range(x0,x1+1):
        for y in range(top,14):
            edge_tl = x==x0 or y==top; edge_br = x==x1
            put(x,y,'ink' if edge_br else dark if edge_tl else (hi if x==x0+1 else base))
bar(1,4,9,'red','orange','redD')      # short red bar
bar(6,9,6,'gold','cream','goldD')    # middle gold bar
bar(11,14,2,'green','greenL','greenD')  # tall green bar
for x in range(0,16): put(x,14,'ink')    # baseline
for x in range(1,16): put(x,15,'woodD')  # soft shadow under the baseline (+1 px)
out=os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),'art','v42')
im.save(os.path.join(out,'icon-margins16.png')); im.resize((32,32),Image.NEAREST).save(os.path.join(out,'icon-margins32.png'))
im.resize((160,160),Image.NEAREST).save('/tmp/icon-margins-preview.png'); print('ok')
