"""v4.3 owner 23:19: remove every baked room plaque/sign from ship_<phase>.png and repaint the spot with the
surrounding wall (the plank/tile pattern beside the sign, copied at the same phase), never an empty gap.
The sign rectangles and the copy map are found once on ship_day and applied to all four phases (same geometry).
Run from the original art: tools/strip_plaques.py <orig_world_dir>  (writes art/v4/world/ship_<phase>.png and glow_<phase>.png)."""
import json,os,sys
from PIL import Image
os.chdir(os.path.join(os.path.dirname(os.path.abspath(__file__)),'..'))
SRC=sys.argv[1] if len(sys.argv)>1 else 'art/v4/world'
S=json.load(open('art/v4/world/spots.json')); MID=201
lum=lambda c:.3*c[0]+.59*c[1]+.11*c[2]
day=Image.open(f'{SRC}/ship_day.png').convert('RGB'); px=day.load(); W,H=day.size
def bbox(cx,cy):
  # the sign face = the bright pixels 4-connected to the plaque centre (the dark border stops the fill; text is enclosed)
  x0,y0,x1,y1=max(0,cx-40),max(0,cy-12),min(W,cx+40),min(H,cy+12)
  mx=max(lum(px[x,y]) for x in range(cx-6,cx+7) for y in range(cy-6,cy+7)); th=mx*.78
  def comp(seed):
    seen={seed};st=[seed]
    while st:
      x,y=st.pop()
      for n in ((x+1,y),(x-1,y),(x,y+1),(x,y-1)):
        if n not in seen and x0<=n[0]<x1 and y0<=n[1]<y1 and lum(px[n])>=th: seen.add(n);st.append(n)
    return seen
  comps=[];done=set()
  for y in range(cy-6,cy+7):
    for x in range(x0,x1):
      if (x,y) not in done and lum(px[x,y])>=th:
        c=comp((x,y));done|=c;comps.append(c)
  bb=lambda c:(min(q[0] for q in c),min(q[1] for q in c),max(q[0] for q in c),max(q[1] for q in c))
  near=[c for c in comps if len(c)>=20 and bb(c)[0]-3<=cx<=bb(c)[2]+3] or comps
  A,T,B,U=bb(max(near,key=len))
  grown=True   # letters that run from the top to the bottom edge split a short face (LIBRARY, CARGO) into pieces: chain them
  while grown:
    grown=False
    for c in comps:
      a,t,b,u=bb(c)
      if t>=T-1 and u<=U+1 and len(c)>=6 and (A-3<=b<A or B<a<=B+3):
        A,B=min(A,a),max(B,b);grown=True;comps.remove(c);break
  xs=[A,B];ys=[T,U]
  return min(xs)-1,min(ys)-1,max(xs)+2,max(ys)+3   # border, 1px right shade, 2px drop shadow
def side_map(y,a,b,side,L=10):
  edge=a-1 if side<0 else b+1
  st=[px[edge+side*k,y] for k in range(L) if 0<=edge+side*k<W]
  best=(-1,1)
  for p in range(1,9):
    ok=sum(st[k]==st[k+p] for k in range(len(st)-p))/(len(st)-p)
    if ok>best[0]+1e-9: best=(ok,p)
  ok,p=best
  return ok,{(x,y):((edge+((x-edge)%p)) if side>0 else (edge-((edge-x)%p)),y) for x in range(a,b+1)}
def dark(c): return lum(c)<70 and c[2]>c[0]   # the blue-black door transoms beside the signs
MAP={}
RECTS=[]
for P in S['plaques']:
  a,t,b,u=bbox(P['x'],P['y']); RECTS.append((P['text'],a,t,b,u))
  far=-1 if P['x']<MID else 1
  for y in range(t,u+1):
    okf,mf=side_map(y,a,b,far); okn,mn=side_map(y,a,b,-far)
    nearDark=dark(px[(b+1) if far<0 else (a-1),y])
    MAP.update(mf if (okf>=.8 or nearDark or okf>=okn) else mn)
for lay,ph in [('ship',p) for p in ('day','dusk','night','storm')]+[('glow',p) for p in ('dusk','night','storm')]:
  # glow_<phase> holds a lit copy of the LOUNGE sign under the aquarium light: same copy map, so the lit wall continues
  if not os.path.exists(f'{SRC}/{lay}_{ph}.png'): continue
  im=Image.open(f'{SRC}/{lay}_{ph}.png').convert('RGBA'); q=im.load(); orig=im.copy().load()
  for (x,y),s in MAP.items(): q[x,y]=orig[s]
  cols=im.getcolors(256)
  if cols:  # keep the original small indexed PNG (exact palette, no dithering)
    pal=[c for _,c in cols];idx={c:i for i,c in enumerate(pal)};out=Image.new('P',im.size);out.putdata([idx[c] for c in im.getdata()])
    out.putpalette([v for c in pal for v in c[:3]]);out.info['transparency']=bytes(c[3] for c in pal);out.save(f'art/v4/world/{lay}_{ph}.png',optimize=True,transparency=bytes(c[3] for c in pal))
  else: im.save(f'art/v4/world/{lay}_{ph}.png',optimize=True)
json.dump([{'text':r[0],'x':r[1],'y':r[2],'w':r[3]-r[1]+1,'h':r[4]-r[2]+1} for r in RECTS],open('art/v4/world/plaques-removed.json','w'))
print(len(RECTS),'plaques,',len(MAP),'px repainted per phase')
