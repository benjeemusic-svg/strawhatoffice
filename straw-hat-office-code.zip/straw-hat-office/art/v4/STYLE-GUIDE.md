# Pixel Office — v4 Style Guide (official, owner-approved)

**Reference:** Stardew warmth + One Piece anime colours. Polished, never childish.

## Palette — one fixed 32-colour palette
Base families: warm wood browns, cream parchment, sea teal, deep navy.
**Straw Hat red (`red` #b8342f) and gold (`gold` #e9b84c) are the ONLY accents**, reserved for money, alerts and highlights.
(Character signature outfits, e.g. Luffy's red vest and Law's yellow hoodie, use those same entries; UI never uses them decoratively.)
Lighting/time/weather never add colours: they remap through the `DARK`/`LIGHT` lookup tables (`tools/v4/pal.py`) or a runtime global tint.

| # | name | hex |
|---|---|---|
| 0 | `ink` | #2b1d18 |
| 1 | `woodD` | #4b3226 |
| 2 | `wood` | #6e4b34 |
| 3 | `woodM` | #946b47 |
| 4 | `woodL` | #b98f5f |
| 5 | `tan` | #dcb987 |
| 6 | `cream` | #f1e2bb |
| 7 | `parch` | #dcc596 |
| 8 | `parchS` | #b59c72 |
| 9 | `navyD` | #142636 |
| 10 | `navy` | #1e3d55 |
| 11 | `tealD` | #1f5e6e |
| 12 | `teal` | #2b8288 |
| 13 | `tealL` | #4fa7a1 |
| 14 | `foam` | #a7d8cb |
| 15 | `white` | #f6f2e7 |
| 16 | `red` | #b8342f |
| 17 | `redD` | #7a2523 |
| 18 | `gold` | #e9b84c |
| 19 | `goldD` | #a77a2e |
| 20 | `skinL` | #f3cfa6 |
| 21 | `skin` | #dca27c |
| 22 | `skinD` | #a86b50 |
| 23 | `greenD` | #34502f |
| 24 | `green` | #587a43 |
| 25 | `greenL` | #8ba45f |
| 26 | `purpleD` | #3e3157 |
| 27 | `purple` | #6a5487 |
| 28 | `blue` | #3c6ea6 |
| 29 | `orange` | #d27a3c |
| 30 | `grey` | #8e8b84 |
| 31 | `pink` | #dc8ea0 |

Swatch: `palette/v4-palette.png`. Source of truth: `tools/v4/pal.py` (index order is part of the spec).

## Grid
- **Tiles: 16×16 px.** Props snap to an 8 px half-grid.
- **Characters: 32×48 px frames, anchor (16,47)** (feet, bottom-centre). Same grid for every row (idle/walk ×4 dirs, work, shared poses, activities).
  Full v4 sheets: `sprites/v4/chars/<id>.png` (8 cols × 21 rows, see `manifest-v4.json`).
- **Chibi proportions, big heads** (head ≈ 14–22 px wide). Silhouettes must differ: Chopper ≈ 60 % height, Brook tall/thin + afro + top hat, Frankie huge with 6 px forearms, Robin tall/slim, Jinbe broad, Zoro 3 swords, Law nodachi, as in the anime's chibi art and the concept art.
  Faces are controlled: 2×2 eyes with a 1 px catch-light, 1–3 px mouth, no oversized grins or bouncing.

## Rendering rules
- **Selective outline (sel-out) in dark brown, never pure black.** Top/left edges use the darker tone of the material's own ramp;
  bottom/right edges use `ink` #2b1d18. No outline on interior boundaries except where shading needs one.
- **3 shading tones per material** (hi / base / shade) plus the sel-out tone = 4 per ramp. Cast shadow under hair and hats.
- **Light always from the top-left.** Soft drop shadows: dithered ellipse under feet, props offset +2,+2, all via `DARK` LUT.
- **Lantern glow at night**, warm `LIGHT` remap with an ordered-dither edge; **global tint** for weather and time of day (runtime).
- Dithering: 4×4 Bayer only, for gradients (water depth, glows, foam), never as noise on flat surfaces.

## UI
- Parchment (`cream`) panels with thin 1 px `woodD` borders, 1 px inner bevel, wood buttons and chips. Generous spacing (8 pt gutters).
- Pixel fonts: **VT323** for labels/body (≥ 15 px, i.e. ≥ 11 pt cap height-safe), **Pixelify Sans Bold** for money figures. Both SIL OFL.
- **Every money figure carries the gold coin icon**, and money numbers are the largest, highest-contrast text on screen (21 pt, `ink` on `cream`).
- Placeholder/demo values are always tagged with an `EXAMPLE` chip.

## Mobile-first: iPhone 16 Pro
402×874 pt, 3× DPR (1206×2622). Art at 1 art px = 1 pt = 3 device px (integer scale, `imageSmoothingEnabled=false`).
Tap targets ≥ 44 pt. Respect the Dynamic Island (top 54 pt) and home indicator (bottom 34 pt).

## Not in scope
Minigames, wanted posters, ship upgrades.

## Crew colour notes (v4.2)
- No palette additions. Two crew material ramps were added in `tools/v4/fig.py` from existing entries:
  `hairO` = orange / orange / skinD / wood (Nami's hair: no `tan` highlight, so it never reads blonde) and `jeansD` = blue / navy / navyD / navyD (dark jeans).
- Jinbe's skin ramp `fish` is now blue / navy (was teal). Show colours to keep: Luffy red vest + straw hat, Zoro green hair, Sanji blond + black suit,
  Robin black hair, Usopp curly black hair, Chopper pink hat, Franky blue hair, Brook afro, Jinbe blue skin, Law spotted hat,
  Nami long wavy orange hair + striped top + jeans.
