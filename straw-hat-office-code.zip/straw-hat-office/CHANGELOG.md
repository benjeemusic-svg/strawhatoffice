# Changelog: Straw Hat Office

## v4.3.4 (2026-10-19, Frankie; branch `v4.3.4-margins` from live v4.3.3 2e36257, NOT deployed)
Owner (~01:05 BRT): "resume the Margins tab". The paused v4.2 Margins work (93a7e65, 6899267, 0bedaed on branch v4.2, base 324183d) is
cherry-picked onto 2e36257; index.html rebuilt from src (no hand-merged build).
- MARGINS is its own phone tab again, as the v4.2 spec put it: SHIP · MONEY · MARGINS · CREW (4 x 100.5 x 58 CSS px at 402 wide, no overflow).
  Ship tab (4x ship only) and Crew tab (status + brainstorms) unchanged.
- Data: Robin's US COMPS tab of the tracker (gviz, CSV fallback), shown as-is: cost US$ (D), TCGplayer US$ (F), margin % (I), confidence (J), TCGplayer link (G).
- New per product: an R$ line (ours = column C as is; TCG ≈ F x 5.14) and "Robin checked <day>" from column A. Tabular digits, system font.
- Also from v4.2: optional IDEAS sync tab, BRAINSTORMS `sources` column kept (sync_crew.py, brainSessions()).
- Tests: new tests/check_v434_margins.js (live sheet row-by-row, recomputes I = (F - D*1.05)/(D*1.05)*100 within 0.1, R$/date line, footnote,
  tab sizes, overflow, page errors, screenshot); check_v43_ship expects the 4-tab bar; check_v42_margins / check_v42_sync carried over.

## v4.3 (2026-10-19, Frankie; branch `v4.3`, rebased onto master 786bf07 = live v4.1 2a177a0, NOT deployed)
Built in /workspace/pixel-office-v43.

**Owner changes (23:19 and 23:48 BRT, Oct 18)**
- All room plaques are gone: HELM, CHARTS, GALLEY, LIBRARY, SICKBAY, QA DESK, LOUNGE, WORKSHOP, CARGO. `tools/strip_plaques.py`
  repaints each sign in `art/v4/world/ship_<phase>.png` with the wall beside it (same plank/tile pattern, copied at the same phase),
  so there are no gaps. The lit copy of the LOUNGE sign in `glow_<dusk|night|storm>.png` (under the aquarium light) is repainted the same way. Rects are in `art/v4/world/plaques-removed.json`. The rects and copy map come from ship_day and are applied to
  all 4 phases; no pixel outside the rects changed. The v4.1 runtime plaque toning is off, and `V41.plq` (the bubble-avoid list) is empty.
- Ship tab = only the ship. Removed the CREW STATUS strip, REPLAY LAST PURCHASE, EVENTS & PREVIEWS, the BRAINSTORMS button and the
  SFX switch (sound stays off). Speech bubbles, banners and animations stay. The phone ship uses the largest whole-number scale
  that fits between the safe area and the tab bar, centred (402x874 @3x: k=3, 402x620 css).
- Crew tab = CREW STATUS (roster, decisions, "Red glow = needs your decision") + a BRAINSTORMS section that shows the existing
  board inline (`src/6_v43.js`). The ship's idea board still opens it as a modal.
- Tab bar stays SHIP / MONEY / CREW (Margins paused).

**Law 23:17**
- Aquarium glow by the door3L doorway (187-189, 423-441): Law saw it on the old v4r review copy (one whole glow layer over the crew).
  In this build the v4.1 depth pass paints wall glow under the crew, and the render probe shows 0 changed sprite px at those spots in
  all 4 phases. Regression cases added to tests/check_v41_glow.js. Note: t50's pixel gate can't see the split glow pieces of v4.1+
  (glowDrawnFrames=0), so it passes trivially there.
- S8 flat-cut head at (226,262): the A11 ceiling clip cut a bot that turned sideways right after a door. Routes now step straight
  down from a door until the whole sprite clears the wall line, and line up below a door before walking into it
  (`v43Knees`; S8 route now has 215,279). The head is hidden only inside the door column (behind the lintel).

**Tests**: new tests/check_v43_ship.js (layout, removed controls, no room-name text, Crew tab, door legs) and
tests/check_v43_plaques.py (art). check_v41_numfont, check_v4_live and check_v41_state now read the Crew-tab roster instead of the
strip; their screenshots go to frankie-review/shots-v4.3/tests.

### v4.3 world/render (first cut, from v4.1 324183d)

- **Ambient pack v4.2** (`art/v4/ambient/`, spec `AMBIENT-v4.2.md`) inlined by build.py and played by the new `src/6_v4amb.js`:
  aquarium fish + bubbles, grass/tree rustle with gusts, butterflies, falling leaf, flag + sail, wake + waterline roll, 0/1 px hull bob (4 s),
  sea shimmer/foam baked into the 4 procedural water frames, gulls (none at night), jumping fish, dolphins, a far ship, clouds and a rare
  Sea King peek (first one at least 120 s after load). Event intervals follow the spec; at most 2 one-shots at a time.
  Paused while the tab is hidden; a static frame with reduced motion. 30 fps only while gulls fly, 10 fps steps otherwise.
- Depth: ambient art goes inside the v4.1 y-sorted pass. Aquarium fish and resting butterflies are drawn above the wall glow and below every
  sprite. The flag is y-sorted on its pole base. Only flying things (gulls, butterflies, a falling leaf) are drawn over the crew.
- **Nami redraw** (orange post-timeskip hair, blue-striped top, Clima-Tact) and **Jinbe** (blue skin ramp), plus the new portraits24/16.
  Owner approved them at 22:35.
- **Crew brightness** (owner: the previews look brighter than the app):
  - crew no longer get the full phase LUT; they keep day colours at dusk and get only the light dusk table at night and in storms;
  - the world canvas is snapped to the device-pixel grid. It sat at y = 538.45 device px under the HUD.
- Perf (headless Chromium, 4x CPU throttle, every event forced at once): ambient 0.38-0.49 ms/frame mean, p95 1.1-1.5 ms.

## v4.1 (2026-10-18, Frankie; branch `v4.1` from f7c6832, NOT deployed, NOT copied to the Mac)
Simpler, money-first office on the v4 look. Built in /workspace/pixel-office-v41; /workspace/pixel-office-v4 and master untouched.

**Owner brief (19:25 BRT)**
- Removed XP/level, achievements, Quest Board (text, DOM, code and `status.json` quests).
- Room plaques toned down at runtime (art pack untouched).
- LIVE dot in the top card: tap or press-and-hold shows last refresh, source and sync time; Escape/outside tap closes; static with reduced motion.
- One top card: spent R$ + US$, 5% commission, units, `lines · stores`; money first with a coin on every figure. TOP DEAL is a slim chip under it (real current `deal_found` with numeric discount only).
- ~~Cargo list sorted by total value~~: built, then removed with the whole Orders tab (owner, 22:34; see below).
- Phone tab bar Ship / Money / Orders / Crew: fixed, safe-area aware, 44px+ targets, hud.png pixel icons; desktop/landscape keep the side panels.
- Placeholder panels stay hidden until real rows exist (Bounty Board, crew status lines). Stage-2 hooks only: `STAGE2.purchase/deal/summary/crewTap`.

**Law's v4 QA (20:07)**
- V4-1: date parsing never throws (`asDate`/`parseDate` wrapped, `fmtTime` returns "time unknown"); the log never freezes on '18/10/2026 19:31'.
- V4-2: zoneless 'YYYY-MM-DD HH:MM', gviz Date() and 'DD/MM/YYYY HH:MM' are read as BRT (-03:00) whatever the viewer's timezone.
- V4-3: BR prices ('R$ 1.234,56', 'R$ 1.234') parse correctly on the TOP DEAL chip. V4-4: DD/MM dates keep their time.
- V4-5: bubbles avoid the commission chip, meal banner and room signs (shift/flip, dock at the keel, or hide).
- V4-6: safe area applied once; top card starts right under the status bar. V4-7: no R$ 12,046.39 flash after Replay (count-up shows whole reais, ends exact).
- V4-8: DATA_FEED.md says the TOP DEAL chip needs a numeric `discount` > 0.
- A hung Sheet request falls back to the CSV backup (JSONP slice 7 s inside a 12 s budget).
- tests/check_v41_units.js: V4-1..V4-4 under 6 timezones via TZ (São Paulo, UTC, New York, Los Angeles, Tokyo, Kiritimati).

**Owner via Nami (20:23)**
- No mood/energy anywhere (tired, exhausted, focused, energy bars, zzz/… emotes, energy text).
- Crew status panel: per bot one plain "doing now" line, last real event with BRT time, and a NEEDS YOUR DECISION flag; a "Needs your decision" section sits at the top. Everything comes from CREW STATUS in /crew.json; no example rows; offline shows names/roles only.
  - Decision field: the existing `decision` column (blank = none, text = the question); no new column. `state` = working/idle/resting, `status` = the doing-now line. No simulated states: status.json no longer bakes `working`, and 5_crew.js no longer defaults a blank state to `working`.
- LV/XP removed; treasure map removed entirely (button, modal, code).
- Brainstorms kept, fed only by the real BRAINSTORMS tab: no example sessions (`src/brainstorms.json` deleted); empty shows "No brainstorms yet".

**Depth + footprints (owner iPhone bug, 20:27)**
- Crew and furniture are drawn in one y-sorted pass by the feet line (crew key = a.y, i.e. sprite top + 47 with anchor [16,47]; furniture key = its baseline). The front layer and the glow layer are split at runtime into pieces with baselines; wall glow (aquariums, lamps) now sits behind the crew instead of over them. Ship-layer pieces that must cover crew (sickbay desk + screen, galley counter, workbench) are cut from the ship layer. FRONT_BANDS is gone.
- 24 furniture footprints are blocked; walk legs that would cross one are re-routed with a 2px grid A* inside the room floor. Nodes moved out of footprints: library_c, workshop_c, door2R_in.
- tests/check_v41_routes.js walks every spot→spot route (3,780) and asserts no feet point enters a footprint, plus pixel checks that a bot in front of the aquarium at night is visible and the sickbay screen covers a bot behind the desk.

**Crew state, faces, decisions (owner via Law, 20:53)**
- Live v4 bug: Frankie showed "resting" although CREW STATUS said `state=working` (synced 20:50). v4 does read `state` (src/3_feeds.js:69 at f7c6832). But `v4State()` in src/6_v4.js:207 checked the simulated nap flag `a.resting` first. That flag is set in src/5_life.js:20 when the simulated energy (drained in :9, kept in localStorage) drops under 25, so a "tired" bot showed and was drawn as resting whatever the sheet said. A related default in src/5_crew.js:139 turned a blank state into `working`.
- v4.1: `v4State` reads only `state` (working, idle or resting; blank or anything else = resting), and the movement break rule uses the same function. The energy/nap simulation is gone. tests/check_v41_state.js loads a crew.json shaped like the live sheet, with old energy=0 in localStorage, and checks every face word, roster word and decision. It then changes the rows and checks that one refresh picks them up.
- State dots are brighter, and each face in the crew strip and roster has a plain word next to it: Working, Idle or Resting. The legend now reads "Red glow = needs your decision".
- "Needs your decision" items (decision cards, flagged roster rows, faces in the strip) pulse gently with a red glow. With reduced motion the highlight is static.
- Eye blink: each face blinks every 2.5–7 s on its own random timer (140 ms). Frankie (sunglasses) and Brook (skull) have no visible eyes, so they don't blink. There is no other face animation, and no blink with reduced motion or when the tab is hidden.

**Crew chat removed (20:33)**: CREW CHAT strip/UI and the stage-3 live-chat plan are gone. The sync still reads the CREW CHAT tab; nothing in the UI shows it.

**Crew voices (20:42/20:43)**
- Every spoken line lives in one table, `VOICE` in src/4_voice.js, keyed by bot id. Luffy: upbeat captain with "Nice work, crew!" (his old laugh line is gone everywhere, Luffy included). Brook Yohoho, Frankie SUPER, Robin calm Fufu, Zoro terse, Usopp dramatic, Sanji courteous, Chopper eager, Jinbe formal, Law dry, Nami sharp about money. At most one catchphrase per bubble, and not on every line.
- The purchase celebration uses each bot's own `cheer` line. The `summary_sent` line is Luffy's only; event labels are neutral and bots override them only with their own lines.
- tests/check_voices.js fails on the old laugh line anywhere (excluding the archived v3 side-view), on another bot's catchphrase, or on more than one catchphrase per bubble.
- The meeting summary split no longer uses a regex lookbehind (old iOS Safari).

**Sync**: optional RELEASES (from master 1c88524) and PALLET (sheetId 1097796826: pallet_id|status|next_ship_date|date_confidence|carrier|notes|updated_at) tabs in sync_crew.py and DEPLOY.md. A missing tab comes out as `[]` and never fails the sync. There is no PALLET UI yet.

**Law's v4 review (21:18), report.md**
- A, depth: wall glow (aquarium windows, lamp pools, screen light) is painted under the crew; glow on a ship prop shares that prop's baseline. Law's solid rects are added to the footprints, so feet never enter them. Side clearance keeps feet 9 px off the helm desk, the chart table and the library armrests while inside their depth band (fixes t50 S7/S8 "half-hidden"); door1L_out moved 3 px off the desk. Nodes that sat inside furniture moved out (library_c 274,284→274,297, workshop_c 128,542→122,542, door2R_in, sofa nodes/rest spots y 485, helm spot x 101). Walk legs that cross furniture get A* detours, then string-pulling removes zig-zags. No transit through the sickbay. Jinbe/Nami stand right behind their desks (y 204). A sprite is clipped to its own room (no head poking into the room above; doors go behind the lintel). New `tests/check_v41_glow.js`: pixel proof that glow never changes a sprite pixel (16 positions from Law's GLOW hits).
- D, voices: no one says the old laugh line. No scripted or example brainstorm starts by itself; a real session plays once per visit, and a line is skipped if its speaker isn't in the room, so no bot says another bot's line. A recency gate (same bot 15 min, any bot 10 min) cuts repeats. The "got a sec?" ping and example texts are gone, and a status older than 24 h is not shown as a bubble. Bubbles use the Pixelify font at 15 px.
- B, phone: double-tap zoom, pull-to-refresh and long-press "Save Image" are blocked on the ship. There is an apple-touch-icon (Luffy) and an inline manifest ("Straw Hat"), plus REFRESH NOW in the LIVE popover for home-screen mode. Contrast meets AA: muted labels are ≥ #625547 on the parchment, the status tags (ACTIVE/doing, todo, done) are darker under white text, and the Working/Idle/Resting words sit on a parchment chip. At 150% and 200% text there is no sideways scroll and nothing is clipped (Law's t55 zoom150/zoom200: 0 overlaps, 0 clipped, docSW = viewport).
- C, money first: snapshot-first, see below.

**Money (owner, 21:32)**
- MUST: the money is on screen instantly. A tiny script right under the top card fills SPENT / ≈US$ / commission / units / lines·stores as soon as that HTML arrives. It uses the newest of this browser's last live numbers (localStorage `pixelOffice.money41`) and the snapshot baked in at build time. The live Sheet numbers replace them when they arrive, and the offline fallback uses the same newest source ("NUMBERS AS OF …"). On slow 3G: money at 2.3 s; the page finishes loading at 12.6 s (`tests/check_v41_instant.js`).
- Every US$ figure is R$ ÷ 5.14, the funders' partner rate, hard-coded in `CONFIG.brlPerUsd`. v4 computed it from the first SUMMARY row of the Sheet (avg R$ ÷ avg US$ = 5.14 today, by coincidence). This covers the top card, money tab, bounty, cargo averages and the header pallet line. There is no new rate stamp, data-age dot, buy zone or decision strip.

**Own-row rule (owner via Nami, 21:56)**: anything a bubble or line says about what a bot is doing comes only from that bot's own CREW STATUS row (`status`, or `event_text` for its own events), matched by crew_id. The reported "Building your pixel office, one tile at a time!" on Robin was not in the app: it came from my QA script (test_v41_law.py V4-5), which injected that text into every bot's bubble to test placement. That script now puts a long text in each bot's own mocked row instead. App fixes:
- A blank `status` now clears the old text; before, a stale status survived the next sync.
- The bubble no longer falls back to the role line. A blank or >24 h status shows only the bot's own state word.
- Job-accept bubbles no longer repeat the task; they're the bot's neutral "aye".
- Zoro's stow line no longer names the product.
- The big-deal run is done by the bot whose own row found the deal, and Luffy's reply names that bot (no more hard-wired "Chopper").
- New `tests/check_v41_ownrow.js`: static scan, 40 s of live bubbles, a re-sync, and the screenshot shots-v4.1/v41-iphone16pro-robin-own-row.png.
- New `tests/check_v41_money.js`: the top card, money tab, commission, units, lines·stores, and US$ at 5.14 must equal the live Sheet's CSV, computed independently.

**Orders tab removed (owner)** (22:34): the whole phone ORDERS tab is gone: the CARGO HOLD product list (`renderCargo`/`cargoRows` plus the #cargo CSS) and the SHIPPING order table (`v41Orders`, `orderTable`, .maptbl CSS), plus its tab-bar button. The tab bar now has 3 equal buttons (Ship / Money / Crew) across 402 px. The cargo hold ROOM on the ship and Zoro's crate art are unchanged, and so are the money totals (top card, Money tab, commission). The SHIPPING tab is still read for the "on pallet" count. Tests that depended on #cargo and were updated: test_v41.py (cargo list/sort/footer checks become "Orders tab removed", the tab bar is 3 equal tabs, the per-tab visibility lists), run_v41.py (cargo fields removed from the numbers dump), check_v41_money.js (Cargo rows become an Orders-gone check) and check_v41_instant.js (the cargo US$ check is dropped).

**Bounty Board + Captain's Log removed (owner 20:31, done 22:52)**: the CAPTAIN'S LOG panel was still in #colR and always showed. The BOUNTY BOARD section was hidden only until the JOBS tab had rows, then it appeared. Both are now gone from the DOM, along with their render code: renderJobs, the job form, and the walk to the board to "accept" a job (simulated work). `addLog` still keeps entries in memory, but nothing renders them. The JOBS tab is still synced, with no UI. Tests updated: check_v313.py reads `logEntries` instead of `#log`, run_v41.py checks log times in memory, and test_v41.py checks the two panels are absent.

**Money tab simplified (owner)** (22:51): #pMoney is now only:
- MONEY title + live dot + "· read <date, time> BRT", the moment the numbers were read: live fetch time, or the snapshot/cache time.
- BOUNTY · MY 5% COMMISSION: R$ big, ≈ US$ under it.
- SPENT SO FAR · CURRENT PALLET: R$ big, ≈ US$ under it.

US$ = R$ ÷ 5.14. Removed: the "tracker PURCHASES" label, FX USED, funders, palletText/palletOn and bountyNote. The instant paint (baked snapshot or browser cache) now also fills the Money tab ids, through a second tiny call right after #pMoney. The bounty no longer counts up from R$ 0 on load; it shows the value at once, and REPLAY still counts up. check_v41_money.js checks bounty = 5% of spend and both figures in R$ and US$ against the live Sheet. check_v41_instant.js checks the Money tab is painted before the app script runs, with the same texts as the final render.

**Readability + layout (owner, 23:00)**
- Number font: every money, percent and count number (top card, Money tab, deal chip, crew strip, Crew tab, toasts, banners, floaties, bubbles) uses the system font with `font-variant-numeric: tabular-nums`, weight 700 (600 for the US$ lines). The pixel font's 5/9 and 2/8 looked alike. Numbers inside pixel-font prose are wrapped in `<span class="num">` by `v41Num()` / `v41NumHtml()`. The pixel font is kept for labels only.
- Ship first screen (phone, portrait): the whole CREW STATUS strip sits above the tab bar. `fitV4` reserves the tab-bar and strip heights and picks the largest whole-number pixel scale that fits (402×874 @3x: k = 3, ship 402×620 CSS px, strip bottom 772 px, tab bar top 815 px). A ResizeObserver on #crewStrip refits when the strip changes height.
- Crew tab heading on one line: "CREW STATUS · synced HH:MM" (stale/offline variants). The duplicated "CREW STATUS · crew.json … BRT" small text is gone.
- New test `tests/check_v41_numfont.js`: no visible text containing R$, US$ or % (and no digit inside #topCard/#pMoney/#crewStrip) is in the pixel font on Ship/Money/Crew, including a bubble, banner, floaty and toast. It also checks that the strip bottom is ≤ the tab-bar top at 402×874 and that the heading is a single line.

**Ship-tab money card removed (owner, 23:05)**
- The SPENT SO FAR / MY 5% COMMISSION / UNITS / LINES · STORES card and its TOP DEAL chip are gone from the Ship tab. The Ship tab is now the ship plus the crew strip, and the ship is at its full whole-number scale.
- The Money tab is unchanged as specified (live dot plus the read date, BOUNTY, SPENT SO FAR, each in R$ and US$ at 5.14). The live dot's existing popover (source, REFRESH NOW) now opens from the Money tab's live dot. No new UI.
- Tests that read the card (`check_v41_money`, `check_v41_instant`, `check_v4_live`, `check_v313` C2/N2/N4, `test_v41`, `run_v41`, the copy of Law's harness) now read the Money tab, or `stats` for units and lines/stores. They also assert that the card is absent. The money check still matches the live Sheet.
- Fix: the Bounty Board removal had also dropped `safeLink`, which the message-in-a-bottle news link still uses (check_v313 N1 caught a ReferenceError). It is restored in 5_jobs.js.

**Not built / deferred**: investor mode (cancelled by the owner), funders data, stage-2 animations, real-device test on an iPhone, captain's-log seed entries, PALLET UI, lawn mast/tree canopy depth (the mast is a scripted climb; only the tree trunks are blocked).

## v4.0-stage1 (2026-10-18, Frankie; branch `v4`, awaiting Law's QA, NOT deployed, NOT copied to the Mac)
Stage 1 of the v4 redesign ("new look"), built on master v3.1.3 (e6c27d6 merged in). Master stays deployable; v4 lives on its own branch/worktree (/workspace/pixel-office-v4).

**New look**
- Art pack copied (read-only) from /workspace/pixel-office-art into `art/v4/` (manifest-v4.json, world/spots.json, ship/front/glow/water/shadows, 11 crew sheets, portraits, ui/hud.png, ui/emotes.png, ui/css 9-slices, CREDITS + STYLE-GUIDE). build.py inlines it as one JSON pack with data URIs; `{{V4IMG:…}}` tokens in CSS. Single file, ~565 KB.
- World: portrait 402×620 canvas at an exact integer scale (k=3 on iPhone 16 Pro, k=1 on desktop), 4 baked time-of-day phases (day/dusk/night/storm; palette LUT recolour of crew, water, shadows), front layer, glow, 4-frame animated water, fish shadows. Draw order water → shadows → ship → crew behind front → front → crew in front → glow → emotes → particles. Frame-key skip when nothing changes.
- Crew stand at their stations from spots.json and walk its graph (BFS); existing states mapped to the new animations (working/idle/resting, quirks, events, meetings in the lounge m0–m10, meals, combos). Fireworks/confetti/celebrate/replay coin rain redrawn in v4 coordinates.
- HUD (HTML/CSS): pallet value + top deal over the sea corners, money in Pixelify Sans Bold with a pixel gold coin on every money figure (auto-wrapped). Right card = TOP DEAL (a real current deal only) or MY COMMISSION; see the 18:57 review below. Crew status strip: 11 portraits + status dots from live crew data (/crew.json over https, gviz fallback, embedded status otherwise); one ≥44px button that opens the roster. Crew chat strip is a placeholder: "COMING SOON · stage 3" (no SEND button).
- All existing panels/features kept and restyled: ledger (guild, LV/XP, items, spend, pallet, SFX), toolbar (map, brainstorms, replay, events & previews), data pill, weather, commission, crew roster + crew panel, jobs, log, cargo/order table, achievements, modals. Desktop (≥1100px) = centred portrait world with side columns; 641–1099px and phone landscape = world + one side column.
- Fonts: Pixelify Sans Bold subset (woff2, 6.5 KB, OFL) for headings + money only; everything else uses the system UI font. The VT323 body font was dropped.
- QA hook: `?phase=day|dusk|night|storm` forces a phase.

**Owner feedback pass (via Law, 18:37 BRT)**
1. Labels never overlap: no DOM name tags or room labels on the stage (plaques are baked art); at most one speech bubble at a time; no ambient status bubbles, so bubbles only show for events, spoken lines (meetings, meals, combos) and the tapped/hovered crew. Tapping a crew member opens their panel with the name.
2. One readable font (system UI) for all small text, buttons, badges, toasts and banners; pixel font only for headings and money. Map-modal canvas labels moved from 5–8px PIX to 10–13px bold system font.
3. Native emoji in the UI are replaced by ui/v4 pixel icons (coin, map, chat, send, close, settings, crew, pallet, deal, plus emotes heart/music/idea/happy/surprised/question/sleepy/focused). Weather/food emoji with no pixel icon are dropped; the words are already there.
4. Lighter frames: wood 9-slices replaced by flat fills with 1px hairlines; parchment 9-slice kept only for the HUD cards and bubbles (art). Flat buttons with a 1px border.
5. Money first: larger pixel money; XP bar 4px and dimmed, WORKING/ON BREAK badges outlined and dimmed, role/status/event/energy lines lower contrast, legend/notes muted.

**Owner review of iphone-webkit-top.png (18:57 BRT)**
- Mislabelled money fixed: the right HUD card no longer calls the biggest purchase line a "deal". It shows **TOP DEAL** only for a real, current deal: a `deal_found` row in CREW STATUS (Chopper / crew feed) with a numeric `discount` (% below the average buy price), dated within the last 24h. The card shows the price parsed from `event_text` (or "−X%" when the text has no price), the product, and "−X% vs avg buy". Otherwise it shows **MY COMMISSION**: R$ 12,046.40 (stats.commission = 5% of the current-pallet spend, the same figure as the CREW COMMISSION panel), ≈ US$ underneath, and "5% of pallet". There's no deals feed in the app yet, so CREW STATUS is the only deal source.
- Calmer water: the sea is painted from the art tile's own phase-recoloured average colour (turquoise by day, deep navy at night/storm). It has a flat base, ~34 large soft swells and ~120 sparse low-contrast crests, animated at 2 fps instead of 4. The high-contrast 32px tile is no longer drawn.
- The "embedded status (crew feed unavailable)" line is gone. The strip header shows a quiet "synced HH:MM", "stale HH:MM" or "offline" (tooltip has the detail), and the dot legend moved under the portraits, dimmed.
- The chat placeholder no longer has a SEND button (removed until stage 3).
- Banners (meal, meeting) sit below the HUD cards instead of over them.
- tests/check_v4_live.js now also checks TOP DEAL (current mocked deal: "R$ 1,234", "−18% vs avg buy") and that a 3-day-old deal falls back to MY COMMISSION = the commission panel figure.

**Fixes on top of master v3.1.3**
- N1b: `serveMeal` sets a one-off 60s timer, so the manual meal banner clears at 60s (it was 60–80s via the ~20s lifeSchedule poll).
- C6: the ceremony log line reads "Weekly MVP ceremony at the mast" (was "Weekly mvp ceremony"). The meeting log text now comes from a MEET_LOG map instead of lower-casing the banner title. tests/check_v313.py was updated for the C6 wording and the N1b 60s timing.
- Bubble width is re-measured once webfonts load (a pre-font measurement let a bubble overflow by 3px), and #stageWrap clips horizontal overflow.

**Tested** (headless Playwright: WebKit 26 + Chrome, iPhone 16 Pro 402×874 DPR3 touch, phone landscape 874×402 DPR3, desktop 1440×900; harness /workspace/frankie-review/run_v4.py → results-v4.json, screenshots in /workspace/frankie-review/shots-v4/):
- 0 console errors, page errors or failed requests on all 5 configs.
- Numbers match the tracker on every config: 396 items, 28 lines · 27 stores, R$ 240,928 (240,927.93), commission R$ 12,046.40, cargo sum 396 / R$ 240,928, HUD pallet = spend. With no live deal, the right card = MY COMMISSION R$ 12,046.40 ≈ US$ 2,344 (5% of pallet), equal to the commission panel. 0 money figures without a coin.
- 0 tap targets under 44px (page and all 4 toolbar modals/actions); 0 visible text under 14.6px on any config/modal; no horizontal scroll.
- Exact integer scale: 3 device px per art px on the phone and in landscape, 1 on desktop; backing store 402×620.
- Loop ~30fps (WebKit 31), draw 0.06–0.16 ms/frame, ~31 draw calls; Chrome main-thread work 63–72 ms/s (6–7%), JS heap 3–5 MB. Hidden tab: 0 ticks while hidden, resumes at 31/s. Reduced motion: 15fps, both engines.
- No 1970 dates (all row years 2026); no minigame/wanted/upgrade/500-goal text or globals.
- Strip header reads "offline" with no crew feed and "synced 16:40" with the mocked /crew.json.
- Bubbles: max 1 bubble at a time during a meeting + event preview (25s sample); 0 visible name tags/room labels; full morning meeting with 0 bubble-off gaps; all 11 crew reach the lounge spots.
- Canvas tap on Nami opens her panel; hover cleared after close.
- 4 phases render (day/dusk = sea water, night/storm = deep water).
- tests/check_crewjson.js PASS; new tests/check_v4_live.js PASS (strip dots resting/offline/alert/idle/working and the "deal −18%" chip follow a mocked /crew.json); tests/check_v313.py on the v4 build 27/27 PASS (WebKit + Chrome); N1b (banner gone at 60.5s, present at 59s) and C6 log line verified under a fake clock.

**Not tested**
- A real iPhone / real Safari (only WebKit headless), the hosted Cloudflare build behind Access, and Law's QA.
- Real fps/battery on a device (the headless numbers are a proxy).

**Known gaps / deferred**
- v3 canvas decorations not ported to the v4 world: treasure vault + coin pile, trophy shelf, Halloween pumpkins/bats, Den Den Mushi phones, idea board, pallet crates. Ringing shows a "surprised" emote + alert dot instead. Replay/new purchase rain gold over the cargo hold.
- No rain/fog overlay or weather tint on the v4 world yet; storm is only the storm phase palette.
- Glow flicker is not animated (static glow layer).
- The idle loop rarely drops to 10fps because some crew are almost always walking.
- The map modal is still the v3 canvas map (fonts fixed only).
- Living-crew behaviours (stage 2) and crew chat (stage 3) are not built.

## v3.1.3 (2026-10-18, Frankie; Law's v3.1.2 QA fixes, awaiting Law's QA, NOT deployed)
Small, merge-friendly patch on master over b366efb (v3.1.2, deployed 17:28 BRT). Fixes from /workspace/law-qa/v312-results/report.md:
- **N1, duplicate schedule():** the crew-life scheduler in src/5_life.js is now `lifeSchedule()` (boot call + 20s interval updated). `schedule()` in src/6_loop.js stays the animation-frame scheduler. Breakfast/lunch/dinner, the weekday 09:00 morning meeting and the Friday 16:00 MVP ceremony now actually fire, and the manual meal banner clears after ~60s.
  - Found while testing N1: Sanji's "Come and get it!" arrival callback read `MEAL.name` after the meal could already have ended (e.g. tab hidden) and threw inside the frame loop. It now captures the name and only speaks if a meal is still on.
  - The meeting log line lost its emoji-slice bug (" weekly mvp ceremony" → "Weekly mvp ceremony").
- **N2, OFFLINE at ~12s:** gviz and the CSV fallback share one 12s deadline (`SHEET_TIMEOUT_MS`), so a hanging Sheet shows OFFLINE · SNAPSHOT at ~12s instead of ~24s.
- **N3, invalid synced_at:** new `okDate()` guard; a bad `synced_at` no longer throws. Tabs still load from crew.json with the note "crew.json time unknown", and no SYNCED label is shown.
- **N4, stale crew sync:** if a later /crew.json fetch fails after a good sync, the app keeps the last good crew data (crew, jobs, news, chat…) and the pill reads "· CREW SYNC STALE HH:MM BRT" (feed notes say "(stale)", feeds are marked not live). The next good fetch returns it to "CREW SYNCED".
- **N5, serial dates:** serials use `Math.floor` (a date-time after noon stays on its day) and digit-only text of 6+ digits ("123456") is rejected instead of becoming year 123456.
- **C2 leftover:** the desktop guild subtitle wraps instead of being cut with "…" (header grows from 85 to 100px at 1280 and in WebKit 1440; phone header unchanged).

**Tested** (Playwright headless WebKit iPhone 16 Pro 402×874 DPR3 first, then Chromium; new script `tests/check_v313.py`, 27/27 PASS; outputs in /workspace/pixel-office-qa/v313/):
- N1 with a fake clock (BRT): breakfast starts 08:00 and ends 08:30, lunch 12:00–13:00, dinner 19:00–20:00 (banner and MEAL checked before/at/after each); Monday 09:00 morning meeting starts and finishes; no meeting on Saturday; Friday 16:00 ceremony starts and finishes (delivery count stubbed) and, with no real deliveries, logs "ceremony skipped"; manual "Serve a meal" banner up at 55s, gone by 85s. `lifeSchedule` and the frame `schedule` are distinct functions.
- N2: Sheet hanging → OFFLINE at 12.2s (WebKit and Chromium); gviz refused + CSV hanging → 12.1–12.2s; refused outright → 0.2–0.5s; numbers 396 next to OFFLINE.
- N3: bad synced_at → crew/jobs/news from crew.json ("time unknown"), Chopper's mock status applied, no RangeError, no SYNCED label (WebKit + Chromium).
- N4: good → "CREW SYNCED 16:40 BRT"; then 404 → "CREW SYNC STALE 16:40 BRT" with crew/jobs/chat rows kept; good again → "CREW SYNCED 16:40 BRT" (WebKit + Chromium).
- N5: 46305, 46305.25/.5/.99, "46305", "46305.75" → 2026-10-10; "123456", " 1234567 ", 123456 → null; "10/10/2026" and Date(2026,9,10) unchanged.
- C2: subtitle not clipped (scrollWidth ≤ clientWidth, no "…") at 1180/1280/1440 in WebKit and Chromium; no horizontal overflow; iPhone header unaffected.
- Regression: `node tests/check_crewjson.js` PASS; Law's harness against this build (t20 main WebKit iPhone + Chromium desktop): 396 items, 28 lines · 27 stores, R$ 240,928, ≈ US$ 46,873 @ 5.14, on pallet 0, commission 12,046.40, map dates 13–17/10/2026, no 1970, 0 console/page errors; t2_layout at all 6 viewports: 0 targets under 44px, nothing under the safe areas; t32 meeting 60s (WebKit iPhone, Chromium desktop): 0 visible runs under 600ms, Luffy's bubble continuous for 47s, 0 errors.

**Not tested:** real Safari, a physical iPhone, the owner's Mac, the live Cloudflare Access + KV /crew.json (mocks only), the automatic meals/meeting/ceremony at real wall-clock times (fake clock only), a real Friday ceremony from real deliveries (stubbed), the full 34-button event sweep and perf run (unchanged code paths). Not deployed and not copied anywhere.

## v3.1.2 (2026-10-18, Frankie; Law's v3.1.1 QA fixes, awaiting Law's QA, NOT deployed)
Built on master: v3.1.1 was merged into master on top of 8fc5446 (crew.json reader) and 53c1187 (KV /crew.json worker route). The crew.json reader is unchanged.
Fixes from /workspace/law-qa/v311-results/report.md:
- **B1, meeting bubble blink:** the meeting say duration went from 3700 to 4100, so it outlasts the 3900 step (src/5_life.js). The same gap pattern got the same fix in two more places: brainstorm 3600→4000 (vs a 3800 step) and combo lines 2300→2600 (vs a 2400 step).
- **M1, gviz timeout:**
  - A late JSONP reply now hits a no-op callback, so there is no more "Can't find variable: __gviz…".
  - The CSV fallback has a 12s abort.
  - The pill reads "◌ CONNECTING TO TRACKER…" while loading. On failure it reads "○ OFFLINE · SNAPSHOT AS OF …", with "retrying in 1 min" and an automatic retry.
  - When a retry happens while offline, the pill shows "◌ RETRYING TRACKER…".
  - The numbers render together with the pill, so LIVE never shows next to "–".
- **M2/M3, tap targets:** a minimum of 44px on every viewport, not just the phone. This covers SFX, section headings, .btn (POST BOUNTY), the job form select/textarea/input, panel buttons and every details summary, including the map's ORDER TABLE.
- **M4, text serial dates:** a date serial stored as text (e.g. "46305") is now parsed as a Sheets serial, the same as a numeric one.
- **M5, sticky hover:** closing the panel clears the hover, and a touch pointerup never leaves a hover behind.
- **C1:**
  - status.json log line: removed "(mini-games later removed in v3.1)".
  - HTML comment: "pallet goal" → "pallet start date".
- **C2:** the guild title wraps instead of truncating, so desktop shows "Treasure Route Trading Co." in full.
- **C3:** the panel says "heading to the treasure vault", using the place rather than the activity. Labels without "the" show "on the way (…)".
- **C4:** bubble edge clamping follows the edge exactly. The old >3px hysteresis produced 4px steps.
- **C5:** a minimum display time was added. A shown bubble stays at least 600ms even when an event preempts it, and its text is held for at least 600ms.

**Tested** (headless Chrome via Playwright on an iPhone 16 Pro 402×874 DPR3 emulation, landscape 874×402 and desktop 1440×900; harness /workspace/frankie-review/fixes312.py and run312.py):
- B1: a full morning meeting had 0 bubble-off gaps, and the bubble never fell back to the status text.
- M1: with gviz and CSV delayed 15s, there were no page errors. The pill went CONNECTING → OFFLINE·SNAPSHOT, and never read LIVE next to "–".
- M2/M3: 0 targets under 44px on desktop, landscape and phone. ORDER TABLE is 44px tall.
- M4: "46305", 46305 and " 46305 " all give 2026-10-10.
- M5: after a touch tap, then closing the panel, the hover is null both straight away and 1s later.
- C1: neither stale string remains.
- C2: the desktop title is not truncated.
- C3: verified in the panel text.
- C4: the bubble left edge stays within 1px while the speaker walks along the edge.
- C5: "All signature animations" gives a shortest bubble run of 599ms (was 140–281ms).
- Regression:
  - no console errors or failed requests
  - no minigames, cannon, upgrades, wanted posters or 500 goal
  - pallet numbers consistent: 396 items · R$ 240,928 · 28 lines · 27 stores, on pallet: 0
  - no 1970 dates
  - bubble no-flicker check: 0 bad runs
  - hidden pause: 0 ticks
  - reduced motion: 15 fps
  - all 11 crew rendered
  - tests/check_crewjson.js: PASS

**Not tested:**
- Real Safari/WebKit or a physical iPhone.
- The hosted Cloudflare build: v3.1.2 is not deployed.
- The owner's Mac: v3.1.2 was not copied there.
- Law's QA.

**Known leftover:** the desktop header subtitle "São Paulo → USA · TCG sourcing crew" is still ellipsized at 1440px.

## v3.1.1 (2026-10-18, Frankie; sprite costume fix. Law: GO. Deployed to production 17:03 BRT, deployment db6e9b28)
Branch `v3.1.1` in worktree `/workspace/pixel-office-v311`, cut from v3.1 (`5f6a41b`). The main tree was not touched.

**Bug:** every crew sprite showed the same purple cape and back. The Halloween costume layer in `costume()` (`src/5_world.js`) drew a purple cape over every character, front and back, for the whole of October.

**Changed**
- `src/5_world.js`: removed the Halloween cape from characters. Halloween stays as ship scenery only (pumpkins, bats, tint). The other seasonal accents (Christmas scarf, Festa Junina trim, Carnival stripes) are unchanged.
- `src/5_crew.js`: outfits now match the owner's list.
  - Franky's shirt changed from red to blue floral (#2f7fe0), with navy shorts so the shirt still reads.
  - Jinbe's kimono and sleeves changed from orange to blue (#24479a), with an orange sash as the accent.
  - Usopp got a yellow belt line so he reads brown/yellow from every angle.
  - Nobody else changed. Luffy (red vest), Zoro (green), Nami (orange), Sanji (black suit), Chopper (pink hat), Robin (purple), Brook (black suit, top hat) and Law (yellow/black) already matched once the cape was gone.
- Rebuilt `index.html` (234,704 bytes).

**Tested (headless Chrome via Playwright; iPhone 16 Pro 402×874 DPR3 and desktop 1440×900)**
- Contact sheet: all 11 crew front/back/left/right, rendered with SEASON forced to halloween. Every back view shows that character's own hair and outfit colour; there is no shared cape colour left.
- No console errors and no failed requests.
- Removed features stay gone: no minigames or cannon, no upgrades, no wanted posters, no 500-item goal. This was checked by both text search and globals.
- Pallet numbers are consistent: 396 items · R$ 240,928 · 28 lines · 27 stores, cargo matches, on pallet: 0.
- Purchase dates parse to 2026, with no 1970 dates.
- Bubble no-flicker check: no bad runs on phone or desktop.
- Hidden-tab pause: 0 ticks while hidden.
- Reduced motion: 15 ticks/s, BOB 0.
- Phone tap targets: none under 44px.

**Not tested**
- Real Safari/WebKit or a physical iPhone.
- Other seasons' accents, beyond confirming the code is unchanged.
- QA by Law.
- Not copied to the Mac and not deployed.

## v3.1 (2026-10-18, Frankie; owner-approved)
Built on top of Luffy's 16:23 BRT speech-bubble hotfix, whose files were already current in the v3 baseline. Bubble behaviour is unchanged.
Backups: `/workspace/pixel-office-backups/v3-20261018-162623/` (cp -a) plus git commit `a9f1124` ("v3 as handed over by Luffy").

### Data: one number source
- **Pallet goal removed.** That covers `CONFIG.palletGoalItems` (the 500 placeholder), `palletPct`, the header progress bar and %, and the cargo-hold crate stack that scaled with the goal.
- **The header now shows plain numbers:** `CURRENT PALLET → USA: since 8 Oct: 396 items · R$ 240,928 · ≈US$ 46,873` plus a small `on pallet: N items` line. N counts non-cancelled SHIPPING rows with `PALLET #` filled (0 today). The crate stack draws one crate per such order, up to 9.
- **Single source for everything:** PURCHASES lines dated on/after `CONFIG.palletStartDate` (2026-10-08). That is `compute()` in 3_data.js. ITEMS BOUGHT, TOTAL SPEND, the pallet line, the commission, the cargo hold, XP, achievements and the map's "next pallet loading" all come from it. Taberna Geek is in PURCHASES at its negotiated R$44,500 for 4 EB05 cases. SHIPPING no longer overrides the pallet count; the old 375-vs-396 mismatch is gone.
- **Lines with no date** are kept and flagged in the tooltip, not dropped. If the date filter ever matches nothing, the app counts all lines and logs a warning.
- **Bug fix:** gviz returns `PURCHASE DATE` as a Sheets serial number (e.g. 46305). `parseDate()` now converts serial days. Before this fix every line was dated 1970 and excluded.
- **"28 orders" is now "28 lines".** Log, XP rule and achievements ("25/50 purchase lines") use the same wording. One PURCHASES row can cover several store orders.

### Removed features
- **Mini-games, all of them:** fishing, treasure diving, Usopp's cannon, card packs, break-room quiz. Removed: `src/5_games.js`, the MINI-GAMES toolbar button, `games:openGames` in 4_ui.js, the "card-pack chest" spot label (now "treasure chest"), and the mini-game mentions in the quest board/log. The source is archived in `archive_minigames/` (not built), with the lion card art saved as `lion-card-art.js`. `.gamecv` and `.tabs` styles are kept (used by the treasure map and brainstorms). Old localStorage keys (`best.*`, `fish*`, `cards`, `packs.*`) stay in place, but nothing reads them.
- **Ship upgrades:** `UPG`, `upgOn`, `openUpgrades`, the SHIP UPGRADES button and modal, and all upgrade visuals (brass lanterns, pennants, gold sail trim, the lion's golden crown, observation deck). They were computed live and never stored, so there are no localStorage keys to clean up. Achievements and the trophy shelf stay; they still show in the side panel.
- **Wanted posters:** `openWanted`, the WANTED POSTERS button and modal, the `.posters`/`.poster-card` CSS and `CONFIG.bountyPerDelivery`. The side panel formerly titled "WANTED" is now **CREW COMMISSION** and shows the same 5% figure. The weekly MVP stays.
- The toolbar is now 4 buttons: Treasure Map, Brainstorms, Replay Last Purchase, Events & Previews.

### Ship and crew
- **Lion figurehead restored** at the bow of the top-down view (4_ship.js). It's a port of archive_sideview/4_ship.js:94-101 scaled to fit the canvas: 16-petal sunflower mane, face, eyes, whiskers. It's base ship art, with no crown, because that was an upgrade.
- **Frankie** (Interface Shipwright) and **Law** (QA) are now drawn on the ship in the existing fillRect style, with roster entries and click panels.
  - Frankie has a blue pompadour, sunglasses and an open red shirt. His home is the shipwright workbench on the bow deck.
  - Law has a white spotted hat, a yellow and black hoodie with the smiley mark, and a sword. His home is the QA desk on the bow deck.
  - Both get Den Den Mushi snails, quirks, meal and meeting lines, two extra meeting spots, and signature events `ui_shipped` and `qa_report` (with preview buttons).
  - They're in status.json and the DATA_FEED crew_id list. The sprite pack in /workspace/pixel-office-art/ will replace this art later.

### Mobile and battery
- The hint text is now "tap a crew member" ("tap or click" on devices that can hover).
- The render loop stops while `document.hidden` and resumes on `visibilitychange`.
- `prefers-reduced-motion`: CSS transitions and animations become near-instant (bubbles still use the same on/off logic). The canvas runs at about 15 fps with no ship bob, sea shimmer, foam or grass sway.
- No forced layout each frame:
  - The canvas offset is cached in `fit()`, which re-runs on resize, orientation change and via a ResizeObserver.
  - Room labels and the vault tag only write `left`/`top`/text when the values change.
  - Layouts went from about 286/s to about 55/s (one normal layout per frame).
- Toolbar: every button is at least 44 px tall on all screens. On phones it's a 2×2 grid, with nothing scrolled off-screen at 402 px.
- Added `<meta name="robots" content="noindex, nofollow">`.

### Verified (headless Chrome; iPhone 16 Pro 402×874 @3x and desktop 1440×900)
- No console errors or failed requests; page data reads LIVE.
- Header items/spend, the pallet line, commission (R$ 12,046.40 = 5% of R$ 240,927.93) and the cargo-hold totals (396 / R$ 240,928) all agree.
- 11 crew render; the Frankie and Law panels open.
- No horizontal scroll. On the phone, 0 tap targets are under 44 px.
- **Bubble no-flicker check** (new): bubble visibility sampled every frame for 3 s, three times per viewport. Each crew member's bubble switched at most twice per window, with no run shorter than the hotfix's minimum on (1.6 s) or off (0.35 s) time, so there is no per-frame toggling.
- Hidden page: 0 ticks while hidden, and the loop resumes on return. Reduced motion: 15 ticks/s and bob 0.
- Harness: /workspace/frankie-review/run31.py. Results: results-v3.1.json. Shots: shots-v3.1/.

### Not done / follow-ups
- The owner's Mac copy (~/Documents/Straw Hat Office/index.html) has not been replaced; this box can't reach it.
- Phone room labels and name tags are still 5–6 px. Enlarging them is a redesign item.
- In zoom mode the zoom button scrolls away with the stage.
- A bubble near the left edge of the stage can be partly clipped by the stage. This is Luffy's bubble code, left untouched on purpose.
- Stray `*.whl` files (pillow, pngquant, puremagic, dropped in src/ at 16:20 by another process) are ignored by the build and were left in place.
