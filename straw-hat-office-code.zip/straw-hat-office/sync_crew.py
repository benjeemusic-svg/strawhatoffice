#!/usr/bin/env python3
"""Crew sync: Google Sheet "Straw Hat Crew Board" -> Cloudflare KV 'crew' -> GET /crew.json.

Two connector calls per sync (see DEPLOY.md, "Crew sync"):
  1) user-Google-sheets read_range (all 10 tabs in one batch, write_to_file=true)
  2) python3 sync_crew.py <that result file>      -> writes deploy/sync_code.js
     user-Cloudflare execute  code="$file:/workspace/pixel-office/deploy/sync_code.js"
"""
import csv, io, json, os, re, sys, datetime

HERE = os.path.dirname(os.path.abspath(__file__))
SHEET_ID = "10DeM9dRNrlM96pbdDC7Z1EKDVBbnFqgWQLjWrS0Eb6I"
ACCOUNT_ID = "4018a531e6c8218f03593e05f7c9b596"
KV_NS = "38a00144cc3d4956907ec52f9e89e330"
TABS = ["CREW STATUS", "JOBS", "SUMMARIES", "BRIEFING", "NEWS", "BRAINSTORMS", "CREW CHAT"]
# Optional tabs: output as [] when absent (older batches / sheets without them never fail the sync).
# RELEASES header: release_id|game|product|kind|preorder_opens|release_date|date_confidence|source|link|notes|updated_at
# PALLET header (sheetId 1097796826): pallet_id|status|next_ship_date|date_confidence|carrier|notes|updated_at  (v4.1: synced only, no UI yet)
# IDEAS header (v4.2): id|title|proposed_by|problem|idea|data_sources|owner_bot|effort|status|owner_decision_at|outcome|decision_reason  (synced only, no UI yet)
# BRAINSTORMS has a 6th column `sources` (v4.2): rows are keyed by header, so every column, sources included, is kept as-is.
OPTIONAL_TABS = ["RELEASES", "PALLET", "IDEAS"]
BRT = datetime.timezone(datetime.timedelta(hours=-3))

def load_result(path):
    raw = open(path, encoding="utf-8").read()
    i, j = raw.find("{"), raw.rfind("}")
    if i < 0 or j < 0:
        sys.exit("no JSON found in " + path)
    data = json.loads(raw[i:j + 1])
    if data.get("truncated"):
        sys.exit("read_range result was truncated; re-read with a larger maxChars or row windows")
    if data.get("spreadsheetId") not in (None, SHEET_ID):
        sys.exit("unexpected spreadsheetId " + str(data.get("spreadsheetId")))
    return data

def rows(content):
    r = list(csv.reader(io.StringIO(content or "")))
    if not r:
        return []
    hdr = [h.strip().lower() for h in r[0]]
    out = []
    for line in r[1:]:
        if not any(c.strip() for c in line):
            continue
        out.append({h: (line[k].strip() if k < len(line) else "") for k, h in enumerate(hdr) if h})
    return out

def main():
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    data = load_result(sys.argv[1])
    by_tab = {}
    for sec in data.get("ranges", []):
        by_tab[sec.get("sheet")] = rows(sec.get("content", ""))
    missing = [t for t in TABS + OPTIONAL_TABS if t not in by_tab]
    payload = {
        "synced_at": datetime.datetime.now(BRT).replace(microsecond=0).isoformat(),
        "source": "Straw Hat Crew Board",
        "tabs": {t.replace(" ", "_"): by_tab.get(t, []) for t in TABS + OPTIONAL_TABS},
    }
    if missing:
        payload["missing_tabs"] = missing
    js = json.dumps(payload, ensure_ascii=False, separators=(",", ":"))
    os.makedirs(os.path.join(HERE, "deploy"), exist_ok=True)
    open(os.path.join(HERE, "deploy", "crew.json"), "w", encoding="utf-8").write(js)
    code = """async () => {
  const value = %s;
  const path = `/accounts/%s/storage/kv/namespaces/%s/values/crew`;
  const put = await cloudflare.request({ method: 'PUT', path, body: value, contentType: 'application/json', rawBody: true });
  let back = null;
  try { const g = await cloudflare.request({ method: 'GET', path }); back = g.result !== undefined ? g.result : g; } catch (e) { back = String(e); }
  const s = typeof back === 'string' ? back : JSON.stringify(back);
  let parsed = null; try { parsed = typeof back === 'string' ? JSON.parse(back) : back; } catch (e) {}
  return { put_success: put.success, put_errors: put.errors, readback_bytes: s.length,
           readback_synced_at: parsed && parsed.synced_at, matches: parsed && parsed.synced_at === %s,
           counts: parsed && parsed.tabs ? Object.fromEntries(Object.entries(parsed.tabs).map(([k, v]) => [k, v.length])) : null };
}""" % (json.dumps(js), ACCOUNT_ID, KV_NS, json.dumps(payload["synced_at"]))
    out = os.path.join(HERE, "deploy", "sync_code.js")
    open(out, "w", encoding="utf-8").write(code)
    print("wrote %s; synced_at %s; rows: %s%s" % (out, payload["synced_at"],
          {k: len(v) for k, v in payload["tabs"].items()}, (" MISSING " + str(missing)) if missing else ""))

if __name__ == "__main__":
    main()
