// v4.1 money check against the LIVE tracker: the Money tab (Bounty = my 5% commission and Spent so far, R$ and US$ at the partner rate 5.14)
// plus the computed units / lines / stores must equal the Sheet. The Ship-tab money card was removed by the owner (23:05) and the Orders tab (22:34). Expected values come from the Sheet's own CSV export (computed independently in Node).  node tests/check_v41_money.js [url]
const { chromium } = require(process.env.PW || '/workspace/pwtest/node_modules/playwright-core');
const URL = process.argv[2] || 'http://127.0.0.1:18790/index.html', ID = '125TloDi-xWce5NyGbKupJELfDkSGgJnguE3MZJepa_U', FX = 5.14;
const csv = t => { const out = []; let r = [], f = '', q = false; for (let i = 0; i < t.length; i++) { const c = t[i]; if (q) { if (c === '"') { if (t[i + 1] === '"') { f += '"'; i++; } else q = false; } else f += c; } else if (c === '"') q = true; else if (c === ',') { r.push(f); f = ''; } else if (c === '\n' || c === '\r') { if (c === '\r' && t[i + 1] === '\n') i++; r.push(f); out.push(r); r = []; f = ''; } else f += c; } if (f || r.length) { r.push(f); out.push(r); } return out; };
const num = s => { s = String(s || '').replace(/R\$|US\$|\$/g, '').trim(); if (!s) return 0; s = /,\d{1,2}$/.test(s) ? s.replace(/\./g, '').replace(',', '.') : s.replace(/,/g, ''); const v = parseFloat(s); return isNaN(v) ? 0 : v; };
const pd = s => { s = String(s || '').trim(); let m = s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})/); if (m) return new Date(Date.UTC(+m[3], +m[2] - 1, +m[1])); m = s.match(/^(\d{4})-(\d{2})-(\d{2})/); if (m) return new Date(Date.UTC(+m[1], +m[2] - 1, +m[3])); return null; };
const brl0 = n => 'R$ ' + Math.round(n).toLocaleString('en-US'), brl = n => 'R$ ' + n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }), usd0 = n => 'US$ ' + n.toLocaleString('en-US', { maximumFractionDigits: 0 });
(async () => {
  const t = await (await fetch(`https://docs.google.com/spreadsheets/d/${ID}/export?format=csv`)).text(); const rows = csv(t), hdr = rows[0];
  const di = hdr.findIndex(l => /\b(date|data)\b/i.test(l)); let L = rows.slice(1).filter(r => r[0] && r[2] && num(r[2]));
  const start = new Date(Date.UTC(2026, 9, 8)), dated = di >= 0 && L.some(r => pd(r[di])); if (dated) { const f = L.filter(r => !pd(r[di]) || pd(r[di]) >= start); if (f.length) L = f; }
  const E = { items: L.reduce((a, r) => a + num(r[2]), 0), spend: L.reduce((a, r) => a + num(r[3]), 0), lines: L.length, stores: new Set(L.map(r => r[0].trim())).size, by: {} };
  L.forEach(r => { const p = r[1].trim(); E.by[p] = E.by[p] || { q: 0, v: 0 }; E.by[p].q += num(r[2]); E.by[p].v += num(r[3]); });
  const b = await chromium.launch({ executablePath: '/usr/bin/google-chrome' }); const p = await b.newPage({ viewport: { width: 402, height: 874 }, deviceScaleFactor: 3, isMobile: true, hasTouch: true });
  await p.goto(URL); await p.waitForFunction(() => /LIVE/.test(document.getElementById('dataPill').textContent), null, { timeout: 30000 });
  const G = await p.evaluate(() => ({ shipCard: ['topCard', 'spend', 'spendUsd', 'tcComm', 'items', 'ordersStores', 'dealChip'].filter(i => $(i)), units: stats.items.toLocaleString('en-US'), ls: `${stats.lines} · ${stats.stores}`,
    bountyBrl: $('bounty').textContent, bounty: $('bountyUsd').textContent, mSpend: $('mSpend').textContent, mSpendUsd: $('mSpendUsd').textContent, mAsOf: $('mAsOf').textContent, mLive: $('mLiveTxt').textContent, mKids: [...$('pMoney').children].filter(e => e.id !== 'livePop').map(e => e.className), popInMoney: !!$('pMoney').querySelector('#livePop #refreshNow'), mGone: ['mFx', 'mFunders', 'palletText', 'palletOn', 'bountyNote'].filter(i => $(i)), pill: $('dataPill').textContent, raw: { spend: stats.spend, items: stats.items, comm: stats.commission, fx: stats.fx },
    ordersGone: !document.getElementById('pOrders') && !document.getElementById('cargo') && !document.querySelector('#tabbar [data-tab=orders]')}));
  const fails = []; const eq = (n, a, e) => { if (a !== e) fails.push(`${n}: page "${a}" vs sheet "${e}"`); };
  if (G.shipCard.length) fails.push('Ship-tab money card still present: ' + G.shipCard); if (!G.popInMoney) fails.push('live popover / REFRESH NOW not on the Money tab'); eq('units (stats)', G.units, E.items.toLocaleString('en-US'));
  eq('lines · stores (stats)', G.ls, `${E.lines} · ${E.stores}`); eq('bounty US$', G.bounty, `≈ ${usd0(E.spend * 0.05 / FX)}`); eq('money tab spend', G.mSpend, brl(E.spend)); eq('money tab bounty R$ = 5% of spend', G.bountyBrl, brl(Math.round(E.spend * 0.05 * 100) / 100)); eq('money tab spent US$', G.mSpendUsd, `≈ ${usd0(E.spend / FX)}`);
  eq('money tab live', G.mLive, 'LIVE'); if (!/^· read \d{2} [A-Z][a-z]{2} \d{4}, \d{2}:\d{2} BRT$/.test(G.mAsOf)) fails.push('money tab read date: ' + G.mAsOf);
  eq('money tab blocks', JSON.stringify(G.mKids), JSON.stringify(['mHead', 'mBlock commission', 'mBlock'])); if (G.mGone.length) fails.push('money tab still has ' + G.mGone);
  if (Math.abs(G.raw.comm - G.raw.spend * 0.05) > 1e-9) fails.push('bounty != 5% of spend');
  if (Math.abs(G.raw.spend - E.spend) > 0.005) fails.push('raw spend ' + G.raw.spend + ' vs ' + E.spend); if (G.raw.fx !== 5.14) fails.push('fx ' + G.raw.fx);
  if (!G.ordersGone) fails.push('Orders tab / cargo list still present');
  console.log(JSON.stringify({ sheet: { spend: +E.spend.toFixed(2), commission: +(E.spend * 0.05).toFixed(2), units: E.items, lines: E.lines, stores: E.stores, usd: Math.round(E.spend / FX) }, page: G }, null, 0));
  fails.forEach(f => console.log('  FAIL ' + f)); console.log(fails.length ? 'FAIL money' : 'PASS money');
  await b.close(); process.exit(fails.length ? 1 : 0);
})().catch(e => { console.error(e); process.exit(2); });
