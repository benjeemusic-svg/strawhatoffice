// v4.3.2 (Law #1): all-routes sweep, every crew member from its station to every spot (Law's v43-review doorheads3 method):
// on every walking leg that is more sideways than vertical, a point outside a door column must not put the head above the room's
// top wall line (A11 clip) -> 0 flat-cut heads. Also reports legs where the sprite would be (almost) fully hidden.
// node tests/check_v432_doors.js [url]
const { chromium } = require(process.env.PW || '/workspace/pwtest/node_modules/playwright-core');
const URL = process.argv[2] || 'http://127.0.0.1:18796/index.html';
(async () => {
  const b = await chromium.launch({ executablePath: '/usr/bin/google-chrome', args: ['--no-sandbox'] }); const p = await b.newPage({ viewport: { width: 402, height: 874 } }); const errs = []; p.on('pageerror', e => errs.push(e.message));
  await p.goto(URL + '?phase=day'); await p.waitForFunction('typeof V4!=="undefined"&&V4.ready&&V4.phase', null, { timeout: 40000 }); await p.waitForTimeout(1500);
  const sweep = (force) => p.evaluate((force) => { const DX = V43_DX, clips = force ? () => true : v432Clips, over = [], spots = Object.keys(SPOTS), bad = [], full = []; let pts = 0, routes = 0;
    agents.forEach(o => { o.wait = 1e9; o.path = []; o.walking = false; });
    for (const a of agents) { const id = a.id, h = (V4M.characters[id] || {}).height || 44, st = SPOTS['st_' + id] || V4N['st_' + id]; if (!st) continue;
      for (const sp of spots) { a.x = st.x; a.y = st.y; a.path = []; try { routeTo(a, sp); } catch (e) { continue; } if (!a.path || !a.path.length) continue; routes++;
        let prev = { x: st.x, y: st.y }; for (const q of a.path) { const walk = !q.via || q.via === 'walk', n = Math.max(1, Math.ceil(Math.hypot(q.x - prev.x, q.y - prev.y)));
          if (walk && Math.abs(q.x - prev.x) > Math.abs(q.y - prev.y)) for (let i = 0; i <= n; i++) { const z = { x: prev.x + (q.x - prev.x) * i / n, y: prev.y + (q.y - prev.y) * i / n }; pts++;
            const rm = V4S.rooms[v4Room(z)]; if (!rm || !rm.floor || DX.some(x => Math.abs(x - z.x) <= 1)) continue; const c = rm.y - (Math.round(z.y) - h);
            if (c > 0) { if (!clips({ x: z.x, y: z.y })) { over.push([id, sp, c]); continue; } (c < h - 8 ? bad : full).push([id, sp, Math.round(z.x), Math.round(z.y), c]); } }
          prev = q; } } }
    const routesOf = L => { const u = {}; L.forEach(x => { const k = x[0] + '>' + x[1]; if (!u[k] || u[k][4] < x[4]) u[k] = x; }); return Object.values(u); };
    // Law's two examples
    const ex = [['law', 'st_usopp'], ['luffy', 'st_sanji']].map(([id, sp]) => { const a = agents.find(o => o.id === id), st = SPOTS['st_' + id]; a.x = st.x; a.y = st.y; a.path = []; routeTo(a, sp); return id + '>' + sp + ': ' + a.path.map(q => q.x + ',' + q.y).join(' '); });
    return { routes, pts, headOverRoomAbovePts: over.length, headOverRoomAboveRoutes: new Set(over.map(o => o[0] + '>' + o[1])).size, headOverMax: over.reduce((m, o) => Math.max(m, o[2]), 0), flatCut: routesOf(bad).length, flatCutPts: bad.length, worst: routesOf(bad).sort((u, v) => v[4] - u[4]).slice(0, 10), hiddenRoutes: routesOf(full).length, hiddenEx: routesOf(full).slice(0, 5), ex }; }, force);
  const R = await sweep(false), F = await sweep(true);
  console.log(JSON.stringify(R)); const fails = [];
  if (R.routes < 600) fails.push('only ' + R.routes + ' routes swept');
  if (R.flatCut || R.hiddenRoutes) fails.push(R.flatCut + ' routes with a flat-cut head (+' + R.hiddenRoutes + ' fully hidden) on a sideways leg');
  console.log('must-fail control (A11 clip forced everywhere): ' + F.flatCut + ' flat-cut routes');
  if (!F.flatCut) fails.push('must-fail control: forcing the old clip found no flat-cut heads (the sweep cannot fail)');
  errs.forEach(e => fails.push('page error: ' + e));
  fails.forEach(f => console.log('  FAIL ' + f)); console.log(fails.length ? 'FAIL door heads' : 'PASS door heads (' + R.routes + ' routes, ' + R.pts + ' points, 0 flat-cut heads)');
  await b.close(); process.exit(fails.length ? 1 : 0);
})().catch(e => { console.error(e); process.exit(2); });
