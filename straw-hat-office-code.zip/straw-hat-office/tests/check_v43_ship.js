// v4.3.1 (owner 00:16): the canvas is the whole Ship tab (sea above/below); the ship is rows V4.oy..V4.oy+620 of it and is checked as before.
// v4.3 (owner 23:19 + 23:48, Law 23:17): Ship tab = only the ship; Crew tab = crew status + BRAINSTORMS; no room plaques; no flat-cut heads.
// node tests/check_v43_ship.js [url]   (local server on the build folder; default http://127.0.0.1:18794/index.html)
const { chromium } = require(process.env.PW || '/workspace/pwtest/node_modules/playwright-core');
const URL = process.argv[2] || 'http://127.0.0.1:18794/index.html';
const ROOMS = /\b(HELM|CHARTS?|GALLEY|LIBRARY|SICKBAY|QA DESK|LOUNGE|WORKSHOP|CARGO( HOLD)?)\b/;
(async () => {
  const b = await chromium.launch({ executablePath: '/usr/bin/google-chrome', args: ['--no-sandbox'] }); const fails = [];
  const ctx = await b.newContext({ viewport: { width: 402, height: 874 }, deviceScaleFactor: 3, isMobile: true, hasTouch: true, timezoneId: 'America/Sao_Paulo' });
  const p = await ctx.newPage(); const errs = []; p.on('pageerror', e => errs.push(e.message));
  await p.goto(URL); await p.waitForFunction(() => typeof V4 !== 'undefined' && V4.ready, null, { timeout: 40000 }); await p.waitForTimeout(2500);
  // v4.3.2: the Ship tab opens at 4x; the whole-ship geometry below is checked at the 3x view (double-tap toggle)
  await p.evaluate(() => { if (typeof v4zSet === 'function') v4zSet(1, null, null, false); }); await p.waitForTimeout(100);
  const S = await p.evaluate((src) => { const ROOMS = new RegExp(src); const vis = e => { for (let q = e; q; q = q.parentElement) { const c = getComputedStyle(q); if (c.display === 'none' || c.visibility === 'hidden') return false; } return !!e.getClientRects().length; };
    const c = V4.cv.getBoundingClientRect(), t = $('tabbar').getBoundingClientRect(), w = $('stageWrap').getBoundingClientRect(), dpr = devicePixelRatio;
    const ship = $('colW'), txt = [...ship.querySelectorAll('*')].filter(e => vis(e) && e.children.length === 0 && ROOMS.test(e.textContent)).map(e => e.textContent.trim().slice(0, 30));
    const shown = [...ship.querySelectorAll('button,[role=button],input')].filter(vis).map(e => e.id || e.textContent.trim().slice(0, 20));
    return { k: V4.k, dpr, cw: c.width, ch: c.height * WH / V4.EH, left: c.left, right: c.right, top: c.top + V4.oy * c.height / V4.EH, bottom: c.top + (V4.oy + WH) * c.height / V4.EH, cvTop: c.top, cvBottom: c.bottom, oy: V4.oy, eh: V4.EH, wrapTop: w.top, tabTop: t.top, vw: innerWidth,
      gone: ['crewStrip', 'toolbar', 'soundBtn', 'brainBtn', 'csRow'].filter(id => document.getElementById(id)), roomText: txt, shipButtons: shown, plq: V41.plq.length,
      tabs: [...document.querySelectorAll('#tabbar button')].map(e => e.innerText.trim()) }; }, ROOMS.source);
  const fitW = Math.floor(S.vw * S.dpr / 402 + 1e-6), fitH = Math.floor((S.tabTop - S.wrapTop - 6) * S.dpr / 620 + 1e-6);
  if (S.k !== Math.min(fitW, fitH)) fails.push(`ship scale k=${S.k}, largest whole-number fit is ${Math.min(fitW, fitH)} (w ${fitW}, h ${fitH})`);
  if (S.bottom > S.tabTop + 0.5) fails.push(`ship bottom ${S.bottom} under the tab bar ${S.tabTop}`);
  if (Math.abs(S.left + S.right - S.vw) > 1.01) fails.push(`ship not centred horizontally: ${S.left}..${S.right}`);
  const gapTop = S.top - S.wrapTop, gapBot = S.tabTop - S.bottom; if (Math.abs(gapTop - gapBot) > 8) fails.push(`ship not centred vertically: ${gapTop.toFixed(1)} above, ${gapBot.toFixed(1)} below`);
  if (S.cvTop > S.wrapTop + 0.5 || S.wrapTop > 0.5 || S.tabTop - S.cvBottom > 0.5 || S.cvBottom > S.tabTop + 0.5) fails.push(`sea does not fill the Ship tab: canvas ${S.cvTop}..${S.cvBottom}, wrap top ${S.wrapTop}, tab bar ${S.tabTop}`);
  if (S.oy < 1) fails.push('no sea rows above the ship (oy ' + S.oy + ')');
  if (S.gone.length) fails.push('still in the page: ' + S.gone.join(', '));
  if (S.shipButtons.length) fails.push('Ship tab still shows controls: ' + S.shipButtons.join(', '));
  if (S.roomText.length) fails.push('room-name text on the Ship tab: ' + S.roomText.join(', '));
  if (S.plq) fails.push('runtime plaque list not empty: ' + S.plq);
  // v4.3.4: MARGINS is back as its own tab (owner 01:0x 'resume the Margins tab'), between MONEY and CREW as the v4.2 spec put it
  if (JSON.stringify(S.tabs) !== JSON.stringify(['SHIP', 'MONEY', 'MARGINS', 'CREW'])) fails.push('tab bar: ' + S.tabs);
  // Crew tab: crew status + legend + brainstorms
  await p.click('#tabbar button[data-tab="crew"]'); await p.waitForTimeout(600);
  const C = await p.evaluate(() => { const v = id => { const e = $(id); return !!(e && e.getClientRects().length && getComputedStyle(e).display !== 'none'); };
    return { crew: v('secCrew'), legend: v('crewLegend') && $('crewLegend').textContent.trim(), brain: v('secBrain'), brainText: ($('brainArea').innerText || '').trim().slice(0, 60), roster: document.querySelectorAll('#roster .crew').length }; });
  if (!C.crew || !C.roster) fails.push('Crew tab: crew status missing'); if (C.legend !== 'Red glow = needs your decision') fails.push('Crew tab legend: ' + C.legend);
  if (!C.brain || !C.brainText) fails.push('Crew tab: BRAINSTORMS view missing/empty');
  // doors: after a door the bot steps straight down until its sprite clears the wall line (no flat-cut head out in the room)
  const D = await p.evaluate(() => { const bad = []; const H = V43_H, cols = V43_DX; const ids = ['nami', 'frankie', 'zoro', 'brook'];
    const targets = Object.keys(SPOTS).filter(k => !/^st_/.test(k) || true);
    ids.forEach(id => { const a = agents.find(q => q.id === id); const s0 = SPOTS['st_' + id]; targets.forEach(k => { a.x = s0.x; a.y = s0.y; a.at = s0; a.path = []; try { routeTo(a, SPOTS[k]); } catch (e) { return; }
      let prev = { x: a.x, y: a.y }; (a.path || []).forEach(q => { if (!q.via || q.via === 'walk') { for (let f = 0; f <= 1.0001; f += 0.05) { const x = Math.round(prev.x + (q.x - prev.x) * f), y = Math.round(prev.y + (q.y - prev.y) * f);
        const r = V4S.rooms[v4Room({ x, y })]; if (r && r.floor && y - r.y < H + 1 && !cols.some(c => Math.abs(c - x) <= 1) && Math.abs(q.x - prev.x) > 3 && (Math.abs(prev.x - cols.find(c => Math.abs(c - prev.x) <= 1) || 99) <= 1 || cols.some(c => Math.abs(c - q.x) <= 1))) bad.push(id + '->' + k + ' at ' + x + ',' + y); } } prev = q; }); }); });
    return { n: bad.length, ex: bad.slice(0, 6) }; });
  if (D.n) fails.push(`door legs with a cut head out in the room: ${D.n} (${D.ex.join('; ')})`);
  errs.forEach(e => fails.push('page error: ' + e));
  console.log(JSON.stringify({ ship: S, crew: C, doors: D }));
  fails.forEach(f => console.log('  FAIL ' + f)); console.log(fails.length ? 'FAIL v43 ship' : 'PASS v43 ship');
  await b.close(); process.exit(fails.length ? 1 : 0);
})().catch(e => { console.error(e); process.exit(2); });
