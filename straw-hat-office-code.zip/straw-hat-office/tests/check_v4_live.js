// v4 stage 1 / v4.1: crew strip, TOP DEAL chip and the crew-status gate follow live /crew.json (https, mocked).  node tests/check_v4_live.js
const { chromium } = require('/workspace/pwtest/node_modules/playwright-core');
const fs = require('fs'), path = require('path');
const ROOT = path.join(__dirname, '..'), html = fs.readFileSync(path.join(ROOT, 'index.html'), 'utf8');
const p2 = n => String(n).padStart(2, '0'), d0 = new Date(Date.now() - 3 * 3600e3 - 10 * 60e3); // BRT wall clock, 10 min ago
const NOW = `${d0.getUTCFullYear()}-${p2(d0.getUTCMonth() + 1)}-${p2(d0.getUTCDate())} ${p2(d0.getUTCHours())}:${p2(d0.getUTCMinutes())}`;
const row = (id, state, extra = {}) => Object.assign({ crew_id: id, status: 'MOCK ' + id, state, decision: '', event_type: '', event_id: '', event_at: '', event_text: '', discount: '', updated_at: '2026-10-18 16:40' }, extra);
const mock = { synced_at: '2026-10-18T16:40:00-03:00', source: 'mock', tabs: {
  CREW_STATUS: [row('chopper', 'resting'), row('frankie', 'offline'), row('law', 'working', { decision: 'MOCK: approve?' }),
    row('sanji', 'working', { event_type: 'deal_found', event_id: 'd1', event_at: NOW, event_text: 'MOCK OP09 booster box R$ 1,234 (18% under avg)', discount: '18' }), row('nami', 'idle')],
  JOBS: [], SUMMARIES: [], BRIEFING: [], NEWS: [], BRAINSTORMS: [], CREW_CHAT: [] } };
(async () => {
  const b = await chromium.launch({ executablePath: '/usr/bin/google-chrome', args: ['--no-sandbox'] });
  const ctx = await b.newContext({ viewport: { width: 402, height: 874 }, deviceScaleFactor: 3, isMobile: true, hasTouch: true, timezoneId: 'America/Sao_Paulo' });
  const page = await ctx.newPage(); const errs = [];
  page.on('pageerror', e => errs.push(e.message));
  await page.route('https://straw-hat-office.test/**', r => new URL(r.request().url()).pathname === '/crew.json'
    ? r.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(mock) }) : r.fulfill({ status: 200, contentType: 'text/html', body: html }));
  await page.goto('https://straw-hat-office.test/'); await page.waitForTimeout(9000);
  const got = await page.evaluate(() => ({ dots: Object.fromEntries([...document.querySelectorAll('#roster .crew')].map(c => [c.dataset.id, ((c.querySelector('.dot4') || {}).className || '').replace('dot4', '').trim()])) /* v4.3: the Ship-tab strip is gone; the Crew-tab roster carries the dots */,
    chip: $('dealChip') ? $('dealChip').textContent : null, comm: $('bounty').textContent, commExp: fmtBRL(stats.commission), note: $('crewSrc').textContent.replace(/^·\s*/, ''), pill: $('dataPill').textContent,
    crewlive: document.body.classList.contains('crewlive'), statusShown: [...document.querySelectorAll('#roster .crew .now')].filter(e => /^MOCK /.test(e.textContent)).length, decisions: (() => { const d = document.getElementById('decisions'); return d && !d.hidden ? [...d.querySelectorAll('.decItem')].map(e => e.textContent) : null; })(), flagged: [...document.querySelectorAll('#roster .crew.needs')].map(e => e.dataset.id) }));
  console.log(JSON.stringify({ ...got, errs }));
  const ok = got.dots.chopper === 'resting' && got.dots.frankie === 'resting' && got.dots.law === 'working' && got.dots.luffy === 'resting' && got.dots.nami === 'idle' && got.dots.sanji === 'working'
    && got.chip === null /* owner 23:05: no TOP DEAL chip, the Ship-tab card is gone */ && got.comm === got.commExp && /^synced 16:40$/.test(got.note)
    && got.crewlive && got.statusShown >= 5 && JSON.stringify(got.decisions) === JSON.stringify(['LawMOCK: approve?']) && JSON.stringify(got.flagged) === '["law"]' && !errs.length;
  await page.screenshot({ path: '/workspace/frankie-review/shots-v4.3/tests/live-crewjson-iphone.png' });
  // an old deal_found row (3 days ago) is not current -> MY COMMISSION
  mock.tabs.CREW_STATUS[3].event_at = '2026-10-15 10:00';
  const p2g = await ctx.newPage(); await p2g.route('https://straw-hat-office.test/**', r => new URL(r.request().url()).pathname === '/crew.json'
    ? r.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(mock) }) : r.fulfill({ status: 200, contentType: 'text/html', body: html }));
  await p2g.goto('https://straw-hat-office.test/'); await p2g.waitForTimeout(9000);
  await p2g.waitForFunction(() => VAULT.shown === VAULT.target, null, { timeout: 10000 });
  const old = await p2g.evaluate(() => ({ chipHidden: !$('dealChip'), comm: $('bounty').textContent, commExp: fmtBRL(stats.commission), bounty: $('bounty').textContent }));
  console.log(JSON.stringify(old));
  const ok2 = old.chipHidden && old.comm === old.bounty && old.comm === old.commExp;
  await b.close(); console.log(ok && ok2 ? 'PASS' : 'FAIL'); process.exit(ok && ok2 ? 0 : 1);
})();
