// v4.3.4 (owner: "resume the Margins tab"): the MARGINS tab against the LIVE tracker, Robin's US COMPS tab (CSV export, read in Node).
// - every current-pallet product with a US COMPS row is listed, and its latest row's cost US$ (D), TCGplayer US$ (F), margin % (I),
//   confidence (J) and TCGplayer link (G) are on screen exactly as in the sheet (nothing recomputed by the app, nothing invented);
// - Robin's column I is recomputed here: I = (F - D*1.05) / (D*1.05) * 100, within 0.1 on every row;
// - R$ line: ours = column C as is, TCG = F x 5.14, plus 'checked <day>' from column A;
// - footnote text; tab bar SHIP · MONEY · MARGINS · CREW, every tab >= 44x44 CSS px; no sideways overflow at 402x874; tabular digits; no page errors.
// node tests/check_v434_margins.js [url] [screenshot.png]
const { chromium } = require(process.env.PW || '/workspace/pwtest/node_modules/playwright-core');
const URL = process.argv[2] || 'http://127.0.0.1:18834/index.html', SHOT = process.argv[3] || '';
const ID = '125TloDi-xWce5NyGbKupJELfDkSGgJnguE3MZJepa_U', GID = '1509506030';
function csv(t){const R=[];let r=[],f='',q=false;for(let i=0;i<t.length;i++){const c=t[i];if(q){if(c==='"'){if(t[i+1]==='"'){f+='"';i++;}else q=false;}else f+=c;}
  else if(c==='"')q=true;else if(c===','){r.push(f);f='';}else if(c==='\n'){r.push(f.replace(/\r$/,''));R.push(r);r=[];f='';}else f+=c;}if(f||r.length){r.push(f);R.push(r);}return R;}
const usd = n => 'US$ ' + n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
(async () => {
  const fails = []; const all = csv(await (await fetch(`https://docs.google.com/spreadsheets/d/${ID}/export?format=csv&gid=${GID}&_=${Date.now()}`)).text());
  const H = all[0].map(s => s.trim().toLowerCase()); if (H[0] !== 'date' || H[1] !== 'product' || !/^margin/.test(H[8])) fails.push('US COMPS headers changed: ' + H);
  const rows = all.slice(1).filter(r => (r[1] || '').trim());
  // Robin's margin formula, recomputed on every row that has D, F and I
  let nI = 0; rows.forEach((r, i) => { const D = parseFloat(r[3]), F = parseFloat(r[5]), I = parseFloat(r[8]); if (!(isFinite(D) && isFinite(F) && isFinite(I))) return; nI++;
    const c = (F - D * 1.05) / (D * 1.05) * 100; if (Math.abs(c - I) > 0.1) fails.push(`row ${i + 2} ${r[1]}: I=${I} but (F-D*1.05)/(D*1.05)*100=${c.toFixed(2)}`); });
  if (!nI) fails.push('no US COMPS row with D, F and I to recompute');
  const latest = {}; rows.forEach((r, i) => { const p = r[1].trim(), d = r[0].trim(); if (!latest[p] || d >= latest[p].d) latest[p] = { d, r, row: i + 2 }; });
  const b = await chromium.launch({ executablePath: '/usr/bin/google-chrome', args: ['--no-sandbox'] });
  const ctx = await b.newContext({ viewport: { width: 402, height: 874 }, deviceScaleFactor: 3, isMobile: true, hasTouch: true, timezoneId: 'America/Sao_Paulo' });
  const p = await ctx.newPage(); const errs = []; p.on('pageerror', e => errs.push(e.message));
  await p.goto(URL); await p.waitForFunction(() => typeof stats !== 'undefined' && stats && typeof V42 !== 'undefined' && V42.live && V4.ready, null, { timeout: 40000 });
  await p.tap('#tabbar button[data-tab="margins"]'); await p.waitForTimeout(800);
  const S = await p.evaluate(() => {
    const tabs = [...document.querySelectorAll('#tabbar button')].map(e => { const r = e.getBoundingClientRect(); return { t: e.textContent.trim(), w: r.width, h: r.height, l: r.left, r: r.right }; });
    const items = [...document.querySelectorAll('#mgList .mg')].map(a => ({ p: a.dataset.p, light: a.dataset.light, href: a.getAttribute('href'), pct: a.querySelector('.mgPct').textContent,
      conf: [...a.querySelectorAll('.mgConf,.mgTag')].map(e => e.textContent).join('|'), ours: a.querySelector('.mgB.ours>span:last-child').textContent, tcg: a.querySelector('.mgB.tcg>span:last-child').textContent,
      rs: [...a.querySelectorAll('.mgR')].map(e => e.textContent).join(' | '), h: a.getBoundingClientRect().height, num: getComputedStyle(a.querySelector('.mgPct')).fontVariantNumeric }));
    const vis = document.getElementById('pMargins').getBoundingClientRect();
    return { tab: document.body.dataset.tab, tabs, items, pallet: v42Pallet(stats), unmatched: V42.unmatched, foot: document.querySelector('#pMargins .mgFoot').textContent,
      sw: document.documentElement.scrollWidth, bw: document.body.scrollWidth, vw: innerWidth, panel: { l: vis.left, r: vis.right, w: vis.width } };
  });
  if (S.tab !== 'margins') fails.push('MARGINS tab did not open: ' + S.tab);
  if (JSON.stringify(S.tabs.map(t => t.t)) !== JSON.stringify(['SHIP', 'MONEY', 'MARGINS', 'CREW'])) fails.push('tab bar: ' + S.tabs.map(t => t.t));
  S.tabs.forEach(t => { if (t.w < 44 || t.h < 44) fails.push(`tab ${t.t} ${t.w.toFixed(1)}x${t.h.toFixed(1)} < 44`); if (t.l < -0.5 || t.r > S.vw + 0.5) fails.push(`tab ${t.t} off screen`); });
  if (S.sw > S.vw || S.bw > S.vw || S.panel.r > S.vw + 0.5 || S.panel.l < -0.5) fails.push(`sideways overflow: doc ${S.sw}, body ${S.bw}, panel ${S.panel.l}..${S.panel.r}`);
  if (S.foot.trim() !== 'margin = TCG vs our cost + 5% commission, before shipping & fees') fails.push('footnote: ' + S.foot);
  const expect = S.pallet.filter(x => latest[x.trim()]);
  if (JSON.stringify(S.items.map(i => i.p)) !== JSON.stringify(expect)) fails.push(`listed ${JSON.stringify(S.items.map(i => i.p))} != pallet products with US COMPS rows ${JSON.stringify(expect)}`);
  S.items.forEach(it => { const L = latest[it.p]; if (!L) return; const r = L.r, D = parseFloat(r[3]), F = parseFloat(r[5]), I = parseFloat(r[8]), J = (r[9] || '').trim().toLowerCase();
    const want = { ours: isFinite(D) ? usd(D) : 'no data', tcg: isFinite(F) ? usd(F) : 'no data', pct: isFinite(I) ? I.toLocaleString('en-US', { maximumFractionDigits: 1 }) + '%' : '–', href: /^https:\/\/(www\.)?tcgplayer\.com\//.test(r[6] || '') ? r[6].trim() : null };
    for (const k of Object.keys(want)) if (it[k] !== want[k]) fails.push(`row ${L.row} ${it.p} ${k}: page "${it[k]}" sheet "${want[k]}"`);
    const brl = n => 'R$ ' + n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }), C = parseFloat(r[2]);
    const M = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'], day = +L.d.slice(8, 10) + ' ' + M[+L.d.slice(5, 7) - 1] + ' ' + L.d.slice(0, 4);
    const wantR = [isFinite(C) ? 'ours ' + brl(C) : null, isFinite(F) ? 'TCG ≈ ' + brl(F * 5.14) : null].filter(Boolean).join(' · ') + ' | Robin checked ' + day;
    if (it.rs !== wantR) fails.push(`row ${L.row} ${it.p} R$/date line: page "${it.rs}" sheet "${wantR}"`);
    if (J && !it.conf.toLowerCase().includes(J[0] === 'm' ? 'medium' : J)) fails.push(`row ${L.row} ${it.p} confidence: page "${it.conf}" sheet "${J}"`);
    if (it.h < 44) fails.push(`${it.p} tap target ${it.h}px < 44`); if (!/tabular-nums/.test(it.num)) fails.push(`${it.p} margin % not tabular digits`); });
  if (errs.length) fails.push('page errors: ' + errs.join(' | '));
  if (SHOT) { await p.evaluate(() => window.scrollTo(0, 0)); await p.screenshot({ path: SHOT }); }
  console.log(JSON.stringify({ sheetRows: rows.length, recomputedI: nI, items: S.items, unmatched: S.unmatched, tabs: S.tabs, sw: S.sw }));
  await b.close(); if (fails.length) { fails.forEach(f => console.log('  FAIL ' + f)); console.log('FAIL v434 margins'); process.exit(1); } console.log('PASS v434 margins (' + S.items.length + ' products, ' + nI + ' rows recomputed within 0.1)');
})().catch(e => { console.log('FAIL', e); process.exit(1); });
