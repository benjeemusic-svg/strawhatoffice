# v3.1.3 checks for Law's v3.1.2 findings (N1-N5, C2). Run with a Playwright python env:
#   /workspace/law-qa/.venv/bin/python tests/check_v313.py   (serves ./index.html itself through page.route)
import asyncio, json, os, sys, time, datetime as dt
from playwright.async_api import async_playwright
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
HTML=open(os.path.join(ROOT,"index.html"),encoding="utf8").read()
OUT=os.environ.get("QA_OUT","/workspace/pixel-office-qa/v313"); os.makedirs(OUT,exist_ok=True)
BRT=dt.timezone(dt.timedelta(hours=-3))
UA="Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Mobile/15E148 Safari/604.1"
IPHONE=dict(viewport={"width":402,"height":874},device_scale_factor=3,is_mobile=True,has_touch=True,user_agent=UA,timezone_id="America/Sao_Paulo")
HOST="https://straw-hat-office.test/"
MOCK={"synced_at":"2026-10-18T16:40:00-03:00","source":"mock","tabs":{
 "CREW_STATUS":[{"crew_id":"chopper","status":"MOCK: watching Liga","state":"working","updated_at":"2026-10-18 16:40"}],
 "JOBS":[{"job_id":"J-mock-1","posted_at":"2026-10-18 16:00","task":"MOCK job","assignee":"frankie","status":"doing"}],
 "SUMMARIES":[],"BRIEFING":[],"NEWS":[{"headline":"MOCK headline","source":"mock","link":"","date":"2026-10-18"}],
 "BRAINSTORMS":[],"CREW_CHAT":[{"time":"2026-10-18 16:41","from":"chopper","to":"robin","message":"mock","event_ref":"","kind":"handoff"}]}}
RES=[]
def rec(name,ok,detail): RES.append((name,bool(ok),detail)); print(("PASS " if ok else "FAIL ")+name+" :: "+json.dumps(detail,default=str)[:600],flush=True)
async def new_page(b,args,state,sheet="abort"):
    ctx=await b.new_context(**args); page=await ctx.new_page(); errs=[]
    page.on("pageerror",lambda e: errs.append("pageerror: "+str(e)))
    page.on("console",lambda m: errs.append(m.type+": "+m.text) if m.type in("error","warning") else None)
    async def site(r):
        u=r.request.url
        if u.split("?")[0].endswith("/crew.json"):
            m=state.get("crew","good")
            if m=="good": return await r.fulfill(status=200,content_type="application/json",body=json.dumps(MOCK))
            if m=="badsync": return await r.fulfill(status=200,content_type="application/json",body=json.dumps(dict(MOCK,synced_at="not-a-date")))
            return await r.fulfill(status=404,content_type="application/json",body='{"error":"not_synced"}')
        return await r.fulfill(status=200,content_type="text/html",body=HTML)
    await page.route(HOST+"**",site)
    async def g(r):
        if sheet=="abort": return await r.abort()
        if sheet=="hang": return  # never answered
        if sheet=="gviz-abort-csv-hang":
            if "/gviz/" in r.request.url: return await r.abort()
            return
        return await r.continue_()
    await page.route("https://docs.google.com/**",g)
    return ctx,page,errs
T=lambda s: dt.datetime.fromisoformat(s).replace(tzinfo=BRT)
STATE="""()=>({meal:MEAL?MEAL.name:null,banner:!!banners.meal,meet:MEETING.active?MEETING.kind:null,log:logEntries.slice().sort((a,b)=>logMs(b)-logMs(a)).slice(0,4).map(e=>e.who+': '+e.text)})"""
async def clock_case(b,name,start,steps,pre=None):
    ctx,page,errs=await new_page(b,dict(IPHONE),{})
    await page.clock.install(time=T(start)); await page.goto(HOST); await page.clock.run_for(4000)
    if pre: await page.evaluate(pre)
    out=[]
    for (at,check) in steps:
        now=await page.evaluate("Date.now()"); target=T(at.lstrip("+")).timestamp()*1000
        if at.startswith("+"): await page.clock.run_for(int(target-now))   # run every frame/timer (meetings advance per frame)
        elif target>now: await page.clock.fast_forward(int(target-now))
        await page.clock.run_for(1000)
        s=await page.evaluate(STATE); s["at"]=at; s["ok"]=check(s); out.append(s)
    await ctx.close()
    rec(name, all(s["ok"] for s in out) and not [e for e in errs if "pageerror" in e or e.startswith("error")], {"steps":out,"errs":errs[:5]})
async def main():
    async with async_playwright() as p:
        wk=await p.webkit.launch(); cr=await p.chromium.launch()
        # ---------- N1: life schedule actually runs (fake clock, BRT) ----------
        ev=lambda: None
        await page_fn_check(wk)
        await clock_case(wk,"N1 breakfast 08:00-08:30 (Mon)","2026-10-19T07:59:00",[
            ("2026-10-19T07:59:40",lambda s:s["meal"] is None and not s["banner"]),
            ("2026-10-19T08:00:21",lambda s:s["meal"]=="Breakfast" and s["banner"]),
            ("2026-10-19T08:29:40",lambda s:s["meal"]=="Breakfast" and s["banner"]),
            ("2026-10-19T08:30:21",lambda s:s["meal"] is None and not s["banner"])])
        await clock_case(wk,"N1 lunch 12:00-13:00","2026-10-19T11:59:00",[
            ("2026-10-19T11:59:40",lambda s:s["meal"] is None),
            ("2026-10-19T12:00:21",lambda s:s["meal"]=="Lunch" and s["banner"]),
            ("2026-10-19T13:00:21",lambda s:s["meal"] is None and not s["banner"])])
        await clock_case(wk,"N1 dinner 19:00-20:00","2026-10-19T18:59:00",[
            ("2026-10-19T18:59:40",lambda s:s["meal"] is None),
            ("2026-10-19T19:00:21",lambda s:s["meal"]=="Dinner" and s["banner"]),
            ("2026-10-19T20:00:21",lambda s:s["meal"] is None and not s["banner"])])
        await clock_case(wk,"N1 weekday morning meeting 09:00 (Mon) starts and ends","2026-10-19T08:59:00",[
            ("2026-10-19T08:59:40",lambda s:s["meet"] is None),
            ("2026-10-19T09:00:21",lambda s:s["meet"]=="morning"),
            ("+2026-10-19T09:03:00",lambda s:s["meet"] is None and any("Morning crew meeting" in l for l in s["log"]))])
        await clock_case(wk,"N1 no meeting on Saturday 09:00","2026-10-24T08:59:00",[
            ("2026-10-24T09:00:21",lambda s:s["meet"] is None),("2026-10-24T09:05:00",lambda s:s["meet"] is None)])
        await clock_case(wk,"N1 Friday MVP ceremony 16:00 (with a stubbed real delivery) starts and ends","2026-10-23T15:59:00",[
            ("2026-10-23T15:59:40",lambda s:s["meet"] is None),
            ("2026-10-23T16:00:21",lambda s:s["meet"]=="ceremony"),
            ("+2026-10-23T16:03:00",lambda s:s["meet"] is None and any("Weekly MVP ceremony at the mast" in l for l in s["log"]))],pre="weeklyMVP=()=>({a:agents.find(a=>a.id==='nami'),n:2})")
        await clock_case(wk,"N1 Friday 16:00 with no deliveries logs 'ceremony skipped' (honesty rule)","2026-10-23T15:59:00",[
            ("2026-10-23T16:00:21",lambda s:s["meet"] is None and any("ceremony skipped" in l for l in s["log"]))])
        await clock_case(wk,"N1b manual 'Serve a meal' banner ends at 60s","2026-10-19T15:00:00",[
            ("2026-10-19T15:00:05",lambda s:s["meal"]=="Snack" and s["banner"]),
            ("2026-10-19T15:00:55",lambda s:s["meal"]=="Snack" and s["banner"]),
            # serveMeal runs at ~15:00:04 (after the 4s warm-up): 60s later = 15:01:04 (v3.1.3 N1b one-off timer; was ~60-80s via the 20s poll)
            ("2026-10-19T15:01:06",lambda s:s["meal"] is None and not s["banner"])],pre="serveMeal('Snack')")
        # ---------- N2: OFFLINE at ~12s (real clock) ----------
        for eng,b in (("webkit",wk),("chromium",cr)):
            for mode in ("hang","gviz-abort-csv-hang","abort"):
                ctx,page,errs=await new_page(b,dict(IPHONE) if eng=="webkit" else dict(viewport={"width":1280,"height":800}),{},sheet=mode)
                t0=time.time(); await page.goto(HOST,wait_until="commit")
                await page.wait_for_function("document.getElementById('dataPill').textContent.indexOf('OFFLINE')>=0",timeout=40000)
                t=round(time.time()-t0,1); pill=await page.text_content("#dataPill"); items=await page.text_content("#mSpend")
                lim=(10.5,14.5) if mode!="abort" else (0,4)
                rec(f"N2 OFFLINE timing {eng} {mode}",lim[0]<=t<=lim[1] and items.strip()!="–" and not [e for e in errs if "pageerror" in e],{"t_s":t,"pill":pill,"items":items,"errs":errs[:3]})
                await ctx.close()
        # ---------- N3 / N4: crew.json ----------
        for eng,b in (("webkit",wk),("chromium",cr)):
            st={"crew":"badsync"}; ctx,page,errs=await new_page(b,dict(IPHONE),st)
            await page.goto(HOST); await page.wait_for_function("FEEDS.crew&&FEEDS.jobs&&FEEDS.news&&document.getElementById('dataPill').className.indexOf('load')<0",timeout=30000); await page.wait_for_timeout(1500)
            i=await page.evaluate("()=>({pill:dataPill.textContent,crew:FEEDS.crew.note,jobs:FEEDS.jobs.note,news:FEEDS.news.note,chopper:agents.find(a=>a.id==='chopper').status,stale:CREW_STALE})")
            rec(f"N3 invalid synced_at {eng}", "time unknown" in i["crew"] and i["jobs"].startswith("crew.json") and i["news"].startswith("crew.json") and i["chopper"].startswith("MOCK") and "SYNCED" not in i["pill"] and not [e for e in errs if "RangeError" in e or "refresh failed" in e or "pageerror" in e],{"info":i,"errs":errs[:3]})
            await ctx.close()
            st={"crew":"good"}; ctx,page,errs=await new_page(b,dict(IPHONE),st)
            await page.goto(HOST); await page.wait_for_function("document.getElementById('dataPill').textContent.indexOf('CREW SYNCED')>=0",timeout=30000)
            Q="()=>({pill:dataPill.textContent,crew:FEEDS.crew.note,crewRows:FEEDS.crew.rows.length,jobsRows:FEEDS.jobs.rows.length,news:FEEDS.news.note,chat:FEEDS.chat.rows.length,chopper:agents.find(a=>a.id==='chopper').status,stale:CREW_STALE})"
            a=await page.evaluate(Q); st["crew"]="404"
            await page.evaluate("refresh(false)"); await page.wait_for_function("!REFRESHING",timeout=30000); await page.wait_for_timeout(300)
            s=await page.evaluate(Q); await page.screenshot(path=f"{OUT}/n4-stale-{eng}.png")
            st["crew"]="good"; await page.evaluate("refresh(false)"); await page.wait_for_function("!REFRESHING",timeout=30000); await page.wait_for_timeout(300)
            c=await page.evaluate(Q)
            ok=("CREW SYNCED 16:40 BRT" in a["pill"] and "CREW SYNC STALE 16:40 BRT" in s["pill"] and "SYNCED" not in s["pill"].replace("SYNC STALE","") and s["crewRows"]==1 and s["jobsRows"]==1 and s["chat"]==1 and s["chopper"].startswith("MOCK") and "stale" in s["crew"] and s["stale"]
                and "CREW SYNCED 16:40 BRT" in c["pill"] and not c["stale"] and "stale" not in c["crew"])
            rec(f"N4 stale after later crew.json failure {eng}",ok and not [e for e in errs if "pageerror" in e],{"before":a,"after404":s,"recovered":c,"errs":errs[:3]})
            await ctx.close()
        # ---------- N5 ----------
        ctx,page,errs=await new_page(wk,dict(IPHONE),{})
        await page.goto(HOST); await page.wait_for_timeout(1500)
        r=await page.evaluate("""()=>{const f=v=>{const d=parseDate(v);return d?d.toISOString().slice(0,10):null};
          return {n46305:f(46305),n46305_25:f(46305.25),n46305_5:f(46305.5),n46305_99:f(46305.99),s46305:f("46305"),s46305_75:f("46305.75"),s123456:f("123456"),s1234567:f(" 1234567 "),n123456:f(123456),dmy:f("10/10/2026"),gviz:f("Date(2026,9,10)")}}""")
        rec("N5 serial dates floor + reject 6-digit text",r=={"n46305":"2026-10-10","n46305_25":"2026-10-10","n46305_5":"2026-10-10","n46305_99":"2026-10-10","s46305":"2026-10-10","s46305_75":"2026-10-10","s123456":None,"s1234567":None,"n123456":None,"dmy":"2026-10-10","gviz":"2026-10-10"},r)
        await ctx.close()
        # ---------- C2 (v4.1: the guild header + subtitle are gone; the same "nothing clipped / no h-scroll" check covers the Money tab blocks; the Ship-tab money card was removed by the owner 23:05) ----------
        TC="""()=>{const cells=[...document.querySelectorAll('#pMoney .mHead,#pMoney .mBlock,#pMoney .mBlock>div')];
          return {clipped:cells.filter(e=>e.scrollWidth>e.clientWidth+1).map(e=>e.className+':'+e.textContent.trim().slice(0,30)),card:Math.round($('pMoney').getBoundingClientRect().height),n:cells.length,docSW:document.documentElement.scrollWidth,W:innerWidth}}"""
        for eng,b in (("webkit",wk),("chromium",cr)):
            for w,h in ((1280,800),(1440,900),(1180,800)):
                ctx,page,errs=await new_page(b,dict(viewport={"width":w,"height":h}),{})
                await page.goto(HOST); await page.wait_for_timeout(2500)
                m=await page.evaluate(TC); await page.locator("#pMoney").screenshot(path=f"{OUT}/c2-money-{eng}-{w}.png")
                rec(f"C2 money blocks not clipped {eng} {w}",m["n"]>=5 and not m["clipped"] and m["docSW"]<=m["W"],m); await ctx.close()
        ctx,page,errs=await new_page(wk,dict(IPHONE),{}); await page.goto(HOST); await page.wait_for_timeout(2500); await page.click("#tabbar button[data-tab=money]"); await page.wait_for_timeout(400)
        m=await page.evaluate(TC); await page.locator("#pMoney").screenshot(path=f"{OUT}/c2-money-webkit-iphone.png")
        rec("C2 iPhone Money tab not clipped",m["n"]>=5 and not m["clipped"] and m["docSW"]<=m["W"],m); await ctx.close()
        await wk.close(); await cr.close()
    fails=[n for n,o,_ in RES if not o]; print(f"\n{len(RES)-len(fails)}/{len(RES)} passed"); json.dump(RES,open(f"{OUT}/check_v313.json","w"),indent=1,default=str)
    sys.exit(1 if fails else 0)
async def page_fn_check(b):
    ctx,page,errs=await new_page(b,dict(IPHONE),{}); await page.goto(HOST); await page.wait_for_timeout(1500)
    r=await page.evaluate("()=>({life:typeof lifeSchedule,lifeCallsMeal:String(lifeSchedule).includes('mealCheck'),frame:String(schedule).includes('requestAnimationFrame')})")
    rec("N1 two distinct functions (lifeSchedule + frame schedule)",r["life"]=="function" and r["lifeCallsMeal"] and r["frame"],r); await ctx.close()
asyncio.run(main())
