// v4.1 owner MUST: money on screen instantly (no "–" for ~10 s) on a slow phone connection, from the baked snapshot or the browser's last live numbers.
// 1) slow 3G (CDP throttling, 400 kbit/s, 400 ms RTT), Sheet unreachable: the Money tab (#mSpend, #bounty) shows R$ long before the page finishes loading.
// 2) cache newer than the snapshot: first paint uses it. 3) every US$ figure uses 5.14.
const {chromium}=require('/workspace/pwtest/node_modules/playwright-core');
const URL=process.argv[2]||'http://127.0.0.1:18790/index.html';let fail=0;const ok=(n,c,d)=>{console.log((c?'PASS ':'FAIL ')+n+(d!==undefined?' '+JSON.stringify(d):''));if(!c)fail++;};
(async()=>{const b=await chromium.launch({executablePath:'/usr/bin/google-chrome'});
 { const ctx=await b.newContext({viewport:{width:402,height:874},deviceScaleFactor:3,isMobile:true,hasTouch:true});const p=await ctx.newPage();
   await p.route(/docs\.google\.com|googleusercontent|raw\.githubusercontent/,r=>r.abort());
   const cdp=await ctx.newCDPSession(p);await cdp.send('Network.enable');await cdp.send('Network.emulateNetworkConditions',{offline:false,latency:400,downloadThroughput:400*1024/8,uploadThroughput:400*1024/8});
   const t0=Date.now();let tMoney=null,tLoad=null,early=null,tTab=null,earlyTab=null;p.on('load',()=>{tLoad=Date.now()-t0;});
   p.goto(URL,{waitUntil:'commit',timeout:120000}).catch(()=>{});
   while(Date.now()-t0<90000){const v=await p.evaluate(()=>{const e=document.getElementById('mSpend');const g=i=>(document.getElementById(i)||{}).textContent;return e?[e.textContent,g('mSpendUsd'),g('bounty'),g('bounty'),g('bountyUsd'),g('mSpend'),g('mSpendUsd'),typeof stats!=='undefined'&&!!stats]:null;}).catch(()=>null);
     if(v&&/^R\$/.test(v[0])&&tMoney==null){tMoney=Date.now()-t0;early=v;await p.screenshot({path:'/workspace/frankie-review/shots-v4.1/v41-slow3g-first-paint.png'}).catch(()=>{});}
     if(v&&/^R\$/.test(v[3]||'')&&!v[7]&&tTab==null){tTab=Date.now()-t0;earlyTab=v.slice(3,7);}
     if(tMoney!=null&&tLoad!=null)break;await new Promise(r=>setTimeout(r,100));}
   await p.waitForFunction('typeof stats!=="undefined"&&stats',null,{timeout:60000});await p.waitForTimeout(500);
   const fin=await p.evaluate(()=>[$('mSpend').textContent,$('mSpendUsd').textContent,$('bounty').textContent,$('mSpendUsd').textContent,$('dataPill').textContent,stats.fx,$('bounty').textContent,$('bountyUsd').textContent,$('mSpend').textContent]);
   ok('slow 3G: money visible before the page has loaded',tMoney!=null&&(tLoad==null||tMoney<tLoad-2000),{msMoney:tMoney,msLoad:tLoad});
   ok('slow 3G: money visible within 4 s',tMoney!=null&&tMoney<4000,{msMoney:tMoney});
   ok('first-paint texts = the final rendered texts (no jump)',early&&early[0]===fin[0]&&early[1]===fin[1]&&early[2]===fin[2],{early:early&&early.slice(0,3),fin:fin.slice(0,3)});
   ok('Money tab painted before the app script ran, same texts as the final render',tTab!=null&&earlyTab[0]===fin[6]&&earlyTab[1]===fin[7]&&earlyTab[2]===fin[8]&&earlyTab[3]===fin[3],{tTab,earlyTab,fin:fin.slice(6).concat([fin[3]])});
   ok('US$ at partner rate 5.14 everywhere',fin[5]===5.14&&fin[3]===fin[1],fin);
   ok('offline pill says numbers as of',/OFFLINE · NUMBERS AS OF/.test(fin[4]),fin[4]);
   const usd=await p.evaluate(()=>{const s=stats,spend=s.spend,c=s.commission;return {spendUsd:$('mSpendUsd').textContent,want:"≈ "+fmtUSD(spend/5.14),bounty:$('bountyUsd').textContent,wantB:"≈ "+fmtUSD(c/5.14)};});
   ok('spent / bounty US$ = R$ ÷ 5.14',usd.spendUsd===usd.want&&usd.bounty===usd.wantB,usd);
   await ctx.close(); }
 { const ctx=await b.newContext({viewport:{width:402,height:874}});const p=await ctx.newPage();await p.route(/docs\.google\.com|googleusercontent|raw\.githubusercontent/,r=>r.abort());
   await p.goto(URL);await p.evaluate(()=>localStorage.setItem('pixelOffice.money41',JSON.stringify({at:Date.now(),rows:[["Test Store","EB05 CASE",3,30000]],summary:[],t:{mSpend:"R$ 30,000.00",mSpendUsd:"≈ US$ 5,837",bounty:"R$ 1,500.00",bountyUsd:"≈ US$ 292"}})));
   let first=null;p.on('domcontentloaded',async()=>{});
   await p.addInitScript(()=>{document.addEventListener('readystatechange',()=>{},{once:true});new MutationObserver((m,o)=>{const e=document.getElementById('mSpend');if(e&&e.textContent!=="–"&&!window.__first){window.__first=e.textContent;o.disconnect();}}).observe(document,{subtree:true,childList:true,characterData:true});});
   await p.reload();await p.waitForFunction('typeof stats!=="undefined"&&stats',null,{timeout:60000});await p.waitForTimeout(500);
   const r=await p.evaluate(()=>({first:window.__first,spend:$('mSpend').textContent,pill:$('dataPill').textContent,usd:$('mSpendUsd').textContent}));
   ok('newer browser cache wins over the baked snapshot (first paint and offline fallback)',r.first==="R$ 30,000.00"&&r.spend==="R$ 30,000.00"&&r.usd==="≈ US$ 5,837",r);
   await ctx.close(); }
 await b.close();console.log(fail?'FAIL instant-money':'PASS instant-money');process.exit(fail?1:0);})();
