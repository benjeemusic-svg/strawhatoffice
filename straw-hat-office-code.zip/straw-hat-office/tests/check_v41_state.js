// v4.1 (Law/owner 20:53): the shown state always comes from CREW STATUS `state` (working/idle/resting; blank = resting), even if the
// browser's old v4 energy value is 0 (the v4 bug: a simulated nap flag showed "resting" over state=working). The decision column
// (blank = none, text = the question) drives "Needs your decision". A later sync is picked up on the next refresh.  node tests/check_v41_state.js
const { chromium } = require(process.env.PW || '/workspace/pwtest/node_modules/playwright-core');
const fs = require('fs'), path = require('path');
const html = fs.readFileSync(path.join(__dirname, '..', 'index.html'), 'utf8');
// fixture = the live CREW STATUS shape at 20:56 BRT (states/decisions as in the sheet; texts shortened)
const R = (crew_id, state, status, decision = '') => ({ crew_id, status, state, decision, event_type: '', event_id: '', event_at: '', event_text: '', discount: '', updated_at: '2026-10-18T20:50-03:00' });
let rows = [R('luffy', 'working', 'Rolling out the crew status habit'), R('nami', 'working', 'Coordinating interface upgrades'), R('zoro', 'idle', 'Tracking Oct pallet', 'Which orders were the 3 delivered parcels?'),
  R('usopp', 'idle', 'Release calendar up to date'), R('sanji', 'working', 'Building store scores'), R('chopper', 'idle', 'Watching 5 Liga pages'), R('robin', 'idle', 'Idle until the daily US price check'),
  R('brook', '', 'Standing by'), R('jinbe', 'idle', 'Waiting on funder transfers', 'Which date is the 5.14 rate from?'), R('frankie', 'working', 'Building v4.1 clean-up update'), R('law', 'working', 'Reviewing live v4')];
const body = () => JSON.stringify({ synced_at: '2026-10-18T20:50:00-03:00', source: 'test', tabs: { CREW_STATUS: rows, JOBS: [], SUMMARIES: [], BRIEFING: [], NEWS: [], BRAINSTORMS: [], CREW_CHAT: [], RELEASES: [], PALLET: [] } });
const want = id => { const s = (rows.find(r => r.crew_id === id) || {}).state || ''; return s === 'working' ? 'Working' : s === 'idle' ? 'Idle' : 'Resting'; };
(async () => {
  const b = await chromium.launch({ executablePath: process.env.CHROME || '/usr/bin/google-chrome', args: ['--no-sandbox'] });
  const ctx = await b.newContext({ viewport: { width: 402, height: 874 }, deviceScaleFactor: 3, isMobile: true, hasTouch: true, timezoneId: 'America/Sao_Paulo' });
  const page = await ctx.newPage(); const errs = []; page.on('pageerror', e => errs.push(e.message));
  await ctx.addInitScript(() => { try { ['luffy', 'nami', 'zoro', 'usopp', 'sanji', 'chopper', 'robin', 'brook', 'jinbe', 'frankie', 'law'].forEach(id => localStorage.setItem('pixelOffice.energy.' + id, '0')); } catch (e) {} });
  await page.route('https://straw-hat-office.test/**', r => new URL(r.request().url()).pathname === '/crew.json'
    ? r.fulfill({ status: 200, contentType: 'application/json', body: body() }) : r.fulfill({ status: 200, contentType: 'text/html', body: html }));
  await page.goto('https://straw-hat-office.test/'); await page.waitForTimeout(9000);
  const read = () => page.evaluate(() => ({ words: Object.fromEntries([...document.querySelectorAll('#roster .crew')].map(c => [c.dataset.id, (c.querySelector('.stw') || {}).textContent || null])) /* v4.3: strip removed; roster state words */,
    roster: Object.fromEntries([...document.querySelectorAll('#roster .crew')].map(c => [c.dataset.id, (c.querySelector('.stw') || {}).textContent || null])),
    dec: [...document.querySelectorAll('#decisions .decItem')].map(e => e.dataset.id), dotsBright: getComputedStyle(document.querySelector('#roster .dot4')).filter }));
  const fails = []; const check = (tag, g) => {
    for (const id of Object.keys(g.words)) { if (g.words[id] !== want(id)) fails.push(`${tag}: strip ${id} shows ${g.words[id]}, sheet says ${want(id)}`); if (g.roster[id] !== want(id)) fails.push(`${tag}: roster ${id} shows ${g.roster[id]}`); }
    const d = rows.filter(r => r.decision).map(r => r.crew_id).sort(); if (JSON.stringify([...g.dec].sort()) !== JSON.stringify(d)) fails.push(`${tag}: decisions ${g.dec} != ${d}`); };
  const g1 = await read(); check('first load', g1);
  if (!/brightness/.test(g1.dotsBright)) fails.push('dots not brightened: ' + g1.dotsBright);
  // next sync: Frankie goes idle, Zoro's decision is answered, Brook starts working -> one refresh later the page matches
  rows = rows.map(r => r.crew_id === 'frankie' ? { ...r, state: 'idle' } : r.crew_id === 'zoro' ? { ...r, decision: '' } : r.crew_id === 'brook' ? { ...r, state: 'working' } : r);
  await page.evaluate(() => refresh(false)); await page.waitForTimeout(4000);
  const g2 = await read(); check('after next sync', g2);
  errs.forEach(e => fails.push('page error: ' + e));
  console.log(JSON.stringify({ first: g1.words, after: g2.words, decAfter: g2.dec }));
  fails.forEach(f => console.log('  FAIL ' + f)); console.log(fails.length ? 'FAIL' : 'PASS');
  await b.close(); process.exit(fails.length ? 1 : 0);
})().catch(e => { console.error(e); process.exit(2); });
