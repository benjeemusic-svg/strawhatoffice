// v4.1 unit tests for Law's V4-1..V4-4 (date parsing never throws, zoneless wall clock = BRT, BR prices, DD/MM keeps time).
// Runs the functions extracted from the BUILT index.html in a Node vm, once per time zone set through the TZ env var:
//   node tests/check_v41_units.js            (spawns itself with TZ=America/Sao_Paulo, UTC, America/New_York, America/Los_Angeles, Asia/Tokyo, Pacific/Kiritimati)
const fs = require('fs'), path = require('path'), vm = require('vm'), { spawnSync } = require('child_process');
const ZONES = ['America/Sao_Paulo', 'UTC', 'America/New_York', 'America/Los_Angeles', 'Asia/Tokyo', 'Pacific/Kiritimati'];
if (!process.env.V41_CHILD) {
  let fails = 0, total = 0; const rows = [];
  for (const tz of ZONES) {
    const r = spawnSync(process.execPath, [__filename], { env: { ...process.env, TZ: tz, V41_CHILD: '1' }, encoding: 'utf8' });
    const out = (r.stdout || '').trim().split('\n').filter(Boolean).map(l => { try { return JSON.parse(l); } catch (e) { return { name: 'parse', pass: false, got: l }; } });
    if (r.status !== 0 && !out.length) out.push({ name: 'child crashed', pass: false, got: r.stderr });
    out.forEach(o => { total++; if (!o.pass) { fails++; console.log('FAIL', tz, o.name, JSON.stringify(o.got)); } });
    rows.push([tz, out.filter(o => o.pass).length + '/' + out.length, (new Date(2026, 9, 18).getTimezoneOffset === undefined) ? '' : out.length && out[0].tzOffset]);
  }
  rows.forEach(r => console.log(r[0].padEnd(22), r[1], 'viewer offset(min):', r[2]));
  console.log(`${total - fails}/${total} passed`); process.exit(fails ? 1 : 0);
}
const html = fs.readFileSync(path.join(__dirname, '..', 'index.html'), 'utf8');
const cut = (a, b) => { const i = html.indexOf(a), j = html.indexOf(b, i); if (i < 0 || j < 0) throw new Error('marker not found: ' + a); return html.slice(i, j); };
const src = 'const CONFIG={tz:"America/Sao_Paulo"};\n' + cut('/* v4.1 (Law V4-1/V4-2)', 'const fmtDay') + '\n' + cut('/* v4.1 (V4-3)', '/* ONE number source') + '\n'
  + 'let FEEDS={};' + cut('const V4_DEAL_MAX_AGE', ';') + ';\n' + cut('function v4TopDeal(){', 'function v4State(') + '\nthis.T={asDate,parseDate,fmtTime,okDate,num,numMoney,v4TopDeal,setFeeds:f=>{FEEDS=f;}};';
const ctx = {}; vm.createContext(ctx); vm.runInContext(src.replace(/^const |^let /gm, m => m), ctx); const T = ctx.T;
const off = new Date(Date.UTC(2026, 9, 18, 12)).getTimezoneOffset();
const iso = d => d ? d.toISOString() : null;
const res = []; const t = (name, fn) => { let got, pass = false; try { got = fn(); pass = got === true || (Array.isArray(got) && got[0] === true); } catch (e) { got = 'THREW ' + e.message; } res.push({ name, pass, got, tzOffset: off }); };
// ---- V4-1: never throws, the bad value shows "time unknown"
const bad = ['18/10/2026 19:31x', 'garbage', '32/13/2026 25:61', '31/02/2026 10:00', '2026-13-40 10:00', 'Date(abc)', NaN, Infinity, {}, [], new Date('x'), true, '   ', '46305abc'];
t('V4-1 fmtTime/asDate/parseDate never throw on bad input', () => { const out = bad.map(v => [T.fmtTime(v), T.fmtTime(v, true), iso(T.asDate(v)), iso(T.parseDate(v))]); return [out.every(o => o[0] === 'time unknown' && o[1] === 'time unknown' && o[2] === null && o[3] === null), out]; });
t('V4-1 Law case "18/10/2026 19:31" formats (no RangeError)', () => { const s = T.fmtTime('18/10/2026 19:31'); return [s === '19:31 BRT', s]; });
t('V4-1 okDate is false for bad, true for good', () => [!T.okDate('garbage') && !T.okDate('18/10/2026 19:61') && T.okDate('18/10/2026 19:31') && T.okDate('2026-10-18T16:40:00-03:00'), 0]);
// ---- V4-2: zoneless wall clock = -03:00 in every viewer zone
const W = [['2026-10-18 19:31', '2026-10-18T22:31:00.000Z'], ['2026-10-18T19:31', '2026-10-18T22:31:00.000Z'], ['2026-10-18 19:31:45', '2026-10-18T22:31:45.000Z'], ['18/10/2026 19:31', '2026-10-18T22:31:00.000Z'],
  ['18/10/2026 23:30', '2026-10-19T02:30:00.000Z'], ['1/2/2026 0:05', '2026-02-01T03:05:00.000Z'], ['2026-10-18T19:31:00-03:00', '2026-10-18T22:31:00.000Z'], ['2026-10-18T22:31:00Z', '2026-10-18T22:31:00.000Z'], ['Date(2026,9,18,19,31,0)', '2026-10-18T22:31:00.000Z']];
W.forEach(([v, e]) => t(`V4-2 "${v}" -> ${e}`, () => { const g = iso(T.parseDate(v)); return [g === e, g]; }));
t('V4-2 fmtTime shows the BRT wall clock back', () => { const a = T.fmtTime('2026-10-18 19:31'), b = T.fmtTime('18/10/2026 19:31', true); return [a === '19:31 BRT' && b === '18 Oct 2026, 19:31 BRT', [a, b]]; });
// ---- V4-2/V4-3 on the TOP DEAL card (real v4TopDeal from 6_v4.js)
const p2 = n => String(n).padStart(2, '0'), brtWall = (msAgo, fmt) => { const d = new Date(Date.now() - msAgo - 3 * 3600e3); const Y = d.getUTCFullYear(), M = p2(d.getUTCMonth() + 1), D = p2(d.getUTCDate()), h = p2(d.getUTCHours()), m = p2(d.getUTCMinutes());
  return fmt === 'dmy' ? `${D}/${M}/${Y} ${h}:${m}` : `${Y}-${M}-${D} ${h}:${m}`; };
const deal = (at, text = 'OP09 booster box R$ 1,234 (18% under avg)', discount = '18') => { T.setFeeds({ crew: { ok: true, rows: [{ crew_id: 'chopper', event_type: 'deal_found', event_at: at, event_text: text, discount }] } }); return T.v4TopDeal().deal; };
for (const fmt of ['ymd', 'dmy']) {
  t(`V4-2 TOP DEAL ${fmt} wall clock 10 min old is current`, () => { const d = deal(brtWall(10 * 60e3, fmt)); return [!!d, d && iso(d.at)]; });
  t(`V4-2 TOP DEAL ${fmt} wall clock 23h58 old is current`, () => { const d = deal(brtWall(23 * 3600e3 + 58 * 60e3, fmt)); return [!!d, d && iso(d.at)]; });
  t(`V4-2 TOP DEAL ${fmt} wall clock 24h02 old has expired`, () => { const d = deal(brtWall(24 * 3600e3 + 2 * 60e3, fmt)); return [!d, d && iso(d.at)]; });
}
const P = [['OP09 box R$ 1.234,56 (18% under avg)', 1234.56], ['OP09 box R$1,234.56 18% under', 1234.56], ['OP17 case R$ 11.200 · 22% below avg', 11200], ['OP17 case R$11,200, 22% below', 11200], ['EB05 R$ 950,00 (16% off)', 950], ['EB05 R$ 950.', 950], ['box R$ 12.345.678,90', 12345678.9], ['no price, 18% below', null]];
P.forEach(([txt, e]) => t(`V4-3 TOP DEAL price "${txt}" = ${e}`, () => { const d = deal(brtWall(5 * 60e3), txt); return [!!d && d.price === e, d && d.price]; }));
const N = [['R$ 1.234,56', 1234.56], ['R$1,234.56', 1234.56], ['R$121,366.63', 121366.63], ['R$ 121.366,63', 121366.63], ['US$2,146.56', 2146.56], ['11,200', 11200], ['12,5', 12.5], ['12.5', 12.5], ['18%', 18], ['-18', -18], ['0', 0], ['n/a', null], ['', null], ['#N/A', null], [46305, 46305], ['1.234.567', 1234567]];
t('V4-3 num() reads BR and US formats', () => { const g = N.map(([v, e]) => [v, T.num(v), e]).filter(x => x[1] !== x[2]); return [g.length === 0, g]; });
// ---- V4-4: DD/MM/YYYY keeps its time; date-only stays UTC midnight of that day (pallet filter unchanged)
t('V4-4 "18/10/2026 19:31" keeps 19:31 BRT', () => { const g = iso(T.parseDate('18/10/2026 19:31')); return [g === '2026-10-18T22:31:00.000Z', g]; });
t('V4-4 date-only "08/10/2026" and "2026-10-08" = UTC midnight 8 Oct', () => { const a = iso(T.parseDate('08/10/2026')), b = iso(T.parseDate('2026-10-08')), c = iso(T.parseDate(46303)); return [a === '2026-10-08T00:00:00.000Z' && b === a && c === a, [a, b, c]]; });
t('V4-4 24h age of a DD/MM deal is exact (not off by up to a day)', () => { const d = deal(brtWall(23 * 3600e3, 'dmy')); const age = d && (Date.now() - d.at.getTime()) / 3600e3; return [!!d && Math.abs(age - 23) < 0.02, age]; });
res.forEach(r => console.log(JSON.stringify(r)));
