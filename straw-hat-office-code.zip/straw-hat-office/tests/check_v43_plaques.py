"""v4.3 (owner 23:19): the room plaques are painted out of ship_<phase>.png and glow_<phase>.png (lit LOUNGE copy), with wall pixels (no gaps).
For each removed plaque rect: no transparent pixel, and every pixel is a colour of the wall beside the sign on the same row
(in the v4.1 art), so no sign face, border or letter is left.   python3 tests/check_v43_plaques.py"""
import io,json,os,subprocess,sys
from collections import Counter
from PIL import Image
R=os.path.join(os.path.dirname(os.path.abspath(__file__)),'..');os.chdir(R)
rects=json.load(open('art/v4/world/plaques-removed.json'));fails=[]
names={r['text'] for r in rects};want={'HELM','CHARTS','GALLEY','LIBRARY','SICKBAY','QA DESK','LOUNGE','WORKSHOP','CARGO'}
if names!=want: fails.append(f'plaques covered {sorted(names)} != {sorted(want)}')
for lay,ph in [('ship',p) for p in ('day','dusk','night','storm')]+[('glow',p) for p in ('dusk','night','storm')]:
  old=Image.open(io.BytesIO(subprocess.check_output(['git','show',f'786bf07:art/v4/world/{lay}_{ph}.png']))).convert('RGBA')
  new=Image.open(f'art/v4/world/{lay}_{ph}.png').convert('RGBA')
  for r in rects:
    box=(r['x'],r['y'],r['x']+r['w'],r['y']+r['h'])
    holes=0;alien=0
    for y in range(box[1],box[3]):
      wall={old.getpixel((x,y)) for x in list(range(box[0]-24,box[0]))+list(range(box[2],box[2]+24)) if 0<=x<old.width}
      for x in range(box[0],box[2]):
        c=new.getpixel((x,y));holes+=(c[3]<255 and lay=='ship');alien+=c not in wall and not (lay=='glow' and c[3]==0)
    if alien: fails.append(f'{lay} {ph} {r["text"]}: {alien} px that are not this row wall colours (sign/text left)')
    if holes: fails.append(f'{lay} {ph} {r["text"]}: {holes} transparent px')
  ch=sum(1 for a,b in zip(old.get_flattened_data(),new.get_flattened_data()) if a!=b); outside=0
  M=Image.new('1',new.size,0);[M.paste(1,(r['x'],r['y'],r['x']+r['w'],r['y']+r['h'])) for r in rects]
  outside=sum(1 for (a,b,m) in zip(old.get_flattened_data(),new.get_flattened_data(),M.get_flattened_data()) if a!=b and not m)
  if outside: fails.append(f'{lay} {ph}: {outside} px changed outside the plaque rects')
  print(lay,ph,'changed px',ch,'outside rects',outside)
for f in fails: print('  FAIL',f)
print('FAIL plaques' if fails else 'PASS plaques'); sys.exit(1 if fails else 0)
