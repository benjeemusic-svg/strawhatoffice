// v4.1 (owner via Nami 21:56): every bubble or line that describes what a bot is doing comes ONLY from that bot's own CREW STATUS row
// (`status` / `event_text`, matched by crew_id). A blank row shows nothing about work. Everything else a bot says must be neutral chatter
// from its own VOICE table. Also static: no hard-coded "doing" text in src/.   node tests/check_v41_ownrow.js
const { chromium } = require(process.env.PW || '/workspace/pwtest/node_modules/playwright-core');
const fs = require('fs'), path = require('path');
const root = path.join(__dirname, '..'), html = fs.readFileSync(path.join(root, 'index.html'), 'utf8'); const fails = [];
// static: the reported stale text and the v4 per-spot "doing" phrases never reach a bubble source
const src = fs.readdirSync(path.join(root, 'src')).filter(f => /\.(js|html|json)$/.test(f)).map(f => [f, fs.readFileSync(path.join(root, 'src', f), 'utf8')]);
for (const [f, s] of src) { if (/one tile at a time/i.test(s)) fails.push('static: stale placeholder text in src/' + f); if (/\{task\}|\{item\}/.test(s) && f === '4_voice.js' && /:"[^"]*\{(task|item)\}/.test(s)) fails.push('static: voice line repeats a task/item in ' + f); }
for (const f of ['snapshot.json', 'src/status.json']) { const s = fs.readFileSync(path.join(root, f), 'utf8'); if (/one tile at a time/i.test(s)) fails.push('static: placeholder text in ' + f); }
const st = JSON.parse(fs.readFileSync(path.join(root, 'src/status.json'), 'utf8')); st.agents.forEach(a => { if (String(a.status || '').trim()) fails.push('static: status.json has a built-in status for ' + a.id); });
const R = (crew_id, status, extra = {}) => Object.assign({ crew_id, status, state: status ? 'working' : '', decision: '', event_type: '', event_id: '', event_at: '', event_text: '', discount: '', updated_at: new Date(Date.now() - 5 * 60000).toISOString() }, extra);
const IDS = ['luffy', 'nami', 'zoro', 'usopp', 'sanji', 'chopper', 'robin', 'brook', 'jinbe', 'frankie', 'law'];
let rows = IDS.map(id => R(id, ['robin', 'brook'].includes(id) ? '' : 'OWN-ROW ' + id + ' task text'));
rows = rows.map(r => r.crew_id === 'chopper' ? { ...r, event_type: 'deal_found', event_id: 'own-1', event_at: new Date().toISOString(), event_text: 'OWN-EVENT chopper OP09 box', discount: '18' } : r);
const body = () => JSON.stringify({ synced_at: new Date().toISOString(), source: 'test', tabs: { CREW_STATUS: rows, JOBS: [], SUMMARIES: [], BRIEFING: [], NEWS: [], BRAINSTORMS: [], CREW_CHAT: [], RELEASES: [], PALLET: [] } });
(async () => {
  const b = await chromium.launch({ executablePath: process.env.CHROME || '/usr/bin/google-chrome', args: ['--no-sandbox'] });
  const ctx = await b.newContext({ viewport: { width: 402, height: 874 }, deviceScaleFactor: 3, isMobile: true, hasTouch: true, timezoneId: 'America/Sao_Paulo' });
  const page = await ctx.newPage(); const errs = []; page.on('pageerror', e => errs.push(e.message));
  await page.route(/docs\.google\.com/, r => r.abort());
  await page.route('https://straw-hat-office.test/**', r => new URL(r.request().url()).pathname === '/crew.json'
    ? r.fulfill({ status: 200, contentType: 'application/json', body: body() }) : r.fulfill({ status: 200, contentType: 'text/html', body: html }));
  await page.goto('https://straw-hat-office.test/'); await page.waitForTimeout(8000);
  const sample = () => page.evaluate(() => agents.map(a => ({ id: a.id, text: String(bubbleText(a, performance.now()) || '').trim(), status: a.status || '', ev: a.event && a.event.text || '', word: STATE_LABEL[v4State(a)], anim: a.anim ? a.anim.type : null, own: !!(a.anim && a.anim.own !== false) })));
  // which texts a bot may say that are NOT its own row: its own voice lines (templates -> regex), neutral EVENTS labels
  const allow = await page.evaluate(() => { const o = {}; const flat = v => typeof v === 'string' ? [v] : Array.isArray(v) ? v.flatMap(flat) : v && typeof v === 'object' ? Object.values(v).flatMap(flat) : [];
    Object.keys(VOICE).forEach(id => o[id] = flat(VOICE[id])); o._labels = Object.values(EVENTS).map(e => e.label); return o; });
  const rx = t => new RegExp('^' + t.replace(/[.*+?^$()|[\]\\]/g, '\\$&').replace(/\{[a-z]+\}/g, '.+') + '$');
  const ok = (s) => {
    const t = s.text.replace(/^☎ needs a decision! /, '').trim(); if (!t) return true;
    const own = rows.find(r => r.crew_id === s.id) || {};
    if (t === String(own.status || '').trim()) return true;                                 // own status
    if (own.event_text && t.endsWith(own.event_text)) return true;                         // own event (label + own event_text)
    if ((allow[s.id] || []).some(v => rx(v).test(t))) return true;                         // own neutral voice line
    if (allow._labels.some(l => t === l)) return true;                                      // neutral event label with no text
    if (['Working', 'Idle', 'Resting'].includes(t) && t === s.word) return true;            // own `state` word (blank status)
    return false; };
  const seen = {}; const check = (tag, S) => S.forEach(s => {
    if (!s.text) return; (seen[s.id] = seen[s.id] || new Set()).add(s.text);
    if (!ok(s) && !fails.includes(`${tag}: ${s.id} bubble "${s.text}" is not its own row or own voice line`)) fails.push(`${tag}: ${s.id} bubble "${s.text}" is not its own row or own voice line`);
    rows.forEach(r => { if (r.crew_id !== s.id && r.status && s.text.includes(r.status)) fails.push(`${tag}: ${s.id} shows ${r.crew_id}'s status`); }); });
  // 1) idle bubbles: each bot's own row; blank row -> no work text
  const S0 = await sample(); check('load', S0);
  for (const s of S0) { const own = rows.find(r => r.crew_id === s.id); if (!s.anim && s.status !== own.status) fails.push(`load: ${s.id} status "${s.status}" != own row "${own.status}"`); }
  for (const id of ['robin', 'brook']) { const s = S0.find(x => x.id === id); if (s.status) fails.push(id + ' has a work text with a blank row: ' + s.status); }
  // 2) 40 s of normal life (events, combos, meals, vault replay), every bubble sampled
  await page.evaluate(() => { try { replayLastPurchase && replayLastPurchase(); } catch (e) {} });
  for (let i = 0; i < 160; i++) { check('life', await sample()); await page.waitForTimeout(250); }
  // 3) next sync: Frankie's row goes blank, Robin gets a row -> one refresh later the bubbles follow
  rows = rows.map(r => r.crew_id === 'frankie' ? { ...r, status: '' } : r.crew_id === 'robin' ? { ...r, status: 'OWN-ROW robin reading the price list' } : r);
  await page.evaluate(() => refresh(false)); await page.waitForTimeout(4000);
  const S2 = await sample(); check('after sync', S2);
  if (S2.find(s => s.id === 'frankie').status) fails.push('frankie keeps an old status after the row went blank');
  if (S2.find(s => s.id === 'robin').status !== 'OWN-ROW robin reading the price list') fails.push('robin did not pick up her own new row');
  // 4) the fixed screenshot: Robin hovered, bubble = her own row
  await page.evaluate(() => { const a = agents.find(x => x.id === 'robin'); agents.forEach(x => { x.path = []; x.walking = false; x.wait = 1e9; x.anim = null; x.say = null; x.combo = null; }); hoverRaw = a; hoverAgent = a; });
  await page.waitForTimeout(900);
  const robinBub = await page.evaluate(() => { const a = agents.find(x => x.id === 'robin'); return a._stEl ? a._stEl.textContent : ''; });
  if (robinBub.trim() !== 'OWN-ROW robin reading the price list') fails.push('robin hover bubble: ' + robinBub);
  await page.screenshot({ path: process.env.SHOT || '/workspace/frankie-review/shots-v4.1/v41-iphone16pro-robin-own-row.png' });
  errs.forEach(e => fails.push('page error: ' + e));
  console.log(JSON.stringify({ bubblesSeen: Object.fromEntries(Object.entries(seen).map(([k, v]) => [k, [...v]])), robinBub }));
  fails.forEach(f => console.log('  FAIL ' + f)); console.log(fails.length ? 'FAIL own-row' : 'PASS own-row');
  await b.close(); process.exit(fails.length ? 1 : 0);
})().catch(e => { console.error(e); process.exit(2); });
