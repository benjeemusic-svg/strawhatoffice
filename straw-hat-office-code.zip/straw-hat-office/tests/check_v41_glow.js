// v4.1: pixel proof that wall glow (aquarium windows, lamp pools, screen light) is painted UNDER the crew.
// Law's t50_depth "GLOW over sprite" rule is geometric (sprite box overlaps a glow rect at night). This test renders the real frame
// and checks the sprite's own pixels: with the glow layer on (A) and off (C) they must be identical; any glow drawn on top would change them.
// Usage: node tests/check_v41_glow.js [url]   (needs a local server; default http://127.0.0.1:18790/index.html)
const {chromium}=require('/workspace/pwtest/node_modules/playwright-core');
const URL=process.argv[2]||'http://127.0.0.1:18790/index.html';
const CASES=[ // positions taken from Law's t50 GLOW hits (agent, x, y) + phase
 ['night','brook',[[228,438],[249,440],[271,441],[306,444]]],['dusk','jinbe',[[222,455],[245,450],[267,445],[270,444]]],
 ['night','frankie',[[101,555],[89,539],[76,522]]],['night','sanji',[[97,301],[86,300]]],['night','robin',[[308,305],[317,304],[322,302]]],
 ['night','frankie',[[189,441],[187,431],[187,421]]],['dusk','frankie',[[189,441],[187,431],[187,421]]]]; // v4.3: Law 23:17, aquarium window by the door3L doorway
// v4.3.1: the canvas is taller than the world (sea above/below), so window reads are offset by V4.oy rows.
// Must-fail control (Frankie 00:21): the same check with the glow layer forced OVER the crew (re-painted after the frame) must report changed sprite pixels.
async function run(b,cases,over){let fail=0;const rows=[];
 for(const [ph,id,pts] of cases){const p=await b.newPage({viewport:{width:402,height:874},deviceScaleFactor:3});
  await p.goto(URL+'?phase='+ph);await p.waitForFunction('typeof V4!=="undefined"&&V4.ready&&V4.phase');await p.waitForTimeout(800);
  const r=await p.evaluate(([id,pts,over])=>{const ph=V4.phase,P=v41Pieces(ph),k=V4.cv.width/WW,g=V4.g;
    agents.forEach(o=>{o.wait=1e9;o.path=[];o.walking=false;o.anim=null;o.combo=null;o.say=null;if(o.id!==id){o.x=-300;o.y=-300;}});
    const a=agents.find(o=>o.id===id),h=(V4M.characters[id]||{}).height||44,T=123456,out=[],oy=V4.oy||0;
    if(pts==='auto')pts=P.bg.filter(q=>q.y>0).sort((u,v)=>(v.x1-v.x)*(v.y1-v.y)-(u.x1-u.x)*(u.y1-u.y)).slice(0,3).map(q=>[Math.round((q.x+q.x1)/2),Math.round((q.y+q.y1)/2+h/2)]); // sprite parked on the biggest wall-glow pieces
    const draw=()=>{V4.lastKey=null;drawV4(T,0);if(over&&P.bg.length){g.setTransform(1,0,0,1,0,oy);P.bg.forEach(q=>g.drawImage(q.c,q.x,q.y));g.setTransform(1,0,0,1,0,0);}};
    const shot=(x,y,glow)=>{a.x=x;a.y=y;const bg=P.bg;if(!glow)P.bg=[];try{draw();}finally{P.bg=bg;}
      return g.getImageData(Math.round((x-12)*k),Math.round((y-h-4+oy)*k),Math.round(24*k),Math.round((h+4-4)*k)).data;}; // stop 4 rows above the feet (drop shadow)
    for(const [x,y] of pts){const A=shot(x,y,true),B=shot(-300,-300,true),C=shot(x,y,false),D=shot(-300,-300,false);
      // B/D are the same window with the sprite gone: re-read them at (x,y)'s window
      a.x=-300;a.y=-300;draw();const Bw=g.getImageData(Math.round((x-12)*k),Math.round((y-h-4+oy)*k),Math.round(24*k),Math.round(h*k)).data;
      const bgs=P.bg;P.bg=[];draw();const Dw=g.getImageData(Math.round((x-12)*k),Math.round((y-h-4+oy)*k),Math.round(24*k),Math.round(h*k)).data;P.bg=bgs;
      let n=0,bad=0,glowPx=0;for(let i=0;i<A.length;i+=4){const sA=A[i]!==Bw[i]||A[i+1]!==Bw[i+1]||A[i+2]!==Bw[i+2],sC=C[i]!==Dw[i]||C[i+1]!==Dw[i+1]||C[i+2]!==Dw[i+2];
        if(Bw[i]!==Dw[i]||Bw[i+1]!==Dw[i+1]||Bw[i+2]!==Dw[i+2])glowPx++;
        if(sC){n++; /* v4.3.1: sprite pixels come from the glow-OFF pair only; with sA&&sC an opaque glow painted over the sprite hid itself (A==Bw) and was never counted */if(A[i]!==C[i]||A[i+1]!==C[i+1]||A[i+2]!==C[i+2])bad++;}}
      out.push({x,y,spritePx:n,glowPxInWindow:glowPx,spritePxChangedByGlow:bad,geomOverGlow:v41GlowOver(a).length});}
    return out;},[id,pts,over]);
  r.forEach(o=>{rows.push({ph,id,...o});if(o.spritePxChangedByGlow>0||o.spritePx<50)fail++;});await p.close();}
 return {fail,rows,anyGlow:rows.some(o=>o.glowPxInWindow>0)};}
(async()=>{const b=await chromium.launch({executablePath:'/usr/bin/google-chrome'});
 const N=await run(b,CASES,false);N.rows.forEach(o=>console.log(JSON.stringify(o)));
 const ok=!N.fail&&N.anyGlow;
 console.log(ok?'PASS glow-under-crew ('+N.rows.length+' positions, glow present in window, 0 sprite pixels changed by glow)':'FAIL glow-under-crew');
 // must-fail: glow forced over the crew on the night cases -> the checker has to catch it
 const AUTO=[['night','brook','auto'],['night','frankie','auto'],['dusk','jinbe','auto']];
 const U=await run(b,AUTO,false);console.log((U.fail?'FAIL':'PASS')+' glow-under-crew on the glow pieces themselves ('+U.rows.length+' positions, '+U.fail+' flagged)');
 const F=await run(b,AUTO,true),changed=F.rows.reduce((s,o)=>s+o.spritePxChangedByGlow,0);
 const caught=F.fail>0&&changed>0;F.rows.forEach(o=>console.log('forced '+JSON.stringify(o)));
 console.log(caught?'PASS must-fail control (glow forced over crew: '+changed+' sprite pixels changed, '+F.fail+'/'+F.rows.length+' positions flagged)':'FAIL must-fail control: glow drawn over the crew was NOT detected');
 await b.close();process.exit(ok&&!U.fail&&caught?0:1);})();
