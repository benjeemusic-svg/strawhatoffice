// v4.3.2 Law #2: a blanked decision / state cell in crew.json clears on refresh (Jinbe stops ringing, Luffy is no longer Working).
// Law #3: every visible number (read time, 5% label, synced HH:MM, NEEDS YOUR DECISION (n), status times) uses tabular digits, not the pixel font.
// Plus: the idea board on the visible ship opens the BRAINSTORMS board.   node tests/check_v432_feeds.js
const { chromium } = require(process.env.PW || '/workspace/pwtest/node_modules/playwright-core');
const fs = require('fs'), path = require('path'); const html = fs.readFileSync(path.join(__dirname, '..', 'index.html'), 'utf8');
const IDS = ['luffy', 'nami', 'zoro', 'usopp', 'sanji', 'chopper', 'robin', 'brook', 'jinbe', 'frankie', 'law'];
const now = new Date(), iso = new Date(now - 5 * 60000).toISOString();
const mk = (blank) => JSON.stringify({ synced_at: iso, source: 'test', tabs: { CREW_STATUS: IDS.map(id => ({ crew_id: id, status: id === 'luffy' && !blank ? '' : (id === 'luffy' ? '' : 'Checking 25 listings at 14:05'), state: id === 'luffy' ? (blank ? '' : 'working') : 'working',
  decision: id === 'jinbe' && !blank ? 'Should the 5% include shipping?' : '', event_type: '', event_id: '', event_at: '', event_text: '', discount: '', updated_at: iso })), JOBS: [], SUMMARIES: [], BRIEFING: [], NEWS: [], BRAINSTORMS: [], CREW_CHAT: [], RELEASES: [], PALLET: [] } });
(async () => {
  const b = await chromium.launch({ executablePath: '/usr/bin/google-chrome', args: ['--no-sandbox'] }); const fails = [], out = {};
  const ctx = await b.newContext({ viewport: { width: 402, height: 874 }, deviceScaleFactor: 3, isMobile: true, hasTouch: true, timezoneId: 'America/Sao_Paulo' });
  const p = await ctx.newPage(); const errs = []; p.on('pageerror', e => errs.push(e.message)); let body = mk(false);
  await p.route('https://straw-hat-office.test/**', r => new URL(r.request().url()).pathname === '/crew.json' ? r.fulfill({ status: 200, contentType: 'application/json', body }) : r.fulfill({ status: 200, contentType: 'text/html', body: html }));
  await p.goto('https://straw-hat-office.test/'); await p.waitForFunction(() => typeof stats !== 'undefined' && stats && V4.ready, null, { timeout: 40000 }); await p.waitForTimeout(2500);
  const st = () => p.evaluate(() => { const j = agents.find(a => a.id === 'jinbe'), l = agents.find(a => a.id === 'luffy'); return { ringing: agents.filter(a => ringing(a)).map(a => a.id), jDecision: j.decision, jBubble: bubbleText(j, performance.now()), lState: l.state, lV4: v4State(l), lNow: crewNow(l) }; });
  out.before = await st();
  if (!out.before.ringing.includes('jinbe') || out.before.lV4 !== 'working') fails.push('fixture did not load: ' + JSON.stringify(out.before));
  // numbers (Law #3) with a decision pending, on all three tabs
  const SCAN = () => p.evaluate(() => { const vis = e => { const r = e.getBoundingClientRect(), s = getComputedStyle(e); return r.width > 0 && r.height > 0 && s.visibility !== 'hidden' && s.display !== 'none' && r.bottom > 0 && e.closest('[hidden]') === null; };
    const bad = []; const tw = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT); let n; while (n = tw.nextNode()) { const t = n.textContent; if (!/\d/.test(t) || !n.parentElement || !vis(n.parentElement) || n.parentElement.closest('script,style')) continue;
      const s = getComputedStyle(n.parentElement); if (/Pixelify|PIX/i.test(s.fontFamily) || !/tabular-nums/.test(s.fontVariantNumeric)) bad.push((n.parentElement.id || n.parentElement.className) + ': ' + t.trim().slice(0, 30)); } return bad; });
  for (const tb of ['ship', 'money', 'crew']) { await p.click(`#tabbar button[data-tab="${tb}"]`); await p.waitForTimeout(500); const bad = await SCAN(); out['badNum_' + tb] = bad; if (bad.length) fails.push(tb + ' tab: ' + bad.length + ' numbers not tabular: ' + bad.slice(0, 5).join(' | ')); }
  out.decH = await p.evaluate(() => { const e = document.querySelector('.decH'); return e ? e.textContent : null; }); if (!/\(1\)/.test(out.decH || '')) fails.push('decision header: ' + out.decH);
  // blank both cells, refresh
  body = mk(true); await p.evaluate(() => refresh(false)); await p.waitForTimeout(1500);
  out.after = await st();
  if (out.after.ringing.includes('jinbe') || out.after.jDecision) fails.push('blank decision did not clear: ' + JSON.stringify(out.after));
  if (/Needs your decision/.test(out.after.jBubble)) fails.push('Jinbe bubble still asks: ' + out.after.jBubble);
  if (out.after.lV4 === 'working' || /working/i.test(out.after.lNow || '')) fails.push('blank state did not clear Luffy: ' + JSON.stringify(out.after));
  // idea board on the visible ship (3x view)
  await p.click('#tabbar button[data-tab="ship"]'); await p.waitForTimeout(400);
  await p.evaluate(() => { v4zSet(1, null, null, false); agents.forEach(a => { a.wait = 1e9; a.path = []; a.walking = false; if (Math.abs(a.x - V432_IB.x0 - 20) < 40 && Math.abs(a.y - V432_IB.y1) < 40) { a.x = 60; a.y = 600; } }); });
  const P = await p.evaluate(() => { const c = V4.cv.getBoundingClientRect(), k = c.height / V4.EH, B = V432_IB; return { x: c.left + (B.x0 + B.x1) / 2 * k, y: c.top + (V4.oy + (B.y0 + B.y1) / 2) * k }; });
  await p.touchscreen.tap(P.x, P.y); await p.waitForTimeout(500);
  out.ideaBoard = await p.evaluate(() => { const m = $('modal'); return !!m && !m.hidden && getComputedStyle(m).display !== 'none' && /BRAINSTORM|IDEA/i.test(m.innerText || ''); });
  if (!out.ideaBoard) fails.push('idea board tap did not open the BRAINSTORMS board');
  errs.forEach(e => fails.push('page error: ' + e));
  console.log(JSON.stringify(out)); fails.forEach(f => console.log('  FAIL ' + f)); console.log(fails.length ? 'FAIL v432 feeds/numbers' : 'PASS v432 feeds/numbers');
  await b.close(); process.exit(fails.length ? 1 : 0);
})().catch(e => { console.error(e); process.exit(2); });
