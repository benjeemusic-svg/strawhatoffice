#!/usr/bin/env python3
"""v4.2 crew-sync checks: optional IDEAS tab (missing -> [] and listed in missing_tabs, never fails), IDEAS rows keyed by its 12 headers,
BRAINSTORMS 6th column `sources` kept by sync_crew.py AND by the app's brainSessions() parser in the built index.html.
Runs sync_crew.py from a temp copy so deploy/crew.json and deploy/sync_code.js in the repo are never touched.
   python3 tests/check_v42_sync.py"""
import json, os, shutil, subprocess, sys, tempfile
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
IDEAS_H = "id,title,proposed_by,problem,idea,data_sources,owner_bot,effort,status,owner_decision_at,outcome,decision_reason"
BS_H = "session_id,time,speaker,message,idea,sources"
BASE = ["CREW STATUS", "JOBS", "SUMMARIES", "BRIEFING", "NEWS", "CREW CHAT", "RELEASES", "PALLET"]
fails = []; n = 0
def check(name, ok, got=None):
    global n; n += 1
    if not ok: fails.append(name); print("FAIL", name, json.dumps(got, ensure_ascii=False)[:400])
def run(ranges):
    d = tempfile.mkdtemp(); shutil.copy(os.path.join(ROOT, "sync_crew.py"), d)
    p = os.path.join(d, "in.txt"); json.dump({"spreadsheetId": "10DeM9dRNrlM96pbdDC7Z1EKDVBbnFqgWQLjWrS0Eb6I", "ranges": ranges}, open(p, "w"))
    r = subprocess.run([sys.executable, os.path.join(d, "sync_crew.py"), p], capture_output=True, text=True)
    out = json.load(open(os.path.join(d, "deploy", "crew.json"))) if r.returncode == 0 else None
    shutil.rmtree(d); return r, out
bs = BS_H + '\nS1,2026-10-18 21:00,nami,"Margins first, then ambient",Margins panel,"US COMPS tab; Robin daily check"\n'
base = [{"sheet": t, "content": "x\n"} for t in BASE] + [{"sheet": "BRAINSTORMS", "content": bs}]
# 1) IDEAS missing
r, out = run(base)
check("sync succeeds without IDEAS", r.returncode == 0, r.stderr)
check("missing IDEAS -> empty array", out and out["tabs"].get("IDEAS") == [], out and out["tabs"].get("IDEAS"))
check("missing IDEAS listed in missing_tabs", out and out.get("missing_tabs") == ["IDEAS"], out and out.get("missing_tabs"))
check("BRAINSTORMS keeps sources", out and out["tabs"]["BRAINSTORMS"][0].get("sources") == "US COMPS tab; Robin daily check", out and out["tabs"]["BRAINSTORMS"])
check("BRAINSTORMS has all 6 columns", out and list(out["tabs"]["BRAINSTORMS"][0].keys()) == BS_H.split(","), out and out["tabs"]["BRAINSTORMS"])
# 2) IDEAS present, header only -> [] and not missing
r, out = run(base + [{"sheet": "IDEAS", "content": IDEAS_H + "\n"}])
check("header-only IDEAS -> [] and not missing", out and out["tabs"]["IDEAS"] == [] and "missing_tabs" not in out, out)
# 3) IDEAS with a row (and a blank row that is dropped)
row = 'I-1,Margins panel,nami,Owner cannot see margins,Show margin per product,US COMPS,frankie,S,approved,2026-10-18 21:30,,"owner: yes, keep it minimal"'
r, out = run(base + [{"sheet": "IDEAS", "content": IDEAS_H + "\n" + row + "\n,,,,,,,,,,,\n"}])
I = out and out["tabs"]["IDEAS"]
check("IDEAS row keyed by its 12 headers", I and len(I) == 1 and list(I[0].keys()) == IDEAS_H.split(",") and I[0]["decision_reason"] == "owner: yes, keep it minimal" and I[0]["outcome"] == "", I)
# 4) older 7-tab batch (no RELEASES/PALLET/IDEAS) still works
r, out = run([b for b in base if b["sheet"] not in ("RELEASES", "PALLET")])
check("7-tab batch still works", r.returncode == 0 and out["missing_tabs"] == ["RELEASES", "PALLET", "IDEAS"], out and out.get("missing_tabs"))
# 5) the app's parser keeps sources (brainSessions from the built index.html, fed like crew.json rows)
js = r"""
const fs=require('fs'),vm=require('vm');const h=fs.readFileSync(process.argv[1],'utf8');
const i=h.indexOf('function brainSessions(){'),j=h.indexOf('return [];}',i)+'return [];}'.length;
const ctx={FEEDS:{brainstorms:{ok:true,rows:[{session_id:'S1',time:'2026-10-18 21:00',speaker:'Nami',message:'m',idea:'Margins panel',sources:'US COMPS tab'},{session_id:'S1',time:'2026-10-18 21:01',speaker:'robin',message:'m2',idea:null,sources:null}]}},parseDate:s=>new Date(s)};
vm.createContext(ctx);vm.runInContext(h.slice(i,j)+';this.S=brainSessions();',ctx);console.log(JSON.stringify(ctx.S[0].lines.map(l=>l.sources)));"""
p = subprocess.run(["node", "-e", js, os.path.join(ROOT, "index.html")], capture_output=True, text=True)
check("app parser keeps sources per line", p.stdout.strip() == '["US COMPS tab",null]', p.stdout + p.stderr)
print(f"{n - len(fails)}/{n} passed"); sys.exit(1 if fails else 0)
