// v4.1: walk every route (every spot/station -> every spot) and assert no feet point enters a furniture footprint;
// also no spot, station or graph node sits inside a footprint, and the depth pass draws crew over the aquarium light.
// usage: node tests/check_v41_routes.js   (needs playwright-core; PW env = path to its node_modules)
const path=require("path");const pw=require(process.env.PW||"/workspace/pwtest/node_modules/playwright-core");
(async()=>{const b=await pw.chromium.launch({executablePath:process.env.CHROME||"/usr/bin/google-chrome",args:["--no-sandbox"]});
  const pg=await b.newPage({viewport:{width:402,height:874}});pg.on("pageerror",e=>console.log("PAGEERROR "+e.message));
  await pg.goto("file://"+path.resolve(__dirname,"../index.html"));await pg.waitForFunction(()=>typeof V4!=="undefined"&&V4.ready,null,{timeout:30000});
  const r=await pg.evaluate(()=>{const bad=[],names=Object.keys(SPOTS),a={id:"probe",x:0,y:0,path:[]};let routes=0,legs=0,detours=0,noroute=0;
    const inF=(x,y)=>v41InFoot(x,y,0);
    for(const [k,s] of Object.entries(SPOTS))if(inF(s.x,s.y))bad.push("spot "+k+" inside "+inF(s.x,s.y)[0]);
    for(const [n,q] of Object.entries(V4N))if(!V41_CLIMB.has(n)&&inF(q.x,q.y))bad.push("node "+n+" inside "+inF(q.x,q.y)[0]);
    for(const from of names){const f=SPOTS[from];if(v4OnClimb(f))continue;for(const to of names){if(to===from)continue;
      a.x=f.x;a.y=f.y;routeTo(a,to);routes++;if(!a.path.length&&Math.hypot(SPOTS[to].x-f.x,SPOTS[to].y-f.y)>1){noroute++;continue;}
      let p={x:f.x,y:f.y};
      for(const q of a.path){legs++;if(q.via==="climb"){p=q;continue;}const n=Math.ceil(Math.hypot(q.x-p.x,q.y-p.y));
        for(let i=0;i<=n;i++){const t=n?i/n:0,x=p.x+(q.x-p.x)*t,y=p.y+(q.y-p.y)*t,F=inF(x,y);if(F){bad.push(from+"->"+to+" feet ("+x.toFixed(1)+","+y.toFixed(1)+") in "+F[0]);break;}}p=q;}}}
    detours=Object.values(V41_ASTAR).filter(Boolean).length;
    return {routes,legs,detours,noroute,moved:V41_MOVED,bad:bad.slice(0,30),nbad:bad.length,foot:V41_FOOT.length};});
  let pass=r.nbad===0&&r.noroute===0;
  console.log(JSON.stringify({routes:r.routes,legs:r.legs,astar_detours:r.detours,no_route:r.noroute,footprints:r.foot,moved:r.moved},null,0));
  r.bad.forEach(x=>console.log("  BAD "+x));
  // depth order: a crew member standing in front of the aquarium at night is drawn (pixels at the feet differ from an empty scene)
  const dp=await pg.evaluate(async()=>{V4.force="night";v4SetPhase("night");await new Promise(r=>setTimeout(r,800));
    const res={};const shot=()=>V4.g.getImageData(0,0,WW,WH).data;
    const place=(list)=>{agents.forEach((a,i)=>{a.path=[];a.walking=false;a.wait=1e9;a.anim=null;a.x=212+(i%3);a.y=60;});list.forEach(([id,x,y])=>{const a=agents.find(q=>q.id===id);a.x=x;a.y=y;});V4.lastKey=null;drawV4(performance.now(),16);return shot();};
    const diff=(A,B,x0,y0,x1,y1)=>{let n=0;for(let y=y0;y<y1;y++)for(let x=x0;x<x1;x++){const i=(y*WW+x)*4;if(A[i]!==B[i]||A[i+1]!==B[i+1]||A[i+2]!==B[i+2])n++;}return n;};
    const e=place([]);
    const aq=place([["brook",306,444]]);res.aquarium_visible=diff(e,aq,294,400,318,445);
    const sbBehind=place([["chopper",168,355]]);res.sickbay_behind_desk_px_below_desktop=diff(e,sbBehind,150,342,186,356); // screen covers his lower body
    res.sickbay_behind_desk_over_screen=diff(e,sbBehind,155,308,182,341);
    const sbFront=place([["chopper",168,396]]);res.sickbay_front_visible=diff(e,sbFront,156,352,180,397);
    return res;});
  console.log(JSON.stringify(dp));
  const dpass=dp.aquarium_visible>150&&dp.sickbay_behind_desk_px_below_desktop===0&&dp.sickbay_behind_desk_over_screen>50&&dp.sickbay_front_visible>150;
  console.log((pass?"PASS":"FAIL")+" routes  "+(dpass?"PASS":"FAIL")+" depth");
  await b.close();process.exit(pass&&dpass?0:1);})().catch(e=>{console.error(e);process.exit(2);});
