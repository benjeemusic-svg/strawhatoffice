// v4.1 (owner 23:00): numbers must be readable. Every visible text run containing R$, US$ or % (and every digit in the money card, Money tab
// and crew roster) is rendered in the system font, not the pixel font. Plus: on the Ship tab first screen the whole CREW STATUS strip sits above
// the tab bar (402x874), and the Crew tab heading is one line "CREW STATUS · synced HH:MM".   node tests/check_v41_numfont.js
const { chromium } = require(process.env.PW || '/workspace/pwtest/node_modules/playwright-core');
const fs = require('fs'), path = require('path'); const html = fs.readFileSync(path.join(__dirname, '..', 'index.html'), 'utf8');
const IDS = ['luffy', 'nami', 'zoro', 'usopp', 'sanji', 'chopper', 'robin', 'brook', 'jinbe', 'frankie', 'law'];
const now = new Date(), iso = new Date(now - 5 * 60000).toISOString();
const rows = IDS.map(id => ({ crew_id: id, status: id === 'chopper' ? 'OP09 box at R$ 1.234,56, 18% under avg' : 'Checking 25 listings', state: 'working', decision: '', event_type: id === 'chopper' ? 'deal_found' : '', event_id: id === 'chopper' ? 'nf-1' : '', event_at: id === 'chopper' ? now.toISOString() : '', event_text: id === 'chopper' ? 'OP09 booster box R$ 1.234,56 (18% under avg)' : '', discount: id === 'chopper' ? '18' : '', updated_at: iso }));
const body = JSON.stringify({ synced_at: iso, source: 'test', tabs: { CREW_STATUS: rows, JOBS: [], SUMMARIES: [], BRIEFING: [], NEWS: [], BRAINSTORMS: [], CREW_CHAT: [], RELEASES: [], PALLET: [] } });
const SCAN = `(scope)=>{const out=[];const root=scope?document.querySelector(scope):document.body;if(!root)return out;const w=document.createTreeWalker(root,NodeFilter.SHOW_TEXT);let n;
  while(n=w.nextNode()){const s=n.textContent;if(!s.trim())continue;const e=n.parentElement;if(!e||!e.getClientRects().length)continue;let hid=false;for(let p=e;p;p=p.parentElement){const c=getComputedStyle(p);if(c.display==='none'||c.visibility==='hidden'||+c.opacity<0.05){hid=true;break;}}if(hid)continue;
   const money=/R\\$|US\\$|%/.test(s),digit=/\\d/.test(s);if(!money&&!(scope&&digit))continue;const ff=getComputedStyle(e).fontFamily;out.push({t:s.trim().slice(0,40),sel:(e.id?'#'+e.id:'.'+String(e.className||e.tagName).split(' ')[0]),ff:ff.slice(0,40),pix:/^\\s*"?PIX"?\\s*(,|$)/.test(ff),tab:getComputedStyle(e).fontVariantNumeric});}return out;}`;
(async () => {
  const b = await chromium.launch({ executablePath: '/usr/bin/google-chrome', args: ['--no-sandbox'] }); const fails = []; const seen = [];
  const ctx = await b.newContext({ viewport: { width: 402, height: 874 }, deviceScaleFactor: 3, isMobile: true, hasTouch: true, timezoneId: 'America/Sao_Paulo' });
  const p = await ctx.newPage(); const errs = []; p.on('pageerror', e => errs.push(e.message));
  await p.route('https://straw-hat-office.test/**', r => new URL(r.request().url()).pathname === '/crew.json' ? r.fulfill({ status: 200, contentType: 'application/json', body }) : r.fulfill({ status: 200, contentType: 'text/html', body: html }));
  await p.goto('https://straw-hat-office.test/'); await p.waitForFunction(() => typeof stats !== 'undefined' && stats && V4.ready, null, { timeout: 40000 }); await p.waitForTimeout(3000);
  const scan = async (tag, scope) => { const r = await p.evaluate(`(${SCAN})(${JSON.stringify(scope || null)})`); r.forEach(x => { seen.push(tag + ' ' + x.sel + ' "' + x.t + '" ' + x.ff); if (x.pix) fails.push(`${tag}: ${x.sel} "${x.t}" is in the pixel font`); }); return r.length; };
  // Ship tab first screen: strip fully above the tab bar
  // v4.3 (owner 23:48): the Ship tab is only the ship (no crew strip, toolbar or SFX switch), whole-number scale, fully above the tab bar
  const L = await p.evaluate(() => { const t = $('tabbar').getBoundingClientRect(), c = V4.cv.getBoundingClientRect(); return { shipCard: !!$('topCard'), strip: !!$('crewStrip'), toolbar: !!$('toolbar'), sfx: !!$('soundBtn'), k: V4.k, canvasBottom: Math.round(Math.min(c.bottom, $('stageWrap').getBoundingClientRect().bottom)), /* v4.3.2: at 4x the canvas is clipped by #stageWrap; what shows ends at the wrap */ tabTop: Math.round(t.top), canvasW: Math.round(c.width), canvasH: Math.round(c.height), scrollY }; });
  if (L.shipCard) fails.push('Ship-tab money card still present'); if (L.strip || L.toolbar || L.sfx) fails.push('Ship tab still has strip/toolbar/SFX'); if (Math.abs(L.k - Math.round(L.k)) > 1e-9) fails.push('ship scale not whole-number: k=' + L.k); if (L.canvasBottom > L.tabTop) fails.push('Ship first screen: ship ends at ' + L.canvasBottom + ', under the tab bar at ' + L.tabTop);
  await p.screenshot({ path: '/workspace/frankie-review/shots-v4.3/tests/v41-iphone16pro-ship-first-screen.png' });
  let n = await scan('ship') + await scan('ship-gone', '#topCard') + await scan('crew-roster', '#roster');
  // pixel-font prose with numbers: bubble, banner, floaty, toast
  await p.evaluate(() => { const a = agents.find(x => x.id === 'chopper'); agents.forEach(x => { x.anim = null; x.say = null; }); hoverRaw = a; hoverAgent = a; banner('t', '🎆 BIG DEAL: 18% OFF', 8000); floaty('+3 items!', 200, 300); $('crewStrip'); toast('<b>🪙 NEW PURCHASE LOGGED</b><br>Shiny Store · EB05 CASE<br>×2 · R$ 22,572.76 → commission +R$ 1,128.64', 8000); });
  await p.waitForTimeout(1200); n += await scan('ship-fx');
  await p.click('#tabbar button[data-tab="money"]'); await p.waitForTimeout(600); n += await scan('money') + await scan('money-tab', '#pMoney');
  await p.screenshot({ path: '/workspace/frankie-review/shots-v4.3/tests/v41-iphone16pro-money-tab.png' });
  await p.click('#tabbar button[data-tab="crew"]'); await p.waitForTimeout(600); n += await scan('crew');
  const H = await p.evaluate(() => { const h = document.querySelector('#secCrew h2'); return { text: h.innerText.replace(/\s+/g, ' ').trim(), h: Math.round(h.getBoundingClientRect().height), lines: Math.round(h.getBoundingClientRect().height / parseFloat(getComputedStyle(h).lineHeight || 20)) }; });
  if (!/^CREW STATUS · synced \d{1,2}:\d{2}( ▼| ▾)?$/.test(H.text.replace(/[▼▾▲▴]/g, '').trim() .replace(/\s+$/, '')) && !/^CREW STATUS · synced \d{1,2}:\d{2}/.test(H.text)) fails.push('crew heading: "' + H.text + '"');
  if (H.h > 48) fails.push('crew heading wraps: ' + H.h + ' px tall');
  await p.screenshot({ path: '/workspace/frankie-review/shots-v4.3/tests/v41-iphone16pro-crew-tab.png' });
  if (n < 12) fails.push('only ' + n + ' number runs found: scan broken?');
  errs.forEach(e => fails.push('page error: ' + e));
  console.log(JSON.stringify({ layout: L, heading: H, runs: n })); seen.slice(0, 60).forEach(s => console.log('  ' + s));
  fails.forEach(f => console.log('  FAIL ' + f)); console.log(fails.length ? 'FAIL numfont' : 'PASS numfont');
  await b.close(); process.exit(fails.length ? 1 : 0);
})().catch(e => { console.error(e); process.exit(2); });
