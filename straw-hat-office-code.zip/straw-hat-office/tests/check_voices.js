// v4.1 crew voices (owner 20:42): fails if the old Luffy laugh appears anywhere in the shipped code/docs, if a bot uses another bot's
// catchphrase (Yohoho = Brook, SUPER = Frankie, Fufu = Robin, "Nice work, crew!" = Luffy), if a bubble carries more than one
// catchphrase, or if a bot says its catchphrase on more than half of its lines.   node tests/check_voices.js
const fs = require('fs'), path = require('path'), { execSync } = require('child_process');
const ROOT = path.join(__dirname, '..');
const LAUGH = new RegExp('shi' + 'shi' + 'shi', 'i');           // built from pieces so this file never matches itself
const CATCH = { luffy: /nice work, crew/i, brook: /yoho/i, frankie: /SU+PER/, robin: /fufu/i };
const fails = []; let checked = 0;
// 1) static: every tracked or new text file except the archived v3 side-view (kept read-only, never served)
const files = execSync('git ls-files -co --exclude-standard', { cwd: ROOT }).toString().split('\n').filter(f => f && !f.startsWith('archive_sideview/') && /\.(js|html|md|py|json|txt|csv)$/.test(f));
for (const f of files) { const s = fs.readFileSync(path.join(ROOT, f), 'utf8'); checked++;
  if (LAUGH.test(s)) fails.push(`laugh line found in ${f}`);
  if (f.startsWith('src/') && f !== 'src/4_voice.js') for (const [id, re] of Object.entries(CATCH)) {
    const lits = s.match(/"(?:[^"\\\n]|\\.)*"|'(?:[^'\\\n]|\\.)*'|`(?:[^`\\]|\\.)*`/g) || [];
    lits.forEach(l => { if (re.test(l)) fails.push(`${f}: catchphrase of ${id} outside the VOICE table: ${l.slice(0, 60)}`); }); } }
// 2) runtime: the VOICE table and the real bubble text for every event type, per bot
(async () => {
  const { chromium } = require(process.env.PW || '/workspace/pwtest/node_modules/playwright-core');
  const b = await chromium.launch({ executablePath: process.env.CHROME || '/usr/bin/google-chrome', args: ['--no-sandbox'] });
  const pg = await b.newPage(); const errs = []; pg.on('pageerror', e => errs.push(e.message));
  await pg.goto('file://' + path.join(ROOT, 'index.html')); await pg.waitForFunction(() => typeof V4 !== 'undefined' && V4.ready, null, { timeout: 30000 });
  const R = await pg.evaluate(() => { const lines = {}, flat = (o, out) => { if (typeof o === 'string') out.push(o); else if (o && typeof o === 'object') Object.values(o).forEach(v => flat(v, out)); return out; };
    Object.entries(VOICE).forEach(([id, v]) => lines[id] = flat(v, []));
    const bubbles = []; agents.forEach(a => Object.keys(EVENTS).forEach(type => bubbles.push([a.id, bubbleText({ id: a.id, anim: { type } }, 0)])));
    Object.values(COMBOS).forEach(C => C.lines.forEach(([id, l]) => bubbles.push([id, l])));
    return { lines, bubbles, labels: Object.values(EVENTS).map(e => e.label), ids: agents.map(a => a.id) }; });
  await b.close();
  const hits = s => Object.entries(CATCH).filter(([, re]) => re.test(s)).map(([id]) => id);
  R.ids.forEach(id => { if (!R.lines[id] || !R.lines[id].length) fails.push(`no VOICE lines for ${id}`); });
  for (const [id, ls] of Object.entries(R.lines)) { let own = 0;
    ls.forEach(l => { const h = hits(l); if (h.length > 1) fails.push(`${id}: more than one catchphrase in "${l}"`); h.filter(x => x !== id).forEach(x => fails.push(`${id} uses ${x}'s catchphrase: "${l}"`)); if (h.includes(id)) own++; });
    if (CATCH[id] && own * 2 > ls.length) fails.push(`${id}: catchphrase on ${own}/${ls.length} lines (more than half)`);
    if (CATCH[id] && !own) fails.push(`${id}: catchphrase never used`); }
  R.labels.forEach(l => { if (hits(l).length) fails.push(`neutral EVENTS label carries a catchphrase: "${l}"`); });
  R.bubbles.forEach(([id, t]) => { const h = hits(t); if (h.length > 1) fails.push(`${id} bubble has ${h.length} catchphrases: "${t}"`); h.filter(x => x !== id).forEach(x => fails.push(`${id} bubble uses ${x}'s catchphrase: "${t}"`)); if (LAUGH.test(t)) fails.push(`${id} bubble has the laugh line`); });
  errs.forEach(e => fails.push('page error: ' + e));
  console.log(`files scanned: ${checked} · bots: ${Object.keys(R.lines).length} · lines: ${Object.values(R.lines).flat().length} · bubbles checked: ${R.bubbles.length}`);
  fails.forEach(f => console.log('  FAIL ' + f)); console.log(fails.length ? 'FAIL' : 'PASS'); process.exit(fails.length ? 1 : 0);
})().catch(e => { console.error(e); process.exit(2); });
