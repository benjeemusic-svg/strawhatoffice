// v4.3.2 (owner via Law 00:26, supersedes the 00:16 2x zoom): the Ship tab opens at (k+1)x = 4x on iPhone 16 Pro, centred horizontally,
// no sideways page overflow; one-finger vertical pan clamped to the ship + V4Z_SEA rows of sea; double-tap toggles 3x (whole ship) <-> 4x
// around the tap point; no browser zoom; reduced motion snaps; single taps act at once. Sea still fills the Ship tab (v4.3.1).
// node tests/check_v431_zoom.js [url] [shotdir]
const { chromium } = require(process.env.PW || '/workspace/pwtest/node_modules/playwright-core');
const URL = process.argv[2] || 'http://127.0.0.1:18796/index.html', SHOTS = process.argv[3] || '';
(async () => {
  const b = await chromium.launch({ executablePath: '/usr/bin/google-chrome', args: ['--no-sandbox'] }); const fails = [], out = {};
  const open = async (rm) => { const ctx = await b.newContext({ viewport: { width: 402, height: 874 }, deviceScaleFactor: 3, isMobile: true, hasTouch: true, timezoneId: 'America/Sao_Paulo', reducedMotion: rm ? 'reduce' : 'no-preference' });
    const p = await ctx.newPage(); p._errs = []; p.on('pageerror', e => p._errs.push(e.message));
    await p.goto(URL); await p.waitForFunction(() => typeof V4 !== 'undefined' && V4.ready && V4Z.init, null, { timeout: 40000 }); await p.waitForTimeout(2500); return { ctx, p }; };
  const geo = p => p.evaluate(() => { const c = V4.cv.getBoundingClientRect(), w = $('stageWrap').getBoundingClientRect(), k = c.height / V4.EH, dpr = devicePixelRatio;
    return { s: V4Z.s, k: V4.k, dev: c.width * dpr / WW, oy: V4.oy, sea: V4Z_SEA, ship: { l: c.left, t: c.top + V4.oy * k, r: c.right, b: c.top + (V4.oy + WH) * k }, wrap: { l: w.left, t: w.top, r: w.right, b: w.bottom }, cv: { t: c.top, b: c.bottom },
      tab: $('tabbar').getBoundingClientRect().top, ta: getComputedStyle(V4.cv).touchAction, sw: document.documentElement.scrollWidth, bw: document.body.scrollWidth, sx: scrollX, vv: visualViewport ? visualViewport.scale : 1, ak: k }; });
  const tap = (p, x, y) => p.touchscreen.tap(x, y), dbl = async (p, x, y) => { await tap(p, x, y); await p.waitForTimeout(110); await tap(p, x, y); };
  const drag = async (ctx, p, dy) => { const cdp = await ctx.newCDPSession(p); const pt = (x, y) => [{ x, y }]; await cdp.send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: pt(200, 420) });
    for (let i = 1; i <= 12; i++) await cdp.send('Input.dispatchTouchEvent', { type: 'touchMove', touchPoints: pt(200, 420 + dy * i / 12) });
    await cdp.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] }); await p.waitForTimeout(450); };
  const { ctx, p } = await open(false);
  const G0 = await geo(p); out.open = G0;
  // sea fill (v4.3.1): canvas spans the Ship tab, rows above/below the ship
  if (G0.oy < 20) fails.push('sea fill: oy ' + G0.oy);
  // the Ship tab is exactly one screen: no top strip, sea down to the tab bar, the page cannot scroll
  const H = await p.evaluate(() => { const w = $('stageWrap').getBoundingClientRect(), c = V4.cv, k = c.getBoundingClientRect().height / V4.EH; window.scrollTo(0, 500); const sy = scrollY; window.scrollTo(0, 0);
    return { wrapTop: w.top, wrapBot: w.bottom, tab: $('tabbar').getBoundingClientRect().top, sh: document.documentElement.scrollHeight, ih: innerHeight, sy, osb: getComputedStyle(document.body).overscrollBehaviorY }; });
  out.page = H;
  if (H.wrapTop > 0.5) fails.push('strip above the sea: wrap top ' + H.wrapTop);
  if (Math.abs(H.wrapBot - H.tab) > 0.5) fails.push(`sea ends at ${H.wrapBot}, tab bar at ${H.tab}`);
  if (H.sh > H.ih || H.sy !== 0) fails.push(`Ship page scrolls: scrollHeight ${H.sh} vs ${H.ih}, scrollY after scrollTo(500) ${H.sy}`);
  if (H.osb !== 'none') fails.push('overscroll-behavior on the Ship tab: ' + H.osb);
  const seam = await p.evaluate(() => { const g = V4.g, d = r => [...g.getImageData(2, r, 1, 1).data].slice(0, 3), dist = (u, v) => Math.max(...u.map((x, i) => Math.abs(x - v[i]))); return { top: dist(d(V4.oy - 1), d(V4.oy)), bot: dist(d(V4.oy + WH - 1), d(V4.oy + WH)) }; });
  if (seam.top > 40 || seam.bot > 40) fails.push('visible seam at the ship edge: ' + JSON.stringify(seam));
  // opens at 4x, centred, no sideways overflow
  if (Math.abs(G0.s - 4 / 3) > 1e-6 || Math.abs(G0.dev - 4) > 0.01) fails.push(`does not open at 4x: s=${G0.s}, ${G0.dev} device px per art px`);
  const cropL = G0.wrap.l - G0.ship.l, cropR = G0.ship.r - G0.wrap.r; out.cropCss = [cropL, cropR]; out.cropDevice = [cropL * 3, cropR * 3]; out.cropArt = [cropL * 3 / 4, cropR * 3 / 4];
  if (Math.abs(cropL - cropR) > 0.5 || cropL <= 0) fails.push('4x not centred horizontally: crop ' + cropL + ' / ' + cropR);
  if (G0.sw !== 402 || G0.bw > 402 || G0.sx !== 0) fails.push(`horizontal overflow: scrollWidth ${G0.sw}, body ${G0.bw}, scrollX ${G0.sx}`);
  if (G0.ta !== 'none') fails.push('touch-action on the 4x ship: ' + G0.ta);
  // v4.3.3: at open the hull top sits just below the safe-area inset (emulator inset is 0; a 59 px iPhone 16 Pro inset is simulated)
  if (Math.abs(G0.ship.t - (G0.wrap.t + 4)) > 0.7) fails.push('4x open: hull top ' + G0.ship.t + ' (expected safe inset + 4 = ' + (G0.wrap.t + 4) + ')');
  const S59 = await p.evaluate(() => { V4Z.safeTest = 59; v4zDefault(); const c = V4.cv.getBoundingClientRect(), k = c.height / V4.EH, t = c.top + V4.oy * k; V4Z.safeTest = null; v4zDefault(); return t; });
  out.hullTopAtOpen = { inset0: G0.ship.t, inset59: S59 }; if (S59 < 59 + 3.5 || S59 > 59 + 4.7) fails.push('with a 59 px inset the hull top opens at ' + S59);
  if (SHOTS) await p.screenshot({ path: SHOTS + '/v433-ship-4x.png' });
  // vertical pan, clamped to the ship + sea margin; no sideways movement
  const m = Math.min(G0.sea, G0.oy) * G0.ak;
  await drag(ctx, p, -2000); const Gd = await geo(p);
  if (Math.abs(Gd.ship.b + m - Gd.wrap.b) > 1) fails.push(`pan up not clamped at ship bottom + sea: ship.b ${Gd.ship.b} + ${m} vs wrap ${Gd.wrap.b}`);
  if (Math.abs(Gd.ship.l - G0.ship.l) > 0.5) fails.push('pan moved sideways');
  if (SHOTS) await p.screenshot({ path: SHOTS + '/v432-ship-4x-bottom.png' });
  await drag(ctx, p, 2000); const Gu = await geo(p);
  if (Math.abs(Gu.ship.t - m - Gu.wrap.t) > 1) fails.push(`pan down not clamped at ship top - sea: ship.t ${Gu.ship.t} - ${m} vs wrap ${Gu.wrap.t}`);
  out.travelCss = Gu.ship.t - Gd.ship.t; out.travelShipOnlyCss = (G0.ship.b - G0.ship.t) - (G0.wrap.b - G0.wrap.t);
  if (Gu.sw !== 402) fails.push('pan caused horizontal overflow');
  // double tap -> whole ship at 3x, around the tap point; again -> 4x
  // tap point: a spot in the middle of the ship with no crew member under the finger (a tap on crew opens their panel at once)
  await p.evaluate(() => agents.forEach(a => { a.wait = 1e9; a.path = []; a.walking = false; }));
  const cy = await p.evaluate(() => { for (let d = 0; d < 200; d += 6) for (const y of [460 + d, 460 - d]) { if (!v4Hit({ clientX: 201, clientY: y }, 60)) return y; } return 460; }); out.tapY = cy;
  const artY = async () => p.evaluate(y => { const c = V4.cv.getBoundingClientRect(); return (y - c.top) * V4.EH / c.height; }, cy);
  const a0 = await artY(); await dbl(p, 201, cy); await p.waitForTimeout(450); const G1 = await geo(p);
  if (G1.s !== 1 || Math.abs(G1.dev - 3) > 0.01) fails.push('double tap did not go to 3x: s=' + G1.s);
  if (G1.ship.t < G1.wrap.t - 0.5 || G1.ship.b > G1.wrap.b + 0.5 || G1.ship.l < -0.5 || G1.ship.r > 402.5) fails.push('3x does not show the whole ship: ' + JSON.stringify(G1.ship));
  if (G1.ta !== 'none') fails.push('touch-action at 3x: ' + G1.ta + ' (the ship area is locked)');
  if (SHOTS) await p.screenshot({ path: SHOTS + '/v432-ship-3x.png' });
  const a1 = await artY(); await dbl(p, 201, cy); await p.waitForTimeout(450); const G2 = await geo(p); const a2 = await artY();
  if (Math.abs(G2.s - 4 / 3) > 1e-6) fails.push('double tap did not go back to 4x: s=' + G2.s);
  out.anchor = { before4: a0, at3: a1, after4: a2 };
  if (Math.abs(a2 - a1) > 1.5) fails.push(`4x zoom not around the tap point: art row ${a1.toFixed(1)} -> ${a2.toFixed(1)}`); // (no clamp at cy=500 in the middle of the ship)
  if (G2.vv !== 1 || G1.vv !== 1) fails.push('browser zoom changed: visualViewport.scale ' + G1.vv + '/' + G2.vv);
  // animated (not reduced motion): mid-toggle the scale is between 1 and 4/3
  await dbl(p, 201, cy); await p.waitForTimeout(60); const mid = await p.evaluate(() => { const m = getComputedStyle($('stage')).transform; return m === 'none' ? 1 : +m.split('(')[1].split(',')[0]; });
  if (!(mid > 1.001 && mid < 4 / 3 - 0.001)) fails.push('toggle not animated (scale at 60 ms: ' + mid + ')'); await p.waitForTimeout(500); out.midScale = mid;
  await dbl(p, 201, cy); await p.waitForTimeout(500);
  // bubbles keep their on-screen size at 4x
  const bub = async () => p.evaluate(() => { const a = agents.find(q => q.id === 'luffy'); a.say = { text: 'Ahoy test', until: performance.now() + 4000 }; return null; });
  const bw = () => p.evaluate(() => new Promise(r => setTimeout(() => { const e = document.querySelector('.tag.talk .bub'); r(e ? e.getBoundingClientRect().height : 0); }, 400)));
  await bub(); const h4 = await bw(); await p.evaluate(() => v4zSet(1, null, null, false)); await bub(); const h3 = await bw(); await p.evaluate(() => v4zSet(v4zBig(), null, null, false));
  out.bubbleH = { at4: h4, at3: h3 }; if (h3 && h4 && Math.abs(h4 - h3) > 1.5) fails.push(`bubble grows at 4x: ${h3} -> ${h4} px tall`);
  // single tap on a crew member opens the panel at once (no 300 ms hold)
  const A = await p.evaluate(() => { const c = V4.cv.getBoundingClientRect(), k = c.height / V4.EH; const vis = agents.filter(a => { const y = c.top + (V4.oy + a.y - 20) * k, x = c.left + a.x * k; return !a.walking && x > 30 && x < 372 && y > 60 && y < 760; }); const a = vis[0] || agents[0]; return { id: a.id, x: c.left + a.x * k, y: c.top + (V4.oy + a.y - 20) * k }; });
  await tap(p, A.x, A.y); await p.waitForTimeout(120);
  const opened = await p.evaluate(() => { const e = $('panel'); return !!e && (e.classList.contains('show') || e.classList.contains('open') || (!e.hidden && getComputedStyle(e).display !== 'none' && getComputedStyle(e).visibility !== 'hidden')); });
  if (!opened) fails.push('single tap on ' + A.id + ' did not open the crew panel within 120 ms'); out.tap = A;
  if (Math.abs((await geo(p)).s - 4 / 3) > 1e-6) fails.push('single tap changed the zoom');
  await p.evaluate(() => { try { closeP(); } catch (e) {} });
  // other tabs: Money tab unaffected, zoom kept for the Ship tab
  await p.click('#tabbar button[data-tab="money"]'); await p.waitForTimeout(400);
  const M = await p.evaluate(() => ({ sw: document.documentElement.scrollWidth, ta: getComputedStyle(document.documentElement).touchAction }));
  if (M.sw !== 402) fails.push('Money tab horizontal overflow ' + M.sw);
  for (const tb of ['money', 'crew']) { await p.click(`#tabbar button[data-tab="${tb}"]`); await p.waitForTimeout(300);
    const Q = await p.evaluate(() => { scrollTo(0, 400); const y = scrollY; scrollTo(0, 0); return { y, sh: document.documentElement.scrollHeight, ih: innerHeight }; });
    if (Q.sh > Q.ih + 20 && Q.y < 1) fails.push(tb + ' tab no longer scrolls'); out['scroll_' + tb] = Q; }
  await p.click('#tabbar button[data-tab="ship"]'); await p.waitForTimeout(500);
  if (Math.abs((await geo(p)).s - 4 / 3) > 1e-6) fails.push('Ship tab did not keep 4x after a tab switch');
  p._errs.forEach(e => fails.push('page error: ' + e)); await ctx.close();
  // reduced motion: the toggle snaps
  const R = await open(true); await dbl(R.p, 201, cy); await R.p.waitForTimeout(40);
  const snap = await R.p.evaluate(() => ({ s: V4Z.s, tr: getComputedStyle($('stage')).transform, td: getComputedStyle($('stage')).transitionDuration }));
  if (snap.s !== 1 || snap.tr !== 'none') fails.push('reduced motion: toggle did not snap: ' + JSON.stringify(snap)); out.reduced = snap;
  R.p._errs.forEach(e => fails.push('page error (reduced): ' + e)); await R.ctx.close();
  console.log(JSON.stringify(out));
  fails.forEach(f => console.log('  FAIL ' + f)); console.log(fails.length ? 'FAIL v432 ship zoom' : 'PASS v432 ship zoom');
  await b.close(); process.exit(fails.length ? 1 : 0);
})().catch(e => { console.error(e); process.exit(2); });
