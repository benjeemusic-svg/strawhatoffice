// Headless check: app loads over https with a mocked /crew.json, and over file:// (fallback).
// node tests/check_crewjson.js   (needs /workspace/pwtest/node_modules/playwright-core + google-chrome)
const { chromium } = require('/workspace/pwtest/node_modules/playwright-core');
const fs = require('fs'), path = require('path');
const ROOT = path.join(__dirname, '..');
const html = fs.readFileSync(path.join(ROOT, 'index.html'), 'utf8');
const mock = { synced_at: '2026-10-18T16:40:00-03:00', source: 'mock', tabs: {
  CREW_STATUS: [{ crew_id: 'chopper', status: 'MOCK: watching Liga', state: 'working', decision: '', event_type: '', event_id: '', event_at: '', event_text: '', discount: '', updated_at: '2026-10-18 16:40' }],
  JOBS: [{ job_id: 'J-mock-1', posted_at: '2026-10-18 16:00', task: 'MOCK job', assignee: 'frankie', status: 'doing', result: '', result_link: '' }],
  SUMMARIES: [], BRIEFING: [], NEWS: [{ headline: 'MOCK headline', source: 'mock', link: '', date: '2026-10-18' }],
  BRAINSTORMS: [], CREW_CHAT: [{ time: '2026-10-18 16:41', from: 'chopper', to: 'robin', message: 'mock', event_ref: '', kind: 'handoff' }] } };
(async () => {
  const browser = await chromium.launch({ executablePath: '/usr/bin/google-chrome', args: ['--no-sandbox'] });
  let fail = false;
  for (const mode of ['https', 'https-crewjson-fails', 'file']) {
    const ctx = await browser.newContext({ viewport: { width: 402, height: 874 }, deviceScaleFactor: 1 });
    const page = await ctx.newPage(); const errs = []; let crewHits = 0;
    page.on('pageerror', e => errs.push('pageerror: ' + e.message));
    page.on('console', m => { if (m.type() === 'error') errs.push('console: ' + m.text()); });
    await page.route('https://straw-hat-office.test/**', r => {
      const u = new URL(r.request().url());
      if (u.pathname === '/crew.json') { crewHits++; return mode === 'https' ? r.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(mock) }) : r.fulfill({ status: 302, headers: { location: 'https://x.cloudflareaccess.com/login' } }); }
      return r.fulfill({ status: 200, contentType: 'text/html', body: html });
    });
    await page.route('https://x.cloudflareaccess.com/**', r => r.fulfill({ status: 200, contentType: 'text/html', body: '<html>login</html>' }));
    const url = mode === 'file' ? 'file://' + path.join(ROOT, 'index.html') : 'https://straw-hat-office.test/';
    await page.goto(url); await page.waitForTimeout(9000);
    const pill = await page.textContent('#dataPill');
    const info = await page.evaluate(() => ({ crew: FEEDS.crew && FEEDS.crew.note, jobs: FEEDS.jobs && FEEDS.jobs.note, chat: FEEDS.chat ? FEEDS.chat.rows.length : null,
      chopper: (agents.find(a => a.id === 'chopper') || {}).status }));
    // network errors for blocked external hosts (gviz/meteo in sandbox) are not app errors
    const appErrs = errs.filter(e => !/Failed to load resource|net::ERR|ERR_/.test(e));
    console.log(JSON.stringify({ mode, pill, crewHits, ...info, appErrs }));
    if (appErrs.length) fail = true;
    if (mode === 'https' && !(/CREW SYNCED 16:40 BRT/.test(pill) && info.chopper === 'MOCK: watching Liga' && info.chat === 1)) fail = true;
    if (mode !== 'https' && /CREW SYNCED/.test(pill)) fail = true;
    if (mode === 'https') await page.screenshot({ path: path.join(ROOT, 'shots', 'crewjson-mobile.png') });
    await ctx.close();
  }
  await browser.close(); console.log(fail ? 'FAIL' : 'PASS'); process.exit(fail ? 1 : 0);
})();
