// v4.2 Margins panel unit tests: light thresholds, confidence, date parsing, blanks, one vs many points, pallet filtering.
// Runs the functions extracted from the BUILT index.html in a Node vm:  node tests/check_v42_margins.js
const fs = require('fs'), path = require('path'), vm = require('vm');
const html = fs.readFileSync(path.join(__dirname, '..', 'index.html'), 'utf8');
const cut = (a, b) => { const i = html.indexOf(a), j = html.indexOf(b, i); if (i < 0 || j < 0) throw new Error('marker not found: ' + a); return html.slice(i, j); };
const src = 'const CONFIG={tz:"America/Sao_Paulo",palletStartDate:"2026-10-08",brlPerUsd:5.14,commissionRate:0.05};\n'
  + cut('/* v4.1 (V4-3)', '/* ONE number source') + '\n' + cut('/* ONE number source', 'function findDateCol') + '\n'
  + cut('/* ---- v4.2 PURE BEGIN', '/* ---- v4.2 PURE END') + '\n'
  + 'this.T={num,parseDate,compute,v42ShowSpark,v42Pallet,v42Light,v42Conf,v42Day,v42Num,v42Records,v42Model,v42SparkPts};';
const ctx = {}; vm.createContext(ctx); vm.runInContext(src, ctx); const T = ctx.T;
let pass = 0, fail = 0; const t = (name, fn) => { let got, ok = false; try { got = fn(); ok = got === true || (Array.isArray(got) && got[0] === true); } catch (e) { got = 'THREW ' + e.message; }
  if (ok) pass++; else { fail++; console.log('FAIL', name, JSON.stringify(got)); } };
const L = (m, c) => T.v42Light(m, c).light;
// ---- thresholds
[[35, 'green'], [34.9, 'yellow'], [20, 'yellow'], [19.9, 'red'], [62.6, 'green'], [0, 'red'], [-5, 'red'], [100, 'green']].forEach(([m, e]) =>
  t(`light ${m}% high -> ${e}`, () => [L(m, 'high') === e, L(m, 'high')]));
t('blank margin -> red', () => [L(null, 'high') === 'red' && L(undefined, 'high') === 'red' && L(NaN, 'high') === 'red', 0]);
t('blank margin + low -> red (cap never raises)', () => [L(null, 'low') === 'red', 0]);
// ---- confidence
t('low caps green at yellow (35, 62.6)', () => [L(35, 'low') === 'yellow' && L(62.6, 'low') === 'yellow' && T.v42Light(62.6, 'low').capped === true, 0]);
t('low keeps yellow/red', () => [L(34.9, 'low') === 'yellow' && L(19.9, 'low') === 'red' && T.v42Light(25, 'low').capped === false, 0]);
t('medium keeps its colour and gets the tag', () => { const g = T.v42Light(35, 'medium'), y = T.v42Light(20, 'medium'), r = T.v42Light(19.9, 'medium'); return [g.light === 'green' && y.light === 'yellow' && r.light === 'red' && g.medium && y.medium && r.medium, [g, y, r]]; });
t('high/blank: no tag', () => [!T.v42Light(40, 'high').medium && !T.v42Light(40, '').medium, 0]);
t('confidence spellings', () => { const g = ['high', 'High', ' H ', 'medium', 'M', 'med', 'LOW', 'l', '', null, 'maybe'].map(T.v42Conf); return [JSON.stringify(g) === JSON.stringify(['high', 'high', 'high', 'medium', 'medium', 'medium', 'low', 'low', null, null, null]), g]; });
// ---- date parsing
[['2026-10-18', '2026-10-18'], [' 2026-10-18 ', '2026-10-18'], ['2026-10-18 09:00', '2026-10-18'], ['2026-10-18T09:00:00-03:00', '2026-10-18'], ['18/10/2026', '2026-10-18'], ['1/2/2026', '2026-02-01'],
 ['Date(2026,9,18)', '2026-10-18'], ['Date(2026,0,1,9,0,0)', '2026-01-01'], [46313, '2026-10-18'], ['46313', '2026-10-18'],
 ['2026-02-30', null], ['31/02/2026', null], ['2026-13-01', null], ['garbage', null], ['', null], [null, null], [123, null], ['10/18/2026', null]].forEach(([v, e]) =>
  t(`day ${JSON.stringify(v)} -> ${e}`, () => { const g = T.v42Day(v); return [g === e, g]; }));
// ---- blanks and cells
const C = a => a.map(x => x && typeof x === 'object' ? x : { v: x === '' ? null : x, f: null });
const row = (d, p, cBrl, cUsd, tcg, m, conf, link = 'https://www.tcgplayer.com/product/1') => C([d, p, cBrl, cUsd, 5.14, tcg, link, null, m, conf, null, '']);
t('blank cells stay null (never 0)', () => { const r = T.v42Records([row('2026-10-18', 'X', '', '', '', '', '')]).rows[0]; return [r.costUsd === null && r.tcgUsd === null && r.margin === null && r.conf === null, r]; });
t('CSV text numbers read as numbers', () => { const r = T.v42Records([row('2026-10-18', 'X', '11033.33', '2146.56', '3664.54', '62.6', 'low')]).rows[0]; return [r.costUsd === 2146.56 && r.tcgUsd === 3664.54 && r.margin === 62.6 && r.costBrl === 11033.33, r]; });
t('percent-formatted cell uses the shown %', () => { const r = T.v42Records([C(['2026-10-18', 'X', null, null, null, null, null, null, { v: 0.626, f: '62.6%' }, 'high'])]).rows[0]; return [r.margin === 62.6, r.margin]; });
t('rows without product dropped; undated rows counted, not shown', () => { const R = T.v42Records([row('2026-10-18', '', 1, 1, 1, 50, 'high'), row('nope', 'X', 1, 1, 1, 50, 'high'), row('2026-10-18', 'Y', 1, 1, 1, 50, 'high')]); return [R.rows.length === 1 && R.undated.length === 1 && R.rows[0].product === 'Y' && R.rows[0].row === 4, R]; });
t('non-TCGplayer link is not used', () => { const r = T.v42Records([row('2026-10-18', 'X', 1, 1, 1, 50, 'high', 'javascript:alert(1)')]).rows[0]; return [r.link === null, r.link]; });
// ---- latest row, one vs many points
const recs = T.v42Records([
  row('2026-10-18', 'A', 1, 10, 20, 40, 'high'),
  row('2026-10-20', 'A', 1, 10, 20, 30, 'medium'),
  row('2026-10-19', 'A', 1, 10, 20, 50, 'high'),        // out of order in the sheet
  row('2026-10-18', 'B', 1, 10, 20, 62.6, 'low'),
  row('2026-10-18', 'C', 1, 10, 20, 10, 'high'),
  row('2026-10-18', 'C', 1, 10, 20, 12, 'high'),        // same day: the lower row wins
  row('2026-10-18', 'D', 1, null, null, null, null),    // product priced but no verified data
  row('2026-10-18', 'OLD', 1, 10, 20, 50, 'high'),      // not on the pallet
  row('2026-10-18', 'a', 1, 10, 20, 50, 'high')         // case differs: no match
]).rows;
const M = T.v42Model(recs, ['A', 'B', 'C', 'D', 'E']);
const it = p => M.items.find(i => i.product === p);
t('latest row = latest date, not sheet order', () => [it('A').latest.day === '2026-10-20' && it('A').margin === 30 && it('A').light === 'yellow' && it('A').medium, it('A')]);
t('many points: one per day in date order', () => [JSON.stringify(it('A').spark.map(p => p.margin)) === '[40,50,30]', it('A').spark]);
t('same day: last sheet row wins, one point', () => [it('C').margin === 12 && it('C').spark.length === 1 && it('C').light === 'red', it('C')]);
t('one date -> no sparkline at all; 2+ dates -> sparkline', () => [T.v42ShowSpark(it('B').spark) === false && T.v42ShowSpark([]) === false && T.v42ShowSpark(it('A').spark) === true && T.v42ShowSpark(it('C').spark) === false, 0]);
t('one point geometry (unused on screen) stays centred', () => { const P = T.v42SparkPts(it('B').spark, 64, 20); return [P.length === 1 && P[0].x === 32 && P[0].y === 10, P]; });
t('many points -> polyline across the box', () => { const P = T.v42SparkPts(it('A').spark, 64, 20); return [P.length === 3 && P[0].x === 2 && P[2].x === 62 && P[1].y === 2 && P[2].y === 18, P]; });
t('no margin -> no points, red, values null', () => { const d = it('D'); return [d.spark.length === 0 && T.v42SparkPts(d.spark, 64, 20).length === 0 && d.light === 'red' && d.latest.costUsd === null, d]; });
t('low 62.6 shows yellow', () => [it('B').light === 'yellow' && it('B').capped, it('B')]);
// ---- pallet filtering (real compute() rule: PURCHASES lines dated on/after 2026-10-08; undated kept)
const purch = [['S1', 'A', 2, 'R$ 100', '10/10/2026'], ['S1', 'OLD', 1, 'R$ 50', '01/10/2026'], ['S2', 'B', 1, 'R$ 10', '08/10/2026'], ['S2', 'C', 1, 'R$ 10', '07/10/2026'], ['S3', 'D', 1, 'R$ 10', null]];
const st = T.compute(purch, []);
const pal = T.v42Pallet(st);
t('pallet = lines on/after 8 Oct + undated, largest spend first', () => [JSON.stringify(pal) === '["A","B","D"]', pal]);
t('panel does not depend on the ORDERS tab (no cargoRows/#cargo)', () => { const m = cut('/* ================= v4.2 MARGINS', '/* ================= BOOT'); return [!/cargoRows|#cargo|"cargo"|pOrders/.test(m), 0]; });
const M2 = T.v42Model(recs, pal);
t('only pallet products shown, in pallet order', () => [JSON.stringify(M2.items.map(i => i.product)) === '["A","B","D"]', M2.items.map(i => i.product)]);
t('unmatched = US COMPS products not on the pallet (exact, case-sensitive)', () => [JSON.stringify(M2.unmatched) === '["C","OLD","a"]', M2.unmatched]);
t('pallet product without US COMPS row is simply absent', () => [!M.items.some(i => i.product === 'E'), 0]);
t('no rows -> empty model (empty state)', () => { const E = T.v42Model([], ['A']); return [E.items.length === 0 && E.unmatched.length === 0, E]; });
t('whitespace around names is trimmed on both sides', () => { const R = T.v42Records([row('2026-10-18', '  A  ', 1, 1, 1, 50, 'high')]).rows; return [T.v42Model(R, [' A']).items.length === 1, 0]; });
// ---- the built panel never contains example data or rejected widgets
const mod = cut('/* ================= v4.2 MARGINS', '/* ================= BOOT');
t('no rejected widgets / example data in the module', () => { const hits = ['EXAMPLE', 'buy zone', 'decision strip', 'rate stamp', 'data-age', 'Math.random()*', 'demo'].filter(k => mod.toLowerCase().includes(k.toLowerCase()) && !/no rate stamp, no data-age dots, no buy zone, no decision strip/.test(k)); const body = mod.replace(/no rate stamp, no data-age dots, no buy zone, no decision strip/, ''); const h2 = ['EXAMPLE', 'buy zone', 'decision strip', 'rate stamp', 'data-age'].filter(k => body.toLowerCase().includes(k.toLowerCase())); return [h2.length === 0, h2]; });
t('footnote and empty state text present', () => [mod.includes('margin = TCG vs our cost + 5% commission, before shipping &amp; fees') && mod.includes("Margins appear after Robin's first price check"), 0]);
t('MARGINS tab icon = art/v42/icon-margins32.png (drawn in-house by tools/v42_icon.py)', () => { const b = fs.readFileSync(path.join(__dirname, '..', 'art', 'v42', 'icon-margins32.png')).toString('base64'); return [mod.includes('const V42_ICON="data:image/png;base64,' + b + '"'), 0]; });
t('MARGINS is its own tab (data-tab margins), not on the Money tab', () => [mod.includes('"data-tab":"margins"') && !mod.includes('"data-tab":"money"') && mod.includes('v41Tab("margins")'), 0]);
t('panel numbers use the system font with tabular figures (no Pixelify digits)', () => [/#pMargins \.mgPct,\.v4 #pMargins \.money,\.v4 #pMargins \.mgB>span:last-child\{font-family:var\(--ui\)!important;font-variant-numeric:tabular-nums/.test(mod) && !/\.mgPct\{font-family:"PIX"/.test(mod), 0]);
t('MARGINS tab label never wraps', () => [mod.includes('#tabbar button[data-tab=margins] span{white-space:nowrap'), 0]);
console.log(`${pass}/${pass + fail} passed`); process.exit(fail ? 1 : 0);
