/* ================= v4.3.2 (owner via Law 00:26, supersedes the 00:16 2x zoom): the Ship tab OPENS at (k+1)x =================
   On the phone the ship opens one whole step bigger than the fit (k=3 -> 4 device px per art px on iPhone 16 Pro, still crisp: a
   scale((k+1)/k) of the k-scaled canvas), centred horizontally (a strip of hull is cropped on each side; #stageWrap clips, the page
   never scrolls sideways). One-finger / mouse drag pans up and down only, clamped to the ship plus V4Z_SEA rows of sea. Double-tap /
   double-click toggles between the whole ship (k) and (k+1), animated around the tap point (snaps under prefers-reduced-motion).
   Taps act immediately (no single-tap delay); only the second tap of a double tap is swallowed. */
const V4Z_SEA=24; // art rows of sea allowed past the hull top/bottom while panning
const V4Z={s:1,tx:0,ty:0,g:null,drag:null,down:null,last:null,dblUntil:0,moved:false,key:"",anim:0,init:false};
const v4zPhone=()=>window.matchMedia("(max-width:640px)").matches&&window.innerHeight>window.innerWidth;
const v4zBig=()=>(V4.k+1)/V4.k;
function v4zGeo(){const w=$("stageWrap").getBoundingClientRect(),st=$("stage"),pv=st.style.transform,ptr=st.style.transition;st.style.transition="none";st.style.transform="";
  const s=st.getBoundingClientRect(),c=V4.cv.getBoundingClientRect();st.style.transform=pv;void st.offsetWidth;st.style.transition=ptr;const k=c.width/WW;
  const pr=document.createElement("div");pr.style.cssText="position:fixed;top:0;height:0;padding-top:env(safe-area-inset-top,0px);visibility:hidden";document.body.appendChild(pr);const safe=pr.offsetHeight||0;pr.remove();
  return {safe,wl:w.left,wt:w.top,W:w.width,H:w.height,sl:s.left,st:s.top,x0:c.left-s.left,y0:c.top-s.top+V4.oy*k,sw:c.width,sh:WH*k,ak:k,oy:V4.oy};}
function v4zClamp(){const G=V4Z.g,s=V4Z.s;if(!G||s===1){V4Z.tx=V4Z.ty=0;return;}
  const cl=(v,lo,hi)=>lo>hi?(lo+hi)/2:Math.min(hi,Math.max(lo,v)),m=Math.min(V4Z_SEA,G.oy)*G.ak;
  V4Z.tx=G.wl+G.W/2-G.sl-s*(G.x0+G.sw/2);                                        // always centred horizontally
  V4Z.ty=cl(V4Z.ty,G.wt+G.H-G.st-s*(G.y0+G.sh+m),G.wt+G.safe-G.st-s*(G.y0-m));} // the top clamp sits under the status bar / Dynamic Island
function v4zApply(anim){const st=$("stage"),dpr=window.devicePixelRatio||1,r=v=>Math.round(v*dpr)/dpr,on=V4Z.s>1,an=anim&&!REDUCED;
  st.style.transition=an?"transform .24s ease-out":"none";st.style.transformOrigin="0 0";
  st.style.transform=on?`translate(${r(V4Z.tx)}px,${r(V4Z.ty)}px) scale(${V4Z.s})`:"";
  if(an){clearTimeout(V4Z.anim);V4Z.anim=setTimeout(()=>{V4Z.anim=0;st.style.transition="none";},280);}else{clearTimeout(V4Z.anim);V4Z.anim=0;}
  st.style.setProperty("--zi",on?String(1/V4Z.s):"1");document.body.classList.toggle("zoom4",on);V4.lastKey=null;}
/* zoom to scale s keeping the art point under (cx,cy) in place vertically (horizontal stays centred) */
function v4zSet(s,cx,cy,anim){const G=V4Z.g=v4zGeo(),s0=V4Z.s,ly=cy==null?null:(cy-G.st-V4Z.ty)/s0;V4Z.s=s;
  V4Z.ty=s===1?0:(ly==null?G.wt+G.H/2-G.st-s*(G.y0+G.sh/2):cy-G.st-s*ly);v4zClamp();
  V4Z.key=V4.cv.style.width+V4.cv.style.height+innerWidth+"x"+innerHeight;v4zApply(anim);}
function v4zDefault(){if(!V4.ready||!V4.cv.style.width)return;v4zSet(v4zPhone()?v4zBig():1,null,null,false);V4Z.init=true;}
{const st=$("stage"),cv=V4.cv;
  st.addEventListener("click",ev=>{if(ev.target!==cv)return;if(V4Z.moved||performance.now()<V4Z.dblUntil){ev.stopImmediatePropagation();ev.preventDefault();}},true);
  cv.addEventListener("dblclick",ev=>ev.preventDefault());
  // iOS Safari: no pinch-zoom of the whole page from the Ship tab (gesture events are Safari-only; harmless elsewhere)
  ["gesturestart","gesturechange"].forEach(t=>document.addEventListener(t,ev=>{if(document.body.dataset.tab==="ship"||!document.body.dataset.tab)ev.preventDefault();},{passive:false}));
  st.addEventListener("touchmove",ev=>{if(ev.touches.length>1)ev.preventDefault();},{passive:false});
  cv.addEventListener("pointerdown",ev=>{V4Z.down={id:ev.pointerId,x:ev.clientX,y:ev.clientY};
    if(V4Z.s===1)return;V4Z.drag={id:ev.pointerId,y:ev.clientY,ty:V4Z.ty,on:false};V4Z.moved=false;});
  cv.addEventListener("pointermove",ev=>{const D=V4Z.drag;if(!D||D.id!==ev.pointerId)return;const dy=ev.clientY-D.y,d0=V4Z.down;
    if(!D.on&&Math.hypot(ev.clientX-(d0?d0.x:ev.clientX),dy)<8)return;if(!D.on){D.on=true;try{cv.setPointerCapture(ev.pointerId);}catch(e){}}
    V4Z.moved=true;V4Z.ty=D.ty+dy;v4zClamp();v4zApply(false);ev.preventDefault();});
  const up=ev=>{const D=V4Z.drag;if(D&&D.id===ev.pointerId){V4Z.drag=null;if(D.on){setTimeout(()=>{V4Z.moved=false;},400);V4Z.last=null;V4Z.down=null;return;}}
    const d=V4Z.down;V4Z.down=null;if(ev.type!=="pointerup"||!d||d.id!==ev.pointerId||Math.hypot(ev.clientX-d.x,ev.clientY-d.y)>=8){V4Z.last=null;return;}
    const now=performance.now(),L=V4Z.last;
    if(L&&now-L.t<350&&Math.hypot(ev.clientX-L.x,ev.clientY-L.y)<40){V4Z.last=null;V4Z.dblUntil=now+450;v4zSet(V4Z.s>1?1:v4zBig(),L.x,L.y,true);}
    else V4Z.last={t:now,x:ev.clientX,y:ev.clientY};};
  cv.addEventListener("pointerup",up);cv.addEventListener("pointercancel",up);
  // the default view is set once the ship is sized, and again after a real resize / rotation
  const _f=fitV4;fitV4=function(){const r=_f.apply(this,arguments);const key=V4.cv.style.width+V4.cv.style.height+innerWidth+"x"+innerHeight;
    if(!V4Z.init||V4Z.key!==key)requestAnimationFrame(v4zDefault);return r;};
  const iv=setInterval(()=>{if(V4.ready&&V4.cv.style.width&&!V4Z.init){v4zDefault();}if(V4Z.init)clearInterval(iv);},200);}
