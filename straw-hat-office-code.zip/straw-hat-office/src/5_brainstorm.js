/* ================= WORK vs BREAK + BRAINSTORMS (break room, idea board, transcripts, upvotes) ================= */
/* v4.1 (owner via Nami 20:23): fed ONLY by the real BRAINSTORMS tab; the example sessions are gone. Empty -> "No brainstorms yet". */
const isOnBreak=a=>v4State(a)!=="working"; // v4.1: same rule as the shown state (blank = resting)
const inBreakRoom=a=>!a.walking&&a.at&&(BREAK_SPOTS.includes(a.at)||a.at==="rest1"||a.at==="rest2"||a.at==="aquarium");
function brainSessions(){const f=FEEDS.brainstorms;
  if(f&&f.ok&&f.rows.length){const by={};f.rows.forEach(r=>{const k=String(r.session_id);(by[k]=by[k]||{session_id:k,time:r.time,topic:r.topic||"",lines:[],live:true}).lines.push({speaker:String(r.speaker||"").trim().toLowerCase(),message:String(r.message||""),idea:r.idea?String(r.idea):null,sources:r.sources?String(r.sources):null,time:r.time});});
    return Object.values(by).sort((a,b)=>(parseDate(a.time)||0)-(parseDate(b.time)||0));}
  return [];}
const ideaKey=(s,i)=>s.session_id+"#"+i;
function allIdeas(){const out=[];brainSessions().forEach(s=>s.lines.forEach((l,i)=>{if(l.idea)out.push({key:ideaKey(s,i),text:l.idea,speaker:l.speaker,session:s,example:!!s.example});}));const v=LS.get("votes",{});out.forEach(o=>o.votes=v[o.key]||0);return out;}
/* break-room conversations */
let CONVO=null,convoCD=0;const BS_PLAYED=new Set(); // v4.1: each real BRAINSTORMS session plays at most once per visit
function startConvo(force){const here=agents.filter(inBreakRoom);if(CONVO||(here.length<2&&!force))return false;const S=brainSessions();if(!S.length)return false;
  const s=S.find(x=>!BS_PLAYED.has(x.session_id));if(!s)return false;BS_PLAYED.add(s.session_id);CONVO={s,i:0,next:performance.now()+800,here:here.map(a=>a.id)};
  banner("bs","💡 BRAINSTORM · "+(s.topic||s.session_id),9000);
  for(let i=0;i<here.length;i++)for(let j=i+1;j<here.length;j++)addFriend(here[i].id,here[j].id,1,"brainstorms",true);return true;}
HOOK.tick.push(()=>{const now=performance.now();if(!CONVO){if(now>convoCD&&!MEETING.active&&agents.filter(inBreakRoom).length>=2){startConvo();}return;}
  if(now<CONVO.next)return;const L=CONVO.s.lines[CONVO.i];if(!L){CONVO=null;convoCD=now+45000;return;}
  const sp=agents.find(a=>a.id===L.speaker&&inBreakRoom(a)); // v4.1 (Law D): speaker lock; a line is never handed to another bot. Speaker not in the room -> line skipped
  if(sp){say(sp,L.message,4000);if(L.idea){emote(sp,"💡",2600);setTimeout(()=>{IDEAFLASH=performance.now();},1200);}}
  CONVO.i++;CONVO.next=now+3800;});
let IDEAFLASH=0;
/* idea board (easel with sticky notes) */
const IB={x:279,y:240,w:20,h:24};
HOOK.depth.push(t=>[{b:IB.y+IB.h+2,d:()=>{const{x,y,w,h}=IB;R(ctx,x+2,y+h,2,4,"#5c3416");R(ctx,x+w-4,y+h,2,4,"#5c3416");R(ctx,x-1,y-1,w+2,h+2,OUTL);R(ctx,x,y,w,h,"#c9915a");R(ctx,x,y,w,1,"#e0b07a");
  const n=Math.min(12,allIdeasCached().length),C=["#ffe680","#ffb0c8","#a6f27c","#7fd8ff"];for(let i=0;i<n;i++){const cx=x+2+(i%3)*6,cy=y+2+Math.floor(i/3)*5;R(ctx,cx,cy,5,4,C[i%4]);R(ctx,cx+1,cy+1,3,1,"rgba(0,0,0,.25)");}
  if(t-IDEAFLASH<1500&&Math.floor(t/150)%2){R(ctx,x-2,y-2,w+4,1,"#fff");R(ctx,x-2,y+h+1,w+4,1,"#fff");}}}]);
const allIdeasCached=memo(()=>allIdeas(),3000);
function onIdeaBoard(ev){const [x,y]=canvasXY(ev);return x>IB.x-2&&x<IB.x+IB.w+2&&y>IB.y-2&&y<IB.y+IB.h+4;}
cv.addEventListener("click",ev=>{if(!onIdeaBoard(ev))return;ev.stopImmediatePropagation();openBrainstorms();},true);
cv.addEventListener("mousemove",ev=>{if(onIdeaBoard(ev))cv.style.cursor="pointer";});
function openBrainstorms(tab){const box=el("div"),tabs=el("div",{class:"tabs"}),area=el("div");const S=brainSessions();
  if(!S.length){box.append(el("div",{class:"note bsEmpty"},"No brainstorms yet."));openModal("BRAINSTORMS",box);return;}
  box.append(el("div",{class:"note"},"Source: BRAINSTORMS tab."),tabs,area);
  const show=k=>{tabs.querySelectorAll("button").forEach(b=>b.classList.toggle("on",b.dataset.k===k));area.innerHTML="";
    if(k==="ideas"){const I=allIdeas().sort((a,b)=>b.votes-a.votes);if(!I.length)area.append(el("div",{class:"note"},"No ideas yet."));
      I.forEach(o=>{const mine=LS.get("myvotes",{})[o.key];const b=el("button",{class:"btn vote"+(mine?" green":""),style:"min-width:56px",onclick:()=>{const v=LS.get("votes",{}),m=LS.get("myvotes",{});if(m[o.key]){v[o.key]=Math.max(0,(v[o.key]||1)-1);delete m[o.key];}else{v[o.key]=(v[o.key]||0)+1;m[o.key]=1;}LS.set("votes",v);LS.set("myvotes",m);beep(880,.05);show("ideas");}},"▲ "+o.votes);
        area.append(el("div",{class:"upg"},b,el("div",{},el("b",{},o.text),el("div",{class:"note"},`${nameOf(o.speaker)} · ${o.session.topic||o.session.session_id}`))));});}
    else S.slice().reverse().forEach(s=>{const d=el("details",{open:""},el("summary",{style:"cursor:pointer;font-family:PIX;font-size:8px;margin:6px 0"},(s.topic||s.session_id)+(s.time?" · "+fmtTime(s.time,true):"")));
      s.lines.forEach(l=>d.append(el("div",{style:"font-size:17px;padding:1px 0"},el("b",{style:"color:#c8323c"},nameOf(l.speaker)+": "),l.message,l.idea?el("span",{class:"seed",style:"color:#2f7a3a;border-color:#2f7a3a"},"💡 "+l.idea):"")));area.append(d);});};
  [["ideas","IDEAS + UPVOTES"],["log","TRANSCRIPTS"]].forEach(([k,l])=>tabs.append(el("button",{class:"btn","data-k":k,onclick:()=>show(k)},l)));
  openModal("BRAINSTORM BOARD",box);show(tab||"ideas");}
/* break preview (does not touch real data) */
function previewBreak(on){const ids=["brook","usopp","nami","chopper"];agents.forEach(a=>{if(on&&ids.includes(a.id)){a._realState=a._realState??a.state;a.state="break";a.wait=300;}else if(!on&&a._realState!==undefined){a.state=a._realState;delete a._realState;a.wait=300;}});renderRoster();banner("brk",on?"☕ Break preview: 4 crew sent to the lounge (not real data)":"Back to work (preview ended)",4000);}
setInterval(()=>document.querySelectorAll("#roster .wb").forEach(e=>{const a=agents.find(x=>x.id===e.dataset.id);if(!a)return;const b=isOnBreak(a)||a.resting;e.className="wb "+(b?"brk":"wrk");e.textContent=a.resting?"RESTING":b?"ON BREAK":"WORKING";}),1500);
