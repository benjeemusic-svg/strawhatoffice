/* ================= REWARDS: weekly MVP only (wanted posters + upgrades removed in v3.1; achievements, XP and quests removed in v4.1) ================= */
const deliveries=(id,sinceMs)=>allHistory().filter(h=>h.crew===id&&(!sinceMs||(asDate(h.at)||new Date(0)).getTime()>=sinceMs));
function weekStart(){const n=spNow();const d=new Date(Date.UTC(n.y,n.m-1,n.d));const wd=(d.getUTCDay()+6)%7;return Date.UTC(n.y,n.m-1,n.d-wd)+3*3600*1000;} // Monday 00:00 BRT
function weekKey(){return new Date(weekStart()).toISOString().slice(0,10);}
function weeklyMVP(){const since=weekStart();let best=null;agents.forEach(a=>{const n=deliveries(a.id,since).length;if(n>0&&(!best||n>best.n))best={a,n};});return best;}
function currentMVP(){const m=LS.get("mvp",null);return m&&m.week===weekKey()?m:null;}
/* v4.1: achievements + trophy shelf removed (owner list 19:25); weekly MVP (meetings) stays */
HOOK.fx.push(t=>{
  const m=currentMVP();if(m){const a=agents.find(x=>x.id===m.crew);if(a){const y=Math.round(a.y-LOOKS[a.id].ht-4);R(ctx,a.x-3,y+2,7,2,"#ffd24a");[a.x-3,a.x,a.x+3].forEach(x=>R(ctx,x,y,1,2,"#ffd24a"));R(ctx,a.x,y+2,1,1,"#c8323c");}}});
