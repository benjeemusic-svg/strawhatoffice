/* ================= v4.2 MARGINS panel (Money tab, under the money card) =================
   Source: Robin's US COMPS tab of the public tracker, read like the PURCHASES tab (gviz with its own 7 s slice inside ONE 12 s deadline, then the
   CSV export of the same tab). Robin's columns are shown as they are (col I, confirmed by Robin 23:00: (F − D×1.05) / (D×1.05) × 100, markup on cost + the 5% commission): our cost US$ (D, already at 5.14), TCGplayer market US$ (F), margin % (I),
   confidence (J), TCGplayer link (G). Nothing is recomputed and nothing is invented: a blank cell means "no verified data".
   Only products of the current pallet are listed (stats.byProd = PURCHASES lines since CONFIG.palletStartDate, the same rule as the money card),
   matched by exact product name (whitespace-trimmed, case-sensitive). US COMPS products that do not match stay off screen (V42.unmatched / console).
   Owner (via Nami): no rate stamp, no data-age dots, no buy zone, no decision strip. */
/* ---- v4.2 PURE BEGIN (unit-tested by tests/check_v42_margins.js) ---- */
const V42_TAB="US COMPS", V42_GID="1509506030";
/* health light: green >= 35, yellow 20..<35, red < 20 or blank; low confidence caps at yellow; medium keeps its colour and gets a tag */
function v42Light(margin,conf){const m=(typeof margin==="number"&&isFinite(margin))?margin:null, c=v42Conf(conf);
  let light=m==null?"red":m>=35?"green":m>=20?"yellow":"red", capped=false;
  if(c==="low"&&light==="green"){light="yellow";capped=true;}
  return {light,capped,medium:c==="medium",conf:c,margin:m};}
function v42Conf(v){const s=String(v==null?"":v).trim().toLowerCase();if(!s)return null;
  if(/^h(igh)?$/.test(s))return "high";if(/^m(ed|edium)?$/.test(s))return "medium";if(/^l(ow)?$/.test(s))return "low";return null;}
/* column A -> "YYYY-MM-DD" (a calendar day, no time zone shift) or null. Accepts 2026-10-18, 18/10/2026 (BR day first), gviz Date(2026,9,18) and Sheets serials. */
function v42Day(v){if(v==null||v==="")return null;let m,y,mo,d;
  const ok=(y,mo,d)=>{const x=new Date(Date.UTC(y,mo-1,d));return mo>=1&&mo<=12&&d>=1&&x.getUTCFullYear()===y&&x.getUTCMonth()===mo-1&&x.getUTCDate()===d;};
  const out=(y,mo,d)=>ok(y,mo,d)?`${y}-${String(mo).padStart(2,"0")}-${String(d).padStart(2,"0")}`:null;
  if(typeof v==="number"){if(!(v>20000&&v<80000))return null;const x=new Date(Date.UTC(1899,11,30)+Math.floor(v)*86400000);return out(x.getUTCFullYear(),x.getUTCMonth()+1,x.getUTCDate());}
  const s=String(v).trim();
  if((m=s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})(?:$|[\sT])/)))return out(+m[1],+m[2],+m[3]);
  if((m=s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})(?:$|[\s,T])/)))return out(+m[3],+m[2],+m[1]);
  if((m=s.match(/^Date\((\d{4}),(\d{1,2}),(\d{1,2})/)))return out(+m[1],+m[2]+1,+m[3]);
  if(/^\d{5}(\.\d+)?$/.test(s))return v42Day(parseFloat(s));
  return null;}
/* a cell -> number or null (blank, "#N/A", text). Percent cells formatted as "62.6%" with a fractional value are read from the formatted text. */
function v42Num(v,f){if(f!=null&&/%\s*$/.test(String(f))){const n=num(String(f).replace("%",""));return n;}return num(v);}
/* raw sheet rows (arrays of {v,f} cells in column order A..L) -> records; rows without a product are dropped, rows without a valid date are counted */
function v42Records(raw){const out=[],bad=[];(raw||[]).forEach((c,i)=>{const g=k=>c[k]||{v:null,f:null};
    const product=String(g(1).v==null?"":g(1).v).trim(); if(!product)return;
    const day=v42Day(g(0).v);
    const link=String(g(6).v==null?"":g(6).v).trim();
    const r={i,row:i+2,day,product,costBrl:v42Num(g(2).v,g(2).f),fx:v42Num(g(4).v,g(4).f),costUsd:v42Num(g(3).v,g(3).f),tcgUsd:v42Num(g(5).v,g(5).f),link:/^https:\/\/(www\.)?tcgplayer\.com\//i.test(link)?link:null,margin:v42Num(g(8).v,g(8).f),conf:v42Conf(g(9).v)};
    if(!day){bad.push(r);return;} out.push(r);});
  return {rows:out,undated:bad};}
/* records + pallet product names (in display order) -> panel model. Latest row = latest day; same day -> the row lower in the sheet (Robin appends). */
function v42Model(records,palletProducts){const by={};(records||[]).forEach(r=>{(by[r.product]=by[r.product]||[]).push(r);});
  const pal=(palletProducts||[]).map(p=>String(p).trim()), set=new Set(pal);
  const items=[];pal.forEach(p=>{const L=by[p];if(!L||!L.length)return;
    const s=L.slice().sort((a,b)=>a.day<b.day?-1:a.day>b.day?1:a.i-b.i), last=s[s.length-1];
    const perDay={};s.forEach(r=>{if(r.margin!=null)perDay[r.day]=r.margin;}); // one point per day: the last row with a margin that day
    const spark=Object.keys(perDay).sort().map(d=>({day:d,margin:perDay[d]}));
    items.push(Object.assign({product:p,latest:last,spark},v42Light(last.margin,last.conf)));});
  const unmatched=Object.keys(by).filter(p=>!set.has(p)).sort();
  return {items,unmatched};}
/* sparkline geometry in a w x h box: x by calendar day, y by margin; one point -> a dot only */
function v42SparkPts(spark,w,h){const pad=2;if(!spark||!spark.length)return [];
  const t=spark.map(p=>Date.UTC(+p.day.slice(0,4),+p.day.slice(5,7)-1,+p.day.slice(8,10))), t0=Math.min(...t), t1=Math.max(...t);
  const m=spark.map(p=>p.margin), lo=Math.min(...m), hi=Math.max(...m);
  return spark.map((p,i)=>({x:spark.length===1||t1===t0?w/2:pad+(w-2*pad)*(t[i]-t0)/(t1-t0),y:hi===lo?h/2:pad+(h-2*pad)*(1-(p.margin-lo)/(hi-lo))}));}
/* current-pallet product names, by total R$ spent (largest first): straight from stats.byProd (compute()), no dependency on the removed ORDERS tab */
function v42Pallet(s){return Object.entries((s&&s.byProd)||{}).sort((a,b)=>(b[1].v||0)-(a[1].v||0)||a[0].localeCompare(b[0])).map(e=>e[0]);}
/* owner 23:00: the sparkline only appears with 2+ dated margins (a lone dot read as a stray mark) */
const v42ShowSpark=spark=>!!spark&&spark.length>=2;
/* ---- v4.2 PURE END ---- */
const V42={raw:null,live:false,loading:true,busy:false,at:0,unmatched:[],undated:0,note:""};
/* gviz: keep each cell's raw value AND formatted text; validated by headers because gviz silently returns the FIRST tab for an unknown name */
function v42LoadGviz(deadline){return new Promise((res,rej)=>{const cb="__v42"+Date.now()+Math.random().toString(36).slice(2,6);const s=document.createElement("script");
  const to=setTimeout(()=>{cleanup();rej(new Error("timeout"));},Math.max(0,deadline-Date.now()));
  function cleanup(){clearTimeout(to);window[cb]=()=>{};setTimeout(()=>{try{delete window[cb];}catch(e){}},120000);s.remove();}
  window[cb]=data=>{cleanup();try{if(data.status==="error")throw new Error("gviz error");const lab=data.table.cols.map(c=>String(c.label||"").trim().toLowerCase());
      if(lab[0]!=="date"||lab[1]!=="product"||!/^margin/.test(lab[8]||""))throw new Error("US COMPS headers not found");
      res(data.table.rows.map(r=>(r.c||[]).map(c=>c?{v:c.v,f:c.f==null?null:c.f}:{v:null,f:null})));}catch(e){rej(e);}};
  s.onerror=()=>{cleanup();rej(new Error("script load failed"));};
  s.src=`https://docs.google.com/spreadsheets/d/${CONFIG.sheetId}/gviz/tq?tqx=out:json;responseHandler:${cb}&headers=1&sheet=${encodeURIComponent(V42_TAB)}&_=${Date.now()}`;
  document.head.appendChild(s);});}
async function v42LoadCSV(deadline){const left=deadline-Date.now();if(left<=0)throw new Error("deadline passed");const ctl=window.AbortController?new AbortController():null,to=setTimeout(()=>ctl&&ctl.abort(),left);let r;
  try{r=await fetch(`https://docs.google.com/spreadsheets/d/${CONFIG.sheetId}/export?format=csv&gid=${V42_GID}&_=${Date.now()}`,ctl?{signal:ctl.signal}:{});}finally{clearTimeout(to);}
  if(!r.ok)throw new Error("HTTP "+r.status);const all=parseCSV(await r.text()),h=(all[0]||[]).map(x=>String(x).trim().toLowerCase());
  if(h[0]!=="date"||h[1]!=="product"||!/^margin/.test(h[8]||""))throw new Error("US COMPS headers not found");
  return all.slice(1).map(row=>row.map(x=>({v:x===""?null:x,f:null})));}
async function v42Load(){if(V42.busy)return;V42.busy=true;const deadline=Date.now()+SHEET_TIMEOUT_MS;let raw=null;
  try{raw=await v42LoadGviz(Math.min(deadline,Date.now()+GVIZ_SLICE_MS));}catch(e){try{raw=await v42LoadCSV(deadline);}catch(e2){console.warn("US COMPS unavailable",e,e2);}}
  V42.loading=false;V42.busy=false;
  if(raw){V42.raw=raw;V42.live=true;V42.at=Date.now();LS.set("comps42",{at:V42.at,raw});}
  else if(!V42.raw){const c=LS.get("comps42",null);if(c&&Array.isArray(c.raw)){V42.raw=c.raw;V42.live=false;}}
  v42Render();}
/* ---- DOM ---- */
/* v4.2 (owner 22:51): the panel is its OWN phone tab, MARGINS (tab bar SHIP · MONEY · MARGINS · CREW); nothing from v4.2 sits on the Money tab.
   Desktop/landscape keep the side column, where it is a separate panel under MONEY. Icon: art/v42/icon-margins32.png (tools/v42_icon.py), inlined below. */
const V42_ICON="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAwUlEQVR4nO2UMQ4BQRRA34hDUKiERoKIU9AoCEdwhq21CmdQqLXusJXYCxBBK2I7GmOaKWaKMcR/1WaK2ZeX/weEf0eFurg7aD1s5/f0DMBuf1IAhVACrhRD/2A8bAOQZgcAtq8CmugFREAEvLdglTSt+z1bXgCz3678XgFNbzoHIM8WgCngS/QCIvCegaRWtU73Or8B/tPtyvcU0ExGZQCOmytgCoQiegEREAERUI1KyfoCfor4BfRHv1OPUiJ6gSe/ISnSkrBRewAAAABJRU5ErkJggg==";
const v42Sec=el("section",{id:"pMargins",class:"parch tabp","data-tab":"margins","aria-label":"Margins"});
v42Sec.innerHTML='<h2>MARGINS <small>Robin · US COMPS</small></h2><div id="mgList" aria-live="polite"></div><div class="mgFoot">margin = TCG vs our cost + 5% commission, before shipping &amp; fees</div>';
(function(){const pm=$("pMoney");if(pm&&pm.parentNode)pm.parentNode.insertBefore(v42Sec,pm.nextSibling);})();
(function(){const bar=$("tabbar");if(!bar)return;const b=el("button",{type:"button","data-tab":"margins"});b.innerHTML='<i class="tbi tbi-margins"></i><span>MARGINS</span>';
  const m=bar.querySelector('button[data-tab="money"]');bar.insertBefore(b,m?m.nextSibling:null);b.onclick=()=>{beep(600,.04);v41Tab("margins");};})();
(function(){const st=document.createElement("style");st.textContent=`
.v4 #pMargins{margin-top:8px}
.v4 #pMargins h2 small{text-transform:none}
.v4 #mgList{display:flex;flex-direction:column}
.v4 .mg{display:block;padding:8px 0;border-top:1px solid rgba(43,29,24,.12);color:var(--ink4);text-decoration:none;min-height:44px;-webkit-tap-highlight-color:transparent}
.v4 .mg:first-child{border-top:0}
.v4 a.mg:active{background:rgba(43,29,24,.06)}
.v4 .mgTop{display:flex;align-items:center;gap:8px;min-width:0}
.v4 .mgName{flex:1 1 auto;min-width:0;font-weight:700;font-size:16px;overflow-wrap:anywhere}
.v4 .mgSpark{flex:none;width:64px;height:20px;display:block}
.v4 .mgH{display:flex;align-items:center;flex-wrap:wrap;gap:6px;margin:3px 0 4px;font-size:15px}
.v4 .mgL{flex:none;width:14px;height:14px;border:1px solid var(--ink4);box-shadow:inset 1px 1px 0 rgba(246,242,231,.45)}
.v4 .mgL.green{background:var(--green4)}.v4 .mgL.yellow{background:var(--gold4)}.v4 .mgL.red{background:var(--red4)}
.v4 .mgPct{font-family:var(--ui);font-weight:700;font-size:18px;color:var(--ink4)}
/* owner 23:00: Pixelify digits misread (5 as 9, 2 as 8): every number in this panel is the system font with tabular figures; the gold coin stays */
.v4 #pMargins .mgPct,.v4 #pMargins .money,.v4 #pMargins .mgB>span:last-child{font-family:var(--ui)!important;font-variant-numeric:tabular-nums;letter-spacing:0}
.v4 #pMargins .money{font-weight:600}
.v4 .mgConf{color:rgba(43,29,24,.76)}
.v4 .mgTag{font-size:15px;line-height:1;padding:2px 5px;border:1px solid var(--woodD);background:var(--tan);color:var(--ink4);border-radius:2px}
.v4 .mgB{display:grid;grid-template-columns:44px minmax(0,1fr) auto;align-items:center;gap:6px;font-size:15px;margin-top:2px}
.v4 .mgB>span:first-child{color:rgba(43,29,24,.76)}
.v4 .mgBar{height:8px;background:rgba(43,29,24,.08);min-width:0}
.v4 .mgBar>i{display:block;height:100%;background:var(--woodM)}
.v4 .mgB.tcg .mgBar>i{background:var(--teal)}
.v4 .mgB .money,.v4 .mgR .money{font-size:15px}
.v4 .mgR{margin-top:2px;font-size:15px;color:rgba(43,29,24,.76);overflow-wrap:anywhere}
.v4 #pMargins .mgR,.v4 #pMargins .mgRv{font-family:var(--ui)!important;font-variant-numeric:tabular-nums;letter-spacing:0;font-weight:400}
.v4 .mgNone{font-size:15px;color:rgba(43,29,24,.76)}
.v4 .mgEmpty{padding:6px 0;font-size:15px;color:rgba(43,29,24,.76)}
.v4 .mgFoot{margin-top:6px;padding-top:6px;border-top:1px solid rgba(43,29,24,.12);font-size:15px;color:rgba(43,29,24,.76)}
.v4 #tabbar button[data-tab=margins] span{white-space:nowrap;overflow-wrap:normal}
.v4 .tbi.tbi-margins{background:url(${V42_ICON}) center/32px 32px no-repeat}
@media (max-width:640px){
 .v4 #tabbar{grid-template-columns:none!important;grid-auto-flow:column;grid-auto-columns:minmax(0,1fr)}
 .v4[data-tab=margins] #pMargins{display:block!important}
 .v4[data-tab=margins] #pMargins{margin-top:0}
}
`;document.head.appendChild(st);})();
const v42Pct=m=>m==null?"–":m.toLocaleString("en-US",{maximumFractionDigits:1})+"%";
const v42Brl=n=>"R$ "+n.toLocaleString("en-US",{minimumFractionDigits:2,maximumFractionDigits:2});
const v42DayTxt=d=>{const M=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];return +d.slice(8,10)+" "+M[+d.slice(5,7)-1]+" "+d.slice(0,4);};
const v42Usd=n=>n==null?null:"US$ "+n.toLocaleString("en-US",{minimumFractionDigits:2,maximumFractionDigits:2});
function v42SparkSvg(spark){const w=64,h=20,P=v42SparkPts(spark,w,h);if(!P.length)return null;const NS="http://www.w3.org/2000/svg",svg=document.createElementNS(NS,"svg");
  svg.setAttribute("viewBox",`0 0 ${w} ${h}`);svg.setAttribute("class","mgSpark");svg.setAttribute("aria-hidden","true");
  if(P.length>1){const pl=document.createElementNS(NS,"polyline");pl.setAttribute("points",P.map(p=>p.x.toFixed(1)+","+p.y.toFixed(1)).join(" "));pl.setAttribute("fill","none");pl.setAttribute("stroke","#4b3226");pl.setAttribute("stroke-width","1.5");pl.setAttribute("stroke-linejoin","round");svg.appendChild(pl);}
  const q=P[P.length-1],c=document.createElementNS(NS,"circle");c.setAttribute("cx",q.x.toFixed(1));c.setAttribute("cy",q.y.toFixed(1));c.setAttribute("r","2.5");c.setAttribute("fill","#2b1d18");svg.appendChild(c);
  return svg;}
function v42Bar(cls,label,val,scale){const d=el("div",{class:"mgB "+cls});const l=el("span",{},label),b=el("span",{class:"mgBar"}),v=el("span",{});
  if(val!=null&&scale>0){const i=document.createElement("i");i.style.width=Math.max(2,Math.min(100,val/scale*100)).toFixed(1)+"%";b.appendChild(i);v.textContent=v42Usd(val);}else{v.textContent="no data";v.className="mgNone";}
  d.append(l,b,v);return d;}
function v42Render(){const L=$("mgList");if(!L)return;L.innerHTML="";
  if(!stats||(V42.loading&&!V42.raw)){L.appendChild(el("div",{class:"mgEmpty"},"Loading Robin's price check…"));return;}
  const rec=v42Records(V42.raw||[]), pal=v42Pallet(stats), M=v42Model(rec.rows,pal);
  V42.unmatched=M.unmatched;V42.undated=rec.undated.length;V42.items=M.items;
  if(M.unmatched.length)console.warn("US COMPS products not on the current pallet (exact name match):",M.unmatched);
  if(!M.items.length){L.appendChild(el("div",{class:"mgEmpty"},"Margins appear after Robin's first price check"));return;}
  M.items.forEach(it=>{const r=it.latest,A=r.link?el("a",{class:"mg",href:r.link,target:"_blank",rel:"noopener noreferrer"}):el("div",{class:"mg"});A.dataset.p=it.product;A.dataset.light=it.light;
    const top=el("div",{class:"mgTop"}),nm=el("span",{class:"mgName"},it.product);top.appendChild(nm);const sv=v42ShowSpark(it.spark)?v42SparkSvg(it.spark):null;if(sv)top.appendChild(sv);
    const why=it.margin==null?"no margin yet":it.capped?"low confidence, capped at yellow":it.light;
    const hl=el("div",{class:"mgH"}),lt=el("span",{class:"mgL "+it.light,role:"img","aria-label":"health "+it.light+" ("+why+")",title:why});
    hl.append(lt,el("span",{class:"mgPct"},v42Pct(it.margin)),el("span",{class:"mgConf"},it.margin==null?"no margin yet":"margin"));
    if(it.medium)hl.appendChild(el("span",{class:"mgTag"},"medium"));else if(it.conf)hl.appendChild(el("span",{class:"mgConf"},"· "+it.conf+" confidence"));
    const sc=Math.max(r.costUsd||0,r.tcgUsd||0);
    A.append(top,hl,v42Bar("ours","ours",r.costUsd,sc),v42Bar("tcg","TCG",r.tcgUsd,sc));
    /* v4.3.4: R$ beside the US$ (standing rule: R$ and US$ at the partner rate 5.14) + the day Robin checked the price. Ours R$ = Robin's column C as is;
       TCG R$ = column F x 5.14 (marked ≈). A blank cell stays out (never 0). */
    {const R=[];if(r.costBrl!=null)R.push(el("span",{class:"mgRv"},"ours "+v42Brl(r.costBrl)));if(r.tcgUsd!=null)R.push(el("span",{class:"mgRv"},"TCG ≈ "+v42Brl(r.tcgUsd*CONFIG.brlPerUsd)));
     const d=el("div",{class:"mgR"});R.forEach((x,i)=>{if(i)d.appendChild(document.createTextNode(" · "));d.appendChild(x);});
     A.appendChild(d);A.appendChild(el("div",{class:"mgR mgDay"},"Robin checked "+v42DayTxt(r.day)));}
    if(r.link)A.setAttribute("aria-label",it.product+": open on TCGplayer");
    L.appendChild(A);});}
HOOK.data.push(()=>{v42Render();if(!V42.busy&&Date.now()-V42.at>10*60*1000)v42Load();}); // Robin appends daily: re-read at most every 10 min
HOOK.boot.push(()=>{const c=LS.get("comps42",null);if(c&&Array.isArray(c.raw)){V42.raw=c.raw;V42.at=0;}v42Render();v42Load();});
