/* ================= v4.3.2 (Law #1, 00:22): no flat-cut heads on ANY sideways leg =================
   A11 clips a sprite at its room's top wall line. v43Knees only fixed legs that start/end exactly in a door column, so bots still
   walked along a back-wall line with the head sliced off (Law st_law->st_usopp at y=341 in the QA room, Luffy leaving the galley
   door diagonally). General rule now: any walking leg that is more sideways than vertical and would put the head above the wall line
   (outside a door column) is lowered: straight down to the first row where the whole sprite clears the wall, across, then straight
   to the target. Footprints and free-floor checks as in v43Knees; if no clear row exists the leg is left as it was. */
function v432HeadCut(h,q){const r=V4S.rooms[v4Room(q)];return !!(r&&r.floor&&Math.round(q.y)-h<r.y&&!V43_DX.some(x=>Math.abs(x-q.x)<=1));}
function v432LegCut(h,p,q){const n=Math.max(1,Math.ceil(Math.hypot(q.x-p.x,q.y-p.y)));for(let i=0;i<=n;i++){if(v432HeadCut(h,{x:p.x+(q.x-p.x)*i/n,y:p.y+(q.y-p.y)*i/n}))return true;}return false;}
function v432Lower(a,P){if(!P||!P.length)return P;const h=(V4M.characters[a.id]||{}).height||44,out=[];let prev={x:Math.round(a.x),y:Math.round(a.y)};
  P.forEach(p=>{const walk=!p.via||p.via==="walk";
    if(walk&&Math.abs(p.x-prev.x)>Math.abs(p.y-prev.y)&&v432LegCut(h,prev,p)){const rk=v4Room({x:(prev.x+p.x)/2,y:(prev.y+p.y)/2}),r=V4S.rooms[rk];
      if(r&&r.floor){const lim=r.floor.y+r.floor.h-3;
        const sg=Math.sign(p.x-prev.x)||1,ok=q=>v4Room(q)===rk&&!v41InFoot(q.x,q.y,1);let done=false;
        /* knees: down from prev (steeper than 45 deg, so the head clears the wall line while still near the door), across at row Y,
           then to p the same way; tried lowest-cost first */
        for(let Y=r.y+h;Y<=lim&&!done;Y+=2){const dy1=Math.max(0,Y-prev.y),dy2=Math.max(0,Y-p.y),span=Math.abs(p.x-prev.x);
          for(let d1=0;d1<=Math.min(dy1-1,span)&&!done;d1+=(d1<6?1:3)){const k1={x:prev.x+sg*d1,y:Math.max(prev.y,Y),via:"walk"};if(!ok(k1)||!v41SegFree(prev,k1))continue;
            for(let d2=0;d2<=Math.min(Math.max(0,dy2-1),span-d1)&&!done;d2+=(d2<6?1:3)){const k2={x:p.x-sg*d2,y:Math.max(p.y,Y),via:"walk"};
              if(!ok(k2)||!v41SegFree(k1,k2)||!v41SegFree(k2,p)||v432LegCut(h,k1,k2))continue;
              if(k1.x!==prev.x||k1.y!==prev.y)out.push(k1);if(k2.x!==p.x||k2.y!==p.y)out.push(k2);done=true;}}}}}
    out.push(p);prev=p;});
  return out;}
{const _rt=routeTo;routeTo=function(a,spot){_rt(a,spot);try{if(a.path&&a.path.length)a.path=v432Lower(a,a.path);}catch(e){console.warn(e);}};}
/* Law #1 expected "the whole sprite is visible once out of the door column": the A11 ceiling clip now applies only inside a door
   column (head behind the lintel). Where furniture right under a door forces the walk along the back wall (galley counter, workshop
   bench) the head overlaps the bottom edge of the room above for those steps instead of being sliced flat. */
function v432Clips(c){const x=Math.round(c.x);return V43_DX.includes(x);} // exactly in a door column (the rounded draw x)
/* v4.3.2: the idea board on the visible ship (lounge, above the "ideaboard" spot) opens the BRAINSTORMS board; the old listener sat on the hidden v3 canvas */
const V432_IB=(()=>{let s=(typeof SPOTS!=="undefined"&&SPOTS.ideaboard)||{x:246,y:446};if(Array.isArray(s))s={x:s[0],y:s[1]};if(!isFinite(s.x)||!isFinite(s.y))s={x:246,y:446};return {x0:s.x-20,x1:s.x+20,y0:s.y-26,y1:s.y+2};})();
V4.cv.addEventListener("click",ev=>{if(typeof openBrainstorms!=="function"||v4Hit(ev,ev.pointerType==="mouse"?14:22))return;const [x,y]=v4XY(ev),B=V432_IB;
  if(x>=B.x0&&x<=B.x1&&y>=B.y0&&y<=B.y1){ev.stopImmediatePropagation();openBrainstorms();beep(660);}});
