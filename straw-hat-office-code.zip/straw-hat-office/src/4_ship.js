/* ================= SCENE: top-down / three-quarter Thousand-Sunny-style ship (original pixel art) ================= */
const W=640,H=360, cv=$("scene"), ctx=cv.getContext("2d"); cv.width=W; cv.height=H; ctx.imageSmoothingEnabled=false;
const OUTL="#2a160a";
function R(c,x,y,w,h,col){c.fillStyle=col;c.fillRect(x,y,w,h);}
function mk(w,h,fn){const c=document.createElement("canvas");c.width=w;c.height=h;const g=c.getContext("2d");g.imageSmoothingEnabled=false;fn&&fn(g);return c;}
function disc(c,cx,cy,r,col){for(let y=-r;y<=r;y++){const w=Math.round(Math.sqrt(r*r-y*y));R(c,cx-w,cy+y,w*2+1,1,col);}}
function oval(c,cx,cy,rx,ry,col){for(let y=-ry;y<=ry;y++){const w=Math.round(rx*Math.sqrt(1-(y*y)/(ry*ry)));R(c,cx-w,cy+y,w*2+1,1,col);}}
function ring(c,cx,cy,r,col){for(let a=0;a<360;a+=3){R(c,Math.round(cx+Math.cos(a*Math.PI/180)*r),Math.round(cy+Math.sin(a*Math.PI/180)*r),1,1,col);}}
function line(c,x0,y0,x1,y1,col){x0|=0;y0|=0;x1|=0;y1|=0;const dx=Math.abs(x1-x0),dy=-Math.abs(y1-y0),sx=x0<x1?1:-1,sy=y0<y1?1:-1;let e=dx+dy;for(;;){R(c,x0,y0,1,1,col);if(x0===x1&&y0===y1)break;const e2=2*e;if(e2>=dy){e+=dy;x0+=sx;}if(e2<=dx){e+=dx;y0+=sy;}}}
function silhouette(src,col){return mk(src.width,src.height,g=>{g.drawImage(src,0,0);g.globalCompositeOperation="source-in";R(g,0,0,src.width,src.height,col);});}
function outlined(src,col=OUTL){const s=silhouette(src,col);return mk(src.width+2,src.height+2,g=>{for(const[dx,dy]of[[0,1],[2,1],[1,0],[1,2]])g.drawImage(s,dx,dy);g.drawImage(src,1,1);});}
function lerpC(a,b,t){const p=x=>[1,3,5].map(i=>parseInt(x.substr(i,2),16));const A=p(a),B=p(b);t=Math.max(0,Math.min(1,t));return "#"+A.map((v,i)=>Math.round(v+(B[i]-v)*t).toString(16).padStart(2,"0")).join("");}
const bc=["#7a2e3a","#2f4f8a","#b8862a","#3c6b3c","#5b3a7a","#8a4a2a","#2a6b6b","#9a3a5a"];
const rnd=(s=>()=>(s=(s*16807)%2147483647)/2147483647)(7);
/* ---- layout (world coords) ---- */
const MAST={x:396,base:194,top:50};
const NEST_Y=70, levelOf=y=>y<NEST_Y?0:1;
const RM={ // rooms: rect, floor, north-wall colour, door
  galley:{x:38,y:70,w:86,h:94,name:"GALLEY",floor:["#efe6cf","#d9cba8"],tile:"check",wall:"#f3e7c9",door:{s:"s",x:81}},
  library:{x:126,y:70,w:86,h:94,name:"LIBRARY",floor:["#8a5a34","#7a4c2a"],tile:"plank",wall:"#6b3a4a",door:{s:"s",x:169}},
  sickbay:{x:214,y:70,w:86,h:94,name:"SICK BAY · DEALS",floor:["#e4f0ee","#cfe0dc"],tile:"check",wall:"#cfe6ef",door:{s:"s",x:257}},
  cargo:{x:38,y:222,w:86,h:108,name:"CARGO HOLD",floor:["#9a6a3a","#8a5c30"],tile:"plank",wall:"#7a4a22",door:{s:"n",x:81}},
  ledger:{x:126,y:222,w:86,h:108,name:"LEDGER ROOM",floor:["#3c6b52","#356049"],tile:"carpet",wall:"#e9d8b0",door:{s:"n",x:169}},
  breakroom:{x:214,y:222,w:86,h:108,name:"BREAK ROOM · AQUARIUM BAR",floor:["#2f6f7a","#2a6470"],tile:"carpet",wall:"#1d4f7a",door:{s:"e",y:272}}
};
const DOORS={};Object.entries(RM).forEach(([k,r])=>{const d=r.door;
  if(d.s==="s")DOORS[k]={in:{x:d.x,y:r.y+r.h-10},out:{x:d.x,y:r.y+r.h+12}};
  else if(d.s==="n")DOORS[k]={in:{x:d.x,y:r.y+24},out:{x:d.x,y:r.y-10}};
  else DOORS[k]={in:{x:r.x+r.w-12,y:d.y},out:{x:r.x+r.w+12,y:d.y}};});
function areaOf(p){if(p.y<NEST_Y&&Math.abs(p.x-MAST.x)<24)return "nest";for(const [k,r] of Object.entries(RM))if(p.x>=r.x&&p.x<r.x+r.w&&p.y>=r.y&&p.y<r.y+r.h)return k;return "open";}
/* hull shape */
function hullHalf(x){ // half-height of the hull at x (centre y=200)
  if(x<26)return 0; if(x<60)return 138*Math.sqrt(1-Math.pow((60-x)/34,2));
  if(x<=490)return 138; if(x>=614)return 0; const p=(x-490)/124;return 138*Math.sqrt(1-p*p);}
const HCY=200;
function lantern(g,x,y){R(g,x,y-3,1,3,"#333");R(g,x-2,y,5,6,"#2a2a2a");R(g,x-1,y+1,3,4,"#ffd24a");R(g,x,y+2,1,2,"#fff6b0");}
const LIGHTS=[[60,92],[150,92],[240,92],[80,248],[170,248],[256,250],[160,192],[260,192],[60,192],[330,90],[470,300],[540,200],[396,60]];
/* ---- static ship prerender ---- */
const ship=mk(W,H,g=>{
  // hull side face (3/4 view: thick dark-wood planked side below the rail, gold-rimmed portholes, bunting)
  const FACE=24;
  for(let x=24;x<622;x++){const h=hullHalf(x);if(h<=0)continue;const y0=Math.round(HCY+h),fh=Math.round(FACE*Math.min(1,h/60));for(let k=0;k<fh;k++)R(g,x,y0-2+k,1,1,(k%6===5)?"#4a2a12":(x+Math.floor(k/6)*29)%53===0?"#4a2a12":k<2?"#8a5527":"#6b3f1c");R(g,x,y0-2+fh,1,1,OUTL);}
  for(let x=70;x<480;x+=46){const y=HCY+138+11;disc(g,x,y,4,OUTL);disc(g,x,y,3,"#d4a23a");disc(g,x,y,2,"#1d4f7a");R(g,x-1,y-1,1,1,"#9fd8ff");}
  for(let x=40;x<600;x+=10){const h=hullHalf(x);if(h<=0)continue;const y=Math.round(HCY+h)+1;g.fillStyle=(x/10)%2?"#f08a24":"#c8323c";g.beginPath();g.moveTo(x,y);g.lineTo(x+9,y);g.lineTo(x+4,y+6);g.fill();}
  // rail (deck edge) with posts
  for(let x=24;x<622;x++){const h=hullHalf(x);if(h<=0)continue;const yt=Math.round(HCY-h),yb=Math.round(HCY+h);R(g,x,yt,1,yb-yt,"#5c3416");}
  for(let x=32;x<614;x++){const h=hullHalf(x)-7;if(h<=0)continue;const yt=Math.round(HCY-h),yb=Math.round(HCY+h);R(g,x,yt,1,yb-yt,"#a0703c");}
  // deck planks
  for(let x=32;x<614;x++){const h=hullHalf(x)-7;if(h<=0)continue;for(let y=Math.round(HCY-h);y<HCY+h;y++){if((y-63)%6===0)R(g,x,y,1,1,"#7a4a22");else if(((x+Math.floor((y-63)/6)*23)%37)===0)R(g,x,y,1,1,"#7a4a22");}}
  // rail highlight/outline + posts
  for(let x=24;x<622;x++){const h=hullHalf(x);if(h<=0)continue;R(g,x,Math.round(HCY-h),1,2,"#8a5527");R(g,x,Math.round(HCY-h)-1,1,1,OUTL);R(g,x,Math.round(HCY+h)-4,1,3,"#8a5527");R(g,x,Math.round(HCY+h)-5,1,1,"#a8703a");}
  for(let x=34;x<612;x+=12){const h=hullHalf(x);if(h<=8)continue;const yt=Math.round(HCY-h),yb=Math.round(HCY+h);R(g,x,yt-4,3,6,"#7a4a22");R(g,x,yt-4,3,1,"#a8703a");R(g,x,yb-10,3,8,"#7a4a22");R(g,x,yb-10,3,1,"#a8703a");}
  // ---- lawn deck ----
  for(let x=302;x<492;x++)for(let y=72;y<328;y++){const h=hullHalf(x)-7;if(y<HCY-h||y>HCY+h)continue;const n=((x*7+y*13)%11);R(g,x,y,1,1,n<2?"#5fb043":n<5?"#6cc04a":n===9?"#7fd25a":"#66b947");}
  R(g,301,72,1,256,"#3c7a2a");
  // stone path from hall to bow
  for(let x=304;x<600;x+=9){const w=x>560?4:7;R(g,x,195,w,6,"#c9b48a");R(g,x,195,w,1,"#e0d0aa");R(g,x,200,w,1,"#9a8660");}
  // ---- hallway rug ----
  R(g,40,166,260,54,"#b07a44");for(let y=166;y<220;y+=6)R(g,40,y,260,1,"#8f5f32");
  R(g,48,184,244,18,"#8b2a2a");R(g,50,186,240,14,"#a83a32");for(let x=54;x<288;x+=8){R(g,x,191,4,4,"#e3b444");}
  // ---- rooms ----
  Object.entries(RM).forEach(([k,r])=>{const [a,b]=r.floor;
    for(let y=r.y;y<r.y+r.h;y++)for(let x=r.x;x<r.x+r.w;x++){let c=a;if(r.tile==="check")c=((Math.floor((x-r.x)/8)+Math.floor((y-r.y)/8))%2)?a:b;else if(r.tile==="plank")c=((y-r.y)%7===6)?b:((x+Math.floor((y-r.y)/7)*19)%41===0?b:a);else c=((x*3+y*5)%9===0)?b:a;R(g,x,y,1,1,c);}
    // north wall face (3/4)
    R(g,r.x,r.y,r.w,14,r.wall);R(g,r.x,r.y+12,r.w,2,"#5c3416");R(g,r.x,r.y,r.w,1,"rgba(255,255,255,.25)");
    // wall tops (west/east/south) + north top
    R(g,r.x-2,r.y-2,r.w+4,3,"#5c3416");R(g,r.x-2,r.y-2,r.w+4,1,"#8a5527");R(g,r.x-2,r.y,2,r.h,"#5c3416");R(g,r.x+r.w,r.y,2,r.h,"#5c3416");R(g,r.x-2,r.y+r.h-1,r.w+4,3,"#5c3416");R(g,r.x-2,r.y+r.h-1,r.w+4,1,"#8a5527");
    // doors (gaps)
    const d=r.door;if(d.s==="s"){R(g,d.x-9,r.y+r.h-1,18,3,"#a0703c");R(g,d.x-9,r.y+r.h-1,1,3,OUTL);R(g,d.x+8,r.y+r.h-1,1,3,OUTL);}
    if(d.s==="n"){R(g,d.x-9,r.y-2,18,16,r.floor[0]);R(g,d.x-10,r.y-2,1,16,OUTL);R(g,d.x+9,r.y-2,1,16,OUTL);R(g,d.x-9,r.y-2,18,2,"#a0703c");}
    if(d.s==="e"){R(g,r.x+r.w,d.y-12,2,22,"#a0703c");}
  });
  // ---- room decor (static) ----
  // galley: stove + shelves on the north wall, window
  R(g,44,74,16,10,"#3a3a44");R(g,46,76,12,6,"#1a1a22");R(g,47,78,10,2,"#e0602a");
  R(g,64,74,30,2,"#8a5527");for(let i=0;i<6;i++)R(g,65+i*5,71+(i%2),3,3,["#e0424f","#57c26a","#f5b400","#fff","#9b59b6","#f08a24"][i]);
  R(g,98,73,18,8,"#7fc8ff");R(g,98,73,18,1,"#fff");R(g,106,73,1,8,"#fff");
  // library: books on the north wall
  for(let r=0;r<2;r++)for(let i=0;i<20;i++){const h=4+((i+r)%2);R(g,128+i*4,72+r*6+(5-h),3,h,bc[(i*3+r)%8]);}
  // sick bay: medicine cabinet + deal chart
  for(let i=0;i<6;i++){R(g,276+i*3,73,2,4,["#57c26a","#3fa9f5","#e0424f","#f5b400"][i%4]);R(g,276+i*3,78,2,4,["#3fa9f5","#e0424f","#f5b400","#57c26a"][i%4]);}
  R(g,218,72,26,11,"#f3ecd6");for(let i=0;i<5;i++)R(g,221+i*4,81-i*2-(i%2),3,2+i*2,"#3c9a4a");
  // ledger room: binders + trophy shelf on north wall
  for(let i=0;i<8;i++)R(g,130+i*5,224,4,9,["#7a2e3a","#2f4f8a","#b8862a","#3c6b3c","#5b3a7a"][i%5]);
  // cargo: north wall rope coils
  ring(g,60,229,4,"#c9a26b");ring(g,100,229,4,"#c9a26b");
  // break room: aquarium wall (north face) — animated fish drawn per frame
  R(g,216,223,82,13,"#0e3a5a");R(g,218,224,78,10,"#2f8fd8");R(g,218,224,78,3,"#5ab8f0");for(let x=220;x<296;x+=6)R(g,x,232-((x*3)%4),2,2+((x*3)%4),"#3c9a4a");
  // lanterns
  LIGHTS.slice(0,9).forEach(([x,y])=>lantern(g,x,y-14));
  // crow's-nest mast base shadow
  oval(g,MAST.x+3,MAST.base+2,10,4,"rgba(0,0,0,.25)");
  // bow: figurehead neck
  for(let x=590;x<612;x++){R(g,x,193,1,14,HULLC(x));}
  // sunflower lion figurehead: port of archive_sideview/4_ship.js:94-101, scaled ~0.6 so the mane fits inside x<640
  {const lx=624,ly=200;
   for(let a=0;a<16;a++){const ang=a/16*Math.PI*2,r2=a%2?11:13;for(let r=7;r<=r2;r++){disc(g,Math.round(lx+Math.cos(ang)*r),Math.round(ly+Math.sin(ang)*r),r<r2-1?2:1,a%2?"#f5961e":"#ffc83a");}}
   for(let a=0;a<16;a++){const ang=a/16*Math.PI*2,r2=a%2?13:15;R(g,Math.round(lx+Math.cos(ang)*r2),Math.round(ly+Math.sin(ang)*r2),1,1,OUTL);}
   disc(g,lx,ly,8,OUTL);disc(g,lx,ly,7,"#ffe39a");disc(g,lx-2,ly-2,3,"#fff0c0");
   R(g,lx-4,ly-2,2,2,OUTL);R(g,lx+3,ly-2,2,2,OUTL);R(g,lx-4,ly-2,1,1,"#fff");R(g,lx+3,ly-2,1,1,"#fff");
   R(g,lx-1,ly+1,3,1,"#8a4a2a");R(g,lx,ly+2,1,1,"#8a4a2a");R(g,lx-3,ly+4,7,1,"#8a4a2a");R(g,lx-4,ly+3,1,1,"#8a4a2a");R(g,lx+4,ly+3,1,1,"#8a4a2a");
   line(g,lx-9,ly+1,lx-6,ly+2,"#8a4a2a");line(g,lx+9,ly+1,lx+6,ly+2,"#8a4a2a");R(g,lx-6,ly+1,1,1,"#ffb0a0");R(g,lx+6,ly+1,1,1,"#ffb0a0");}
});
function HULLC(x){return x%5?"#f2a93b":"#e8992f";}
/* ---- props: depth-sorted objects (base = sort y) ---- */
const props=[];
function prop(x,y,w,h,base,fn,noOut){props.push({x:x-1,y:y-1,img:noOut?mk(w,h,fn):outlined(mk(w,h,fn)),base});}
// shipwright workbench (Frankie) + QA desk (Law), bow deck
prop(520,276,32,12,288,g=>{R(g,0,0,32,6,"#b67b3d");R(g,0,0,32,1,"#d9a066");R(g,0,6,32,6,"#7a4a22");R(g,2,1,8,3,"#cfe8ff");R(g,3,2,6,1,"#2f5fb8");R(g,13,1,2,4,"#888");R(g,12,1,4,1,"#555");R(g,19,2,9,2,"#9a9aa8");R(g,26,1,3,1,"#e0424f");});
prop(514,106,30,12,118,g=>{R(g,0,0,30,6,"#6b3f1c");R(g,0,0,30,1,"#9a6232");R(g,0,6,30,6,"#4a2e17");R(g,3,1,8,4,"#f3ecd6");R(g,4,2,6,1,"#2f7a3a");R(g,4,3,4,1,"#2f7a3a");R(g,14,1,6,4,"#1a1a1a");R(g,15,2,4,2,"#53d769");R(g,23,1,4,4,"#f2d04a");R(g,24,2,2,1,"#1a1a1a");});
// galley
prop(58,100,62,14,114,g=>{R(g,0,0,62,6,"#e8e2d0");R(g,0,0,62,1,"#fff");R(g,0,6,62,8,"#8a5527");R(g,0,6,62,1,"#5c3416");R(g,6,1,10,4,"#c08a4e");R(g,8,2,2,1,"#e0424f");R(g,12,2,2,1,"#57c26a");R(g,24,0,3,4,"#bbb");R(g,40,1,12,3,"#f3ecd6");R(g,44,1,4,2,"#f08a24");}); // counter island
prop(52,132,60,16,148,g=>{R(g,0,0,60,10,"#b67b3d");R(g,0,0,60,1,"#d9a066");R(g,0,10,60,4,"#7a4a22");[4,52].forEach(x=>R(g,x,14,4,2,"#5c3416"));R(g,10,3,8,4,"#fff");R(g,40,3,8,4,"#fff");R(g,26,2,8,6,"#e9d3a0");}); // dining table
// library
prop(146,124,48,14,138,g=>{R(g,0,0,48,8,"#6b3f1c");R(g,0,0,48,1,"#9a6232");R(g,0,8,48,6,"#4a2e17");R(g,14,1,16,5,"#f3ecd6");R(g,21,1,2,5,"#b8a080");R(g,3,2,8,4,"#7a2e3a");R(g,38,0,4,4,"#f3ecd6");R(g,39,1,1,1,"#ffb347");}); // reading desk
prop(196,140,12,16,156,g=>{disc(g,6,6,5,"#3f6fd1");R(g,3,3,4,3,"#57c26a");R(g,7,6,3,2,"#57c26a");R(g,5,11,2,3,"#5c3416");R(g,2,14,8,2,"#5c3416");}); // globe
prop(130,86,78,12,98,g=>{R(g,0,0,78,12,"#5c3416");for(let i=0;i<19;i++){const h=6+(i%3);R(g,1+i*4,10-h,3,h,bc[(i*5)%8]);}R(g,0,10,78,2,"#8a5527");}); // floor bookcase
// sick bay
prop(234,112,48,22,134,g=>{R(g,12,0,24,10,"#2a3448");R(g,14,1,20,7,"#0e1a2a");const p=[6,5,6,4,5,4,3,2,3];for(let i=0;i<9;i++)R(g,15+i*2,1+p[i],2,1,"#53d769");R(g,32,2,2,2,"#ffd24a");R(g,22,10,4,2,"#2a3448");R(g,0,12,48,6,"#c08a4e");R(g,0,12,48,1,"#e0b07a");R(g,0,18,48,4,"#7a4a22");R(g,3,13,6,3,"#57c26a");R(g,38,13,6,3,"#f3ecd6");}); // deal desk
prop(282,126,14,30,156,g=>{R(g,0,0,14,30,"#7a4a22");R(g,1,1,12,28,"#f2efe6");R(g,2,2,10,7,"#fff");R(g,1,12,12,17,"#7fa8d6");}); // cot
// cargo hold
prop(42,236,34,26,262,g=>{const cr=(x,y,s)=>{R(g,x,y,s,s,"#b67b3d");R(g,x,y,s,2,"#d9a066");R(g,x,y,1,s,"#7a4a22");R(g,x+s-1,y,1,s,"#7a4a22");R(g,x,y+s-1,s,1,"#7a4a22");line(g,x,y,x+s-1,y+s-1,"#8a5527");};cr(0,10,16);cr(17,10,16);cr(8,0,14);}); // crates
prop(96,238,24,20,258,g=>{R(g,1,6,22,14,"#8a5527");R(g,1,6,22,3,"#c08a4e");R(g,1,12,22,2,"#d4a23a");R(g,10,10,4,6,"#d4a23a");const c=["#e0424f","#3f6fd1","#f5b400","#9b59b6","#53a653"];for(let i=0;i<5;i++){R(g,3+i*4,2+(i%2),3,5,c[i]);R(g,4+i*4,2+(i%2),1,1,"#fff");}}); // card-pack chest
prop(40,300,12,16,316,g=>{R(g,1,0,10,16,"#8a5527");R(g,0,2,12,12,"#8a5527");R(g,2,0,2,16,"#a8703a");R(g,0,3,12,1,"#4a4a4a");R(g,0,12,12,1,"#4a4a4a");R(g,2,0,8,2,"#5c3416");}); // barrel
// ledger room
prop(146,270,52,14,284,g=>{R(g,0,0,52,8,"#8a5527");R(g,0,0,52,1,"#b67b3d");R(g,0,8,52,6,"#5c3416");R(g,10,1,18,6,"#f3ecd6");R(g,18,1,2,6,"#8b5a2b");for(let i=0;i<3;i++){R(g,11,2+i*2,6,1,"#8b8070");R(g,21,2+i*2,6,1,"#8b8070");}R(g,34,1,12,5,"#7a4a22");for(let i=0;i<4;i++)R(g,35+i*3,2,2,2,["#e0424f","#ffd24a","#57c26a","#3fa9f5"][i]);}); // ledger desk
prop(186,300,20,20,320,g=>{R(g,0,6,20,14,"#2f7a3a");R(g,2,8,16,10,"#3c9a4a");disc(g,10,5,5,"#57c26a");R(g,8,0,4,4,"#3c9a4a");}); // potted plant
// break room
prop(218,244,14,52,296,g=>{R(g,0,0,14,52,"#6b3f1c");R(g,0,0,14,2,"#9a6232");R(g,10,0,4,52,"#4a2e17");[8,20,32,44].forEach(y=>{R(g,3,y,3,4,["#e0424f","#ffd24a","#7fc8ff","#a6f27c"][y%4]);});}); // bar counter
prop(238,280,40,12,292,g=>{R(g,0,0,40,8,"#c08a4e");R(g,0,0,40,1,"#e0b07a");R(g,0,8,40,4,"#7a4a22");R(g,6,2,6,4,"#fff");R(g,8,3,2,2,"#7a3a1a");R(g,26,2,6,4,"#fff");R(g,28,3,2,2,"#7a3a1a");}); // coffee table
prop(234,310,62,18,328,g=>{R(g,0,0,62,8,"#7b3fa0");R(g,0,0,62,1,"#a070c8");R(g,0,8,62,10,"#9b59b6");R(g,0,8,62,1,"#b98ad6");R(g,0,0,4,18,"#6a2f8a");R(g,58,0,4,18,"#6a2f8a");R(g,20,9,1,8,"#7b3fa0");R(g,40,9,1,8,"#7b3fa0");}); // sofa
// lawn deck
prop(312,96,20,24,120,g=>{R(g,8,12,4,12,"#7a4a22");R(g,5,21,10,3,"#5c3416");ring(g,10,9,8,"#8a5527");ring(g,10,9,7,"#a8703a");for(let a=0;a<8;a++){const an=a*Math.PI/4;line(g,10,9,Math.round(10+Math.cos(an)*9),Math.round(9+Math.sin(an)*9),"#7a4a22");}disc(g,10,9,2,"#d4a23a");}); // helm
prop(338,70,28,26,96,g=>{R(g,3,14,2,12,"#5c3416");R(g,23,14,2,12,"#5c3416");R(g,0,0,28,16,"#7a4a22");R(g,2,2,24,12,"#e9d3a0");R(g,4,4,6,5,"#fff");R(g,12,3,7,6,"#ffe680");R(g,20,4,5,5,"#ffd0dc");R(g,5,10,6,3,"#bfe3ff");R(g,13,10,6,3,"#d0f0c0");R(g,7,4,1,1,"#c8323c");R(g,15,3,1,1,"#c8323c");}); // quest board
prop(430,244,40,18,262,g=>{R(g,0,0,40,10,"#b67b3d");R(g,0,0,40,1,"#d9a066");R(g,0,10,40,4,"#7a4a22");R(g,3,14,3,4,"#5c3416");R(g,34,14,3,4,"#5c3416");R(g,4,1,30,8,"#f3dfb0");R(g,8,2,8,4,"#5fb86a");R(g,20,3,9,4,"#5fb86a");R(g,5,6,28,1,"#7fc8ff");R(g,33,1,4,4,"#d4a23a");}); // map table
[[456,88],[482,104]].forEach(([x,y],i)=>prop(x-13,y-14,26,30,y+14,g=>{R(g,12,18,3,12,"#6b3f1c");disc(g,13,12,12,"#2f7a3a");disc(g,11,10,8,"#3c9a4a");disc(g,9,7,3,"#57c26a");[[5,12],[17,8],[19,16],[11,18],[7,5],[15,3]].forEach(([dx,dy])=>{R(g,dx,dy,3,3,"#f5961e");R(g,dx,dy,1,1,"#ffc060");});})); // tangerine trees
prop(526,184,12,18,202,g=>{R(g,5,6,2,12,"#333");R(g,2,16,8,2,"#333");R(g,0,0,12,7,"#f3ecd6");R(g,2,2,8,1,"#555");R(g,2,4,6,1,"#555");}); // music stand
// pallet + vault are drawn per frame (they change with real data)
/* crow's nest: mast pole + basket (drawn with depth tricks in the loop) */
const mastImg=mk(20,MAST.base-MAST.top+20,g=>{const h=MAST.base-MAST.top;R(g,7,8,7,h,"#7a4a22");R(g,8,8,2,h,"#a8703a");R(g,13,8,1,h,"#4e2f15");R(g,6,8,1,h,OUTL);R(g,14,8,1,h,OUTL);});
const yardImg=outlined(mk(132,12,g=>{R(g,0,4,132,4,"#7a4a22");R(g,0,4,132,1,"#a8703a");for(let x=8;x<124;x+=1){const b=Math.round(Math.sin(x/7)*1.5);R(g,x,1+b,1,6,x%11<2?"#ece2cf":"#fbf7ee");}[20,50,82,112].forEach(x=>R(g,x,0,2,9,"#c9a26b"));}));
const nestBack=mk(44,22,g=>{oval(g,22,8,20,7,"#5c3416");oval(g,22,8,17,5,"#3a2410");});
const nestFront=outlined(mk(44,16,g=>{for(let y=0;y<12;y++){const ins=y>8?(y-8)*2:0;R(g,2+ins,y,40-ins*2,1,(y%4)?"#8a5527":"#6b3f1c");}R(g,2,0,40,2,"#a8703a");for(let x=6;x<40;x+=7)R(g,x,2,1,8,"#5c3416");}));
const sailImg=outlined(mk(100,82,g=>{for(let y=0;y<78;y++){const p=y/78,b=Math.round(Math.sin(p*Math.PI)*7),x0=8-b,x1=92+b;R(g,x0,y+2,x1-x0,1,y%13===12?"#e6dcc6":"#f6efdc");R(g,x1-10,y+2,10,1,"#e3d7bd");R(g,x0,y+2,5,1,"#e3d7bd");}
  R(g,0,0,100,3,"#7a4a22");R(g,0,0,100,1,"#a8703a");R(g,2,79,96,3,"#7a4a22");
  const jx=50,jy=40;for(let i=-15;i<=15;i++){R(g,jx+i-1,jy+Math.round(i*0.7)+4,3,3,"#1a1a1a");R(g,jx+i-1,jy-Math.round(i*0.7)+4,3,3,"#1a1a1a");}
  disc(g,jx,jy,11,"#1a1a1a");R(g,jx-6,jy+8,13,6,"#1a1a1a");disc(g,jx-4,jy+1,3,"#f6efdc");disc(g,jx+4,jy+1,3,"#f6efdc");R(g,jx-1,jy+5,3,2,"#f6efdc");for(let i=-4;i<=4;i+=2)R(g,jx+i,jy+11,1,2,"#f6efdc");
  R(g,jx-9,jy-13,19,6,"#f2cc55");R(g,jx-7,jy-15,15,3,"#f2cc55");R(g,jx-9,jy-9,19,2,"#c8323c");R(g,jx-16,jy-7,33,3,"#e3b444");R(g,jx-16,jy-5,33,1,"#b8902f");}));
