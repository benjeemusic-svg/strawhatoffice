/* v4.1: treasure map (20:23) and the order table / Orders tab (owner 22:34) are removed; nothing left in this module */
