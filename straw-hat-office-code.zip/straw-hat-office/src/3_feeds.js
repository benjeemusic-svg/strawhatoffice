/* ================= OPTIONAL SHEET FEEDS (see DATA_FEED.md) =================
   gviz falls back to the FIRST tab when a tab name doesn't exist, so every feed is validated by its headers. */
const FEEDS={};   // name -> {ok, live, rows:[{col:value}], note}
const FEED_DEFS={
  shipping:{tab:"OCTOBER 2026 SHIPPING",need:["order #","status"]},
  crew:{tab:"CREW STATUS",need:["crew_id"]},
  jobs:{tab:"JOBS",need:["job_id","task"]},
  summaries:{tab:"SUMMARIES",need:["date","text"]},
  briefing:{tab:"BRIEFING",need:["date","line"]},
  news:{tab:"NEWS",need:["headline"]},
  brainstorms:{tab:"BRAINSTORMS",need:["session_id","speaker","message"]}
};
function loadTab(tab,need){return new Promise((res,rej)=>{const cb="__tab"+Math.random().toString(36).slice(2);const s=document.createElement("script");const to=setTimeout(()=>{done();rej(new Error("timeout"));},12000);
  function done(){clearTimeout(to);delete window[cb];s.remove();}
  window[cb]=data=>{done();try{if(data.status==="error")throw new Error("gviz error");const labels=data.table.cols.map(c=>String(c.label||"").trim().toLowerCase());
      if(!need.every(n=>labels.includes(n))){res(null);return;}   // tab missing (gviz returned another tab)
      const rows=data.table.rows.map(r=>{const o={};(r.c||[]).forEach((c,i)=>{if(labels[i])o[labels[i]]=c?(c.f!=null&&typeof c.v!=="number"?c.f:c.v):null;});return o;}).filter(o=>Object.values(o).some(v=>v!=null&&v!==""));
      res(rows);}catch(e){rej(e);}};
  s.onerror=()=>{done();rej(new Error("load failed"));};
  s.src=`https://docs.google.com/spreadsheets/d/${CONFIG.sheetId}/gviz/tq?tqx=out:json;responseHandler:${cb}&headers=1&sheet=${encodeURIComponent(tab)}&_=${Date.now()}`;document.head.appendChild(s);});}
/* Hosted (https, behind Cloudflare Access): crew tabs come from the private "Straw Hat Crew Board",
   synced every ~10 min into /crew.json (see DEPLOY.md "Crew sync"). file:// or any failure -> old gviz path. */
const CREW_JSON_TABS={crew:"CREW_STATUS",jobs:"JOBS",summaries:"SUMMARIES",briefing:"BRIEFING",news:"NEWS",brainstorms:"BRAINSTORMS",chat:"CREW_CHAT"}; // v4.1: CREW_CHAT is still read by the sync, but nothing in the UI shows it (crew chat removed, owner 20:33)
let CREW_SYNC=null;   // {synced_at, tabs} from the last good /crew.json
let CREW_STALE=false; // v3.1.3 N4: a later /crew.json fetch failed; still showing the last good CREW_SYNC
async function loadCrewJSON(){
  if(location.protocol!=="https:")return null;
  try{const ctl=typeof AbortController!=="undefined"?new AbortController():null;const to=setTimeout(()=>ctl&&ctl.abort(),10000);
    const r=await fetch("crew.json?_="+Date.now(),{cache:"no-store",credentials:"same-origin",redirect:"manual",signal:ctl?ctl.signal:undefined});clearTimeout(to);
    if(!r.ok||!/json/i.test(r.headers.get("content-type")||""))return null;
    const j=await r.json();if(!j||typeof j!=="object"||!j.tabs||typeof j.tabs!=="object")return null;
    CREW_SYNC=j;return j;}catch(e){return null;}}
function crewRows(j,k,need){const t=j&&j.tabs?j.tabs[CREW_JSON_TABS[k]]:undefined;if(!Array.isArray(t))return null;
  const rows=t.map(r=>{const o={};Object.entries(r||{}).forEach(([h,v])=>{o[String(h).trim().toLowerCase()]=(v===""?null:v);});return o;}).filter(o=>Object.values(o).some(v=>v!=null&&v!==""));
  if(rows.length&&need&&!need.every(n=>n in rows[0]))return null;return rows;}
async function loadFeeds(live){
  let cj=await loadCrewJSON();CREW_STALE=false;
  if(!cj&&CREW_SYNC){cj=CREW_SYNC;CREW_STALE=true;} // keep the last good data instead of emptying the tabs
  if(cj){const c=crewRows(cj,"chat");FEEDS.chat={ok:!!c,live:!!c&&!CREW_STALE,rows:c||[],note:c?"crew.json"+(CREW_STALE?" (stale)":""):"tab not found"};}
  await Promise.all(Object.entries(FEED_DEFS).map(async([k,d])=>{
    let rows=null,ok=false;
    if(cj&&k in CREW_JSON_TABS){rows=crewRows(cj,k,d.need);if(rows){FEEDS[k]={ok:true,live:!CREW_STALE,rows,note:"crew.json "+(okDate(cj.synced_at)?fmtTime(cj.synced_at):"time unknown")+(CREW_STALE?" (stale)":"")};return;}}
    if(live){try{rows=await loadTab(d.tab,d.need);ok=!!rows;}catch(e){}}
    if(!ok&&k==="shipping"&&SNAPSHOT.shipping){rows=SNAPSHOT.shipping.map(r=>{const o={};SNAPSHOT.shippingHeaders.forEach((h,i)=>o[h.toLowerCase()]=r[i]);return o;});FEEDS[k]={ok:true,live:false,rows,note:"snapshot "+fmtTime(SNAPSHOT.shippingTakenAt,true)};return;}
    FEEDS[k]={ok,live:ok,rows:rows||[],note:ok?"live":"tab not found"};
  }));
  // "on pallet" = non-cancelled SHIPPING rows whose PALLET # is filled (the main pallet numbers come from PURCHASES only)
  const sh=FEEDS.shipping;
  if(stats){if(sh&&sh.ok){let n=0,o=0;shipOrders().forEach(r=>{if(r.stage==="cancelled"||r.unmatched)return;if(r["pallet #"]!=null&&String(r["pallet #"]).trim()){n+=num(r.quantity)||0;o++;}});stats.onPallet={items:n,orders:o};}else stats.onPallet=null;}
  applyCrewFeed();
}
/* Classify SHIPPING rows into treasure-map stages (real statuses only) */
function shipOrders(){const sh=FEEDS.shipping;if(!sh||!sh.ok)return [];
  return sh.rows.filter(r=>r["order #"]&&!/^UNMATCHED TRACKING/i.test(r["order #"])).map(r=>{const st=String(r.status||""),y=v=>/^y/i.test(String(v||"").trim());let stage;
    const unmatched=/^UNMATCHED/i.test(r["order #"]);
    if(/cancel/i.test(st))stage="cancelled";
    else if(/US warehouse|arrived (in|at) (the )?US|delivered.*\bUS\b/i.test(st))stage="us";
    else if(r["pallet #"]&&String(r["pallet #"]).trim())stage="pallet";
    else if(y(r["received in sp (y/n)"]))stage="storage";
    else if(unmatched&&/delivered/i.test(st))stage="delivered_unmatched";
    else if(y(r["shipped by store (y/n)"]))stage="transit";
    else if(/awaiting payment/i.test(st))stage="unpaid";
    else stage="store";
    return Object.assign({stage,unmatched},r);});}
/* Optional live CREW STATUS tab overrides status.json per crew member */
function applyCrewFeed(){const f=FEEDS.crew;if(!f||!f.ok||typeof agents==="undefined")return;
  f.rows.forEach(r=>{const a=agents.find(x=>x.id===String(r.crew_id||"").trim().toLowerCase());if(!a)return;
    /* v4.1 (owner via Nami 21:56): the "doing now" text is this bot's own row only; a blank cell clears it (no stale or borrowed text) */
    a.status=String(r.status||"").trim();a.updatedAt=r.updated_at?String(r.updated_at):a.updatedAt;
    /* v4.3.2 (Law #2): crewRows maps a blank cell to null, so "column present" (not "!=null") decides: a blank state clears to resting,
       a blank decision clears the question (and the ring); a sheet without the column leaves status.json alone */
    if("state" in r)a.state=String(r.state==null?"":r.state).trim().toLowerCase();
    if("decision" in r)a.decision=String(r.decision==null?"":r.decision).trim()||null; // v4.1: blank = no decision, text = the question
    if(r.event_id){const ev={type:r.event_type||a.event.type,id:String(r.event_id),at:r.event_at?String(r.event_at):null,text:r.event_text?String(r.event_text):null,discount:num(r.discount)};
      if(!a.event||a.event.id!==ev.id){a.event=ev;queueEventIfNew(a);}}});
  if(typeof renderRoster==="function")renderRoster();}
