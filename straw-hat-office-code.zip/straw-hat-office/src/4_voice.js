/* ===== v4.1 crew voices (owner 20:42/20:43): every line a bot says lives in this ONE table, keyed by bot id =====
   Luffy: upbeat captain, signature "Nice work, crew!" (his old laugh line is gone everywhere) · Brook: Yohoho · Frankie: SUPER · Robin: calm "Fufu" ·
   Zoro: terse · Usopp: dramatic · Sanji: courteous · Chopper: eager · Jinbe: formal · Law: dry · Nami: sharp, money-minded.
   Medium intensity: at most one catchphrase per bubble, and never on every line (tests/check_voices.js).
   {name} {meal} {pct} are filled in by voice(). No line here says what a bot is working on: that text only ever comes from the bot's own CREW STATUS row (status / event_text). Event lines override the neutral EVENTS label for that bot only. */
const VOICE={
  luffy:{aye:"Nice work, crew!",thanks:"MEAT!! Thanks, Sanji!",cheer:"Nice work, crew!",mvp:"Thanks, everyone! Let's keep going!",ask:"Hey {name}, got a sec? 💡",
    dealReply:"Whoa, what a steal! Great find, {name}!",
    morningOpen:"Good morning, crew! Today's plan:",morningClose:"Let's get to work!",summaryOpen:"Friday summary, {date}:",summaryClose:"Great week, everyone!",
    mvpOpen:"Weekly MVP ceremony!",mvpNone:"No deliveries logged this week, so no MVP yet.",mvpNext:"Next week, crew!",mvpName:"This week's MVP: {name}, with {n} deliver{s}!",mvpCheer:"Three cheers! Kanpai!",seaking:"Ooh! Can we eat it?",events:{summary_sent:"Summary sent! Nice work, crew!"},
    combo:{goof:["Usopp! Chopstick-nose dance!","Hahaha! Do it again!"]}},
  nami:{aye:"Got it.",thanks:"Thanks, Sanji-kun!",cheer:"That's money in the bank!",mvp:"Thanks. Now, about my bonus…",ask:"{name}, quick question. It's about money. 💡",
    storm:"Storm ahead! Trim the sail!"},
  zoro:{aye:"Hmph.",thanks:"Not bad, cook.",cheer:"Good.",mvp:"…Thanks.",ask:"{name}. Got a sec?",cargoIn:"Cargo incoming.",stowed:"Hmph.",
    combo:{bicker:["What are you looking at, curly brow?","Bring it."]}},
  usopp:{aye:"Leave it to the great Captain Usopp!",thanks:"Delicious! Truly legendary!",cheer:"The greatest haul in history!",mvp:"I owe it all to my 8,000 followers!",ask:"{name}! I've had a brilliant idea! 💡",
    seaking:"S-S-SEA KING!!",marine:"Ship on the horizon! Everyone stay calm!",
    combo:{goof:["♪ I'm the great Captain Usopp! ♪","The great Captain Usopp takes a bow!"]}},
  sanji:{aye:"Yes, captain.",thanks:"A cook eats last, but thank you.",cheer:"A splendid haul!",mvp:"Thank you. It was my pleasure.",ask:"Pardon me, {name}, a moment? 💡",
    meal:"Come and get it! {meal}!",combo:{bicker:["Huh?! Wanna go, moss head?","…Later. Lunch first."]}},
  chopper:{aye:"On it!",thanks:"Yummy! Thank you, Sanji!",cheer:"Wow! We did it!",mvp:"Th-that doesn't make me happy, you jerk! ♪",ask:"{name}! Got a sec? 💡",
    dealShout:"Luffy! {pct}% off!!"},
  robin:{aye:"Fufu. Of course.",thanks:"Lovely, thank you.",cheer:"What a fine haul.",mvp:"How kind of you all.",ask:"{name}, may I share a thought? 💡"},
  brook:{aye:"Yohoho! Understood!",thanks:"A feast! I'd lick my lips, if I had any!",cheer:"Yohoho! Splendid!",mvp:"I'm moved to tears… though I have no eyes!",ask:"{name}, might I borrow a moment? 💡",
    events:{community_pulse:"Yohoho! Community pulse"}},
  jinbe:{aye:"Understood.",thanks:"Much obliged.",cheer:"A fine result, crew.",mvp:"I am honoured. Thank you.",ask:"{name}, a word, if you please. 💡"},
  frankie:{aye:"SUPER! On it!",thanks:"Tasty! Thanks, Sanji!",cheer:"SUPER haul!",mvp:"Aw, I'm not crying, you are!",ask:"{name}! Got a sec? Big idea! 💡",
    events:{ui_shipped:"SUPER! New office build shipped!"}},
  law:{aye:"Fine.",thanks:"…No bread, right? Thanks.",cheer:"Acceptable.",mvp:"Don't make a fuss.",ask:"{name}. A minute."}};
/* catchphrases that belong to one bot only */
const CATCH={luffy:/nice work, crew/i,brook:/yoho/i,frankie:/SU+PER/,robin:/fufu/i};
function voice(id,key,vars){const v=VOICE[id];let s=v&&v[key];if(typeof s!=="string")return null;vars=vars||{};
  return s.replace(/\{(\w+)\}/g,(m,k)=>vars[k]==null?"":String(vars[k])).replace(/\s+$/,"");}
function voiceEvent(id,type){const v=VOICE[id];return (v&&v.events&&v.events[type])||null;}
