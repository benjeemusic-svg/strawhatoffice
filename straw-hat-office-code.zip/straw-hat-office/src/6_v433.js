/* ================= v4.3.3 (Law v4.3.2 review, 00:51) ================= */
/* 1. At open the 4x view starts with the hull top just below the safe-area inset (Dynamic Island / status bar), not centred */
{const _g=v4zGeo;v4zGeo=function(){const G=_g();if(V4Z.safeTest!=null)G.safe=V4Z.safeTest;return G;};
 v4zDefault=function(){if(!V4.ready||!V4.cv.style.width)return;const big=v4zPhone();v4zSet(big?v4zBig():1,null,null,false);
   if(big){const G=V4Z.g;V4Z.ty=G.wt+G.safe+4-G.st-V4Z.s*G.y0;v4zClamp();v4zApply(false);}V4Z.init=true;};}
/* 2. a small pinned-notes board on the lounge back wall (in-house, STYLE-GUIDE palette, recoloured per phase through the same LUT as
      the world art); the idea-board tap target sits on it */
const V433_B={x:237,y:432,w:19,h:12};
const V433_BC={};
function v433BoardArt(){const c=document.createElement("canvas");c.width=V433_B.w+1;c.height=V433_B.h+1;const g=c.getContext("2d"),W=V433_B.w,H=V433_B.h;
  const P={ink:"#2b1d18",woodD:"#4b3226",wood:"#6e4b34",woodM:"#946b47",woodL:"#b98f5f",tan:"#dcb987",cream:"#f1e2bb",parchS:"#b59c72",foam:"#a7d8cb",pink:"#dc8ea0",grey:"#8e8b84",navy:"#1e3d55",white:"#f6f2e7"};
  const r=(col,x,y,w,h)=>{g.fillStyle=P[col];g.fillRect(x,y,w,h);};
  r("ink",1,1,W,H);                                  // drop shadow +1,+1
  r("wood",0,0,W,H);r("woodD",0,0,W,1);r("woodD",0,0,1,H);r("ink",0,H-1,W,1);r("ink",W-1,0,1,H);r("woodM",1,1,W-3,1); // frame: sel-out top/left woodD, bottom/right ink, top-left light
  r("woodL",2,2,W-4,H-4);                            // cork
  for(let y=2;y<H-2;y++)for(let x=2+(y%2);x<W-2;x+=3)if((x*7+y*3)%5===0)r("woodM",x,y,1,1); // cork speckle
  // notes: cream (with ruled lines), foam, pink; each with a 1 px shade on the bottom/right and a pin
  r("parchS",4,4,5,5);r("cream",3,3,5,5);r("parchS",4,5,3,1);r("parchS",4,7,2,1);r("navy",5,3,1,1);
  r("woodD",11,4,4,4);r("foam",10,3,4,4);r("white",10,3,1,1);r("grey",11,3,1,1);
  r("woodD",13,7,4,3);r("pink",12,6,4,3);r("grey",14,6,1,1);
  return c;}
function v433Board(g,dy){const ph=V4.phase||"day";let c=V433_BC[ph];
  if(!c){const base=V433_BC.day||(V433_BC.day=v433BoardArt()),tbl=V4M.palette.phases[ph];c=V433_BC[ph]=(ph==="day"||!tbl)?base:v4Recolor(base,tbl);}
  g.drawImage(c,V433_B.x,V433_B.y+(dy||0));V4.drawCalls++;}
{const _aq=ambAquarium;ambAquarium=function(g,t,dy){_aq(g,t,dy);try{v433Board(g,dy);}catch(e){console.warn(e);}};}
Object.assign(V432_IB,{x0:V433_B.x-3,x1:V433_B.x+V433_B.w+3,y0:V433_B.y-3,y1:V433_B.y+V433_B.h+3});
/* 3. (partial) door-column pop: the flat ceiling clip is for a bot going THROUGH a doorway (moving up/down in the column); a walker
      crossing the column sideways is no longer sliced for that one step */
v432Clips=function(c){const a=c.a,x=Math.round(c.x);
  if(a){if(a._lx!=null&&(a._lx!==c.x||a._ly!==c.y))a._side=Math.abs(c.x-a._lx)>Math.abs(c.y-a._ly);a._lx=c.x;a._ly=c.y;}
  if(!V43_DX.includes(x))return false;return !(a&&a.walking&&a._side);};
