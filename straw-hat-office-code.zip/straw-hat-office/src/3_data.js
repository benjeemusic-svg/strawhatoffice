<script>
"use strict";
/* ================= CONFIG (edit me) ================= */
const CONFIG = {
  sheetId: "125TloDi-xWce5NyGbKupJELfDkSGgJnguE3MZJepa_U",
  refreshMinutes: 3,
  commissionRate: 0.05,
  brlPerUsd: 5.14,              // funders' partner rate (owner, v4.1): EVERY US$ figure = R$ ÷ 5.14. Fixed here on purpose, not read from the Sheet.
  palletStartDate: "2026-10-08", // current pallet = PURCHASES lines dated on/after this date (undated lines are kept and flagged)
  tz: "America/Sao_Paulo",
  bigDealPct: 15,                // deal_found events with a discount >= this % trigger fireworks
  season: "auto",                // "auto" | "off" | "halloween" | "christmas" | "carnival" | "festa_junina"
  randomEvents: true,            // Sea King, storms, Marine ship on horizon, message in a bottle (needs NEWS tab)
  meetingHour: 9, meals: [[8,0,8,30,"Breakfast"],[12,0,13,0,"Lunch"],[19,0,20,0,"Dinner"]]
};
/* Snapshot of the real tracker, used when the live fetch is blocked (e.g. opened offline). */
const SNAPSHOT = __SNAPSHOT__;

const STATUS = JSON.parse(document.getElementById("STATUS").textContent);
/* shared extension points: modules push functions into these */
const HOOK={tick:[],sky:[],horizon:[],depth:[],light:[],ship:[],fx:[],sea:[],overlay:[],data:[],boot:[]};
const LS={get(k,d){try{const v=localStorage.getItem("pixelOffice."+k);return v==null?d:JSON.parse(v);}catch(e){return d;}},set(k,v){try{localStorage.setItem("pixelOffice."+k,JSON.stringify(v));}catch(e){}}};
const spNow=()=>{const p=new Intl.DateTimeFormat("en-GB",{timeZone:CONFIG.tz,weekday:"short",year:"numeric",month:"2-digit",day:"2-digit",hour:"2-digit",minute:"2-digit",hour12:false}).formatToParts(new Date());const o={};p.forEach(x=>o[x.type]=x.value);return {wd:o.weekday,y:+o.year,m:+o.month,d:+o.day,h:+o.hour%24,mi:+o.minute,date:`${o.year}-${o.month}-${o.day}`};};
const memo=(fn,ms=2000)=>{let v,ts=-1e9;return(...a)=>{const n=performance.now();if(n-ts>ms||a.length){v=fn(...a);ts=n;}return v;};};
const $ = id => document.getElementById(id);
/* v4.1 (owner 23:00, readability): the pixel font's 5/9 and 2/8 look alike, so every number (R$, US$, %, counts, times) inside pixel-font
   text is put in a <span class="num"> that uses the system font with tabular digits. Labels stay in the pixel font. */
const V41_NUM=/(?:R\$|US\$)\s?[−\-+]?\d[\d.,]*|[−\-+]?\d[\d.,:]*\s?%?/g;
function v41Num(el,text){text=String(text==null?"":text);el.textContent="";let i=0;text.replace(V41_NUM,(m,off)=>{if(off>i)el.append(text.slice(i,off));const s=document.createElement("span");s.className="num";s.textContent=m;el.append(s);i=off+m.length;return m;});if(i<text.length)el.append(text.slice(i));}
const v41NumHtml=h=>String(h).replace(/(^|>)([^<]+)/g,(m,a,t)=>a+t.replace(/&[a-z]+;|(?:R\$|US\$)\s?[−\-+]?\d[\d.,]*|[−\-+]?\d[\d.,:]*\s?%?/g,x=>x[0]==="&"?x:'<span class="num">'+x+'</span>'));
const fmtBRL = n => "R$ " + n.toLocaleString("en-US",{minimumFractionDigits:2,maximumFractionDigits:2});
const fmtBRL0 = n => "R$ " + Math.round(n).toLocaleString("en-US");
const fmtUSD = n => "US$ " + n.toLocaleString("en-US",{maximumFractionDigits:0});
/* v4.1 (Law V4-1/V4-2): every displayed time goes through asDate(): it never throws, and zoneless wall-clock strings are BRT (-03:00) */
function asDate(v){try{if(v==null||v==="")return null;if(v instanceof Date)return isNaN(v.getTime())?null:v;
  if(typeof v==="number")return v>1e11?(isFinite(v)?new Date(v):null):parseDate(v); return parseDate(v);}catch(e){return null;}}
const okDate = v => asDate(v)!=null; // v3.1.3 N3
const fmtTime = (d,full) => {const x=asDate(d);if(!x)return "time unknown";try{return new Intl.DateTimeFormat("en-GB",Object.assign({timeZone:CONFIG.tz,hour:"2-digit",minute:"2-digit"},full?{day:"2-digit",month:"short",year:"numeric"}:{})).format(x) + " BRT";}catch(e){return "time unknown";}};
const fmtDay = d => new Intl.DateTimeFormat("en-GB",{day:"numeric",month:"short",year:"numeric",timeZone:"UTC"}).format(new Date(d+"T00:00:00Z"));

/* ================= SOUND (off by default) ================= */
let soundOn=false, actx=null;
function beep(f=660,d=0.08,type="square"){ if(!soundOn)return; try{actx=actx||new (window.AudioContext||window.webkitAudioContext)();const o=actx.createOscillator(),g=actx.createGain();o.type=type;o.frequency.value=f;g.gain.value=0.04;o.connect(g);g.connect(actx.destination);o.start();g.gain.exponentialRampToValueAtTime(0.0001,actx.currentTime+d);o.stop(actx.currentTime+d);}catch(e){} }
if($("soundBtn"))$("soundBtn").onclick=()=>{soundOn=!soundOn;$("soundBtn").textContent=soundOn?"SFX ON":"SFX OFF";beep(880);};

/* ================= LOG ================= */
const logEntries = STATUS.log.slice();
/* v4.1 (V4-1): a bad time never enters the log (it used to freeze every later addLog); it is stored as ISO or "now" */
function addLog(who,text,t){const d=asDate(t);logEntries.push({t:(d||new Date()).toISOString(),who,text});try{renderLog();}catch(e){console.warn("renderLog",e);}}
const logMs=e=>{const d=asDate(e.t);return d?d.getTime():0;};
function renderLog(){const el=$("log");if(!el)return; /* v4.1: Captain's Log panel removed (owner 20:31); entries stay in memory only (logEntries) */el.innerHTML="";logEntries.slice().sort((a,b)=>logMs(b)-logMs(a)).forEach(e=>{const d=document.createElement("div");d.innerHTML=`<time>${fmtTime(e.t)}</time><span class="who"></span> `;d.querySelector(".who").textContent=e.who+":";d.append(" "+e.text);el.appendChild(d);});}
/* v4.1: Quest Board removed (owner list 19:25) */
/* ================= DATA ================= */
let stats=null, lastItems=null;
/* v4.1 (V4-3): numbers in either format. "R$ 1.234,56" / "1.234" (BR) and "R$1,234.56" / "1,234" (US): with both separators the last one is
   the decimal; a lone comma followed by 1-2 digits is a decimal comma; a lone separator followed by exactly 3 digits in groups is thousands. */
function num(v){ if(v==null)return null; if(typeof v==="number")return isFinite(v)?v:null; let s=String(v).replace(/R\$|US\$|\$|\s|\u00a0/g,""); if(!s||s[0]==="#")return null;
  const m=s.match(/^[-−+]?[\d.,]+/); if(!m)return null; let t=m[0].replace("−","-");
  const lc=t.lastIndexOf(","),ld=t.lastIndexOf(".");
  if(lc>=0&&ld>=0){ if(lc>ld)t=t.replace(/\./g,"").replace(",","."); else t=t.replace(/,/g,""); }
  else if(lc>=0){ t=/^[-+]?\d{1,3}(,\d{3})+$/.test(t)?t.replace(/,/g,""):t.replace(",","."); }
  else if(ld>=0&&/^[-+]?\d{1,3}(\.\d{3}){2,}$/.test(t)){ t=t.replace(/\./g,""); }
  const n=parseFloat(t); return isNaN(n)?null:n; }
/* money written inside free text (event_text): "1.234" with exactly 3 digits after a dot is BR thousands there */
function numMoney(v){ const s=String(v==null?"":v).replace(/R\$|US\$|\s|\u00a0/g,""); if(/^\d{1,3}(\.\d{3})+$/.test(s))return parseFloat(s.replace(/\./g,"")); return num(s); }
function parseDate(v){ try{ return parseDate0(v); }catch(e){ return null; } }
function parseDate0(v){ if(v==null||v==="")return null; let m;
  if(typeof v==="string"&&/^\s*\d{6,}(\.\d+)?\s*$/.test(v))return null; // v3.1.3 N5: "123456" is not a date
  if(typeof v==="string"&&/^\s*\d{5}(\.\d+)?\s*$/.test(v))v=parseFloat(v); // v3.1.2 M4: serial typed as text ("46305")
  if(typeof v==="number")return (v>20000&&v<80000)?new Date(Date.UTC(1899,11,30)+Math.floor(v)*86400000):null; // Sheets serial day (gviz types PURCHASE DATE as number)
  if(typeof v==="string"&&(m=v.match(/^Date\((\d+),(\d+),(\d+)(?:,(\d+),(\d+)(?:,(\d+))?)?/)))return m[4]==null?new Date(Date.UTC(+m[1],+m[2],+m[3])):new Date(Date.UTC(+m[1],+m[2],+m[3],+m[4]+3,+m[5],+(m[6]||0))); // gviz datetime = sheet (BRT) wall clock
  /* v4.1 (V4-4): DD/MM/YYYY keeps its time; (V4-2) a zoneless wall clock is BRT (-03:00, no DST in Brazil since 2019) whatever the viewer's zone.
     A date with no time stays UTC midnight of that day (the pallet date filter compares whole days). */
  const wall=(y,mo,d,h,mi,se)=>{if(mo<1||mo>12||d<1||d>31||h>23||mi>59||se>59)return null;const x=new Date(Date.UTC(y,mo-1,d,h+3,mi,se));return isNaN(x)||new Date(Date.UTC(y,mo-1,d)).getUTCDate()!==d?null:x;};
  if(typeof v==="string"&&(m=v.match(/^\s*(\d{1,2})\/(\d{1,2})\/(\d{2,4})(?:[\sT,]+(\d{1,2}):(\d{2})(?::(\d{2}))?)?\s*$/))){let y=+m[3];if(y<100)y+=2000;
    if(m[4]==null){const x=new Date(Date.UTC(y,+m[2]-1,+m[1]));return isNaN(x)||+m[2]<1||+m[2]>12||x.getUTCDate()!==+m[1]?null:x;}return wall(y,+m[2],+m[1],+m[4],+m[5],+(m[6]||0));}
  if(typeof v==="string"&&(m=v.match(/^\s*(\d{4})-(\d{2})-(\d{2})[\sT](\d{1,2}):(\d{2})(?::(\d{2})(?:\.\d+)?)?\s*$/)))return wall(+m[1],+m[2],+m[3],+m[4],+m[5],+(m[6]||0));
  if(typeof v!=="string")return null;
  const d=new Date(v);return isNaN(d)?null:d; }
/* ONE number source for every figure on screen: PURCHASES lines of the current pallet.
   Current pallet = lines dated on/after CONFIG.palletStartDate (PURCHASE DATE column). Lines without a date are kept
   (never silently dropped) and counted in s.undated. Taberna Geek is entered in PURCHASES at its negotiated R$44,500. */
function compute(rows,summary){
  const all=rows.filter(r=>r[0]&&num(r[2])>0);
  const start=new Date(CONFIG.palletStartDate+"T00:00:00Z"), dated=all.some(r=>parseDate(r[4]));
  let lines=dated?all.filter(r=>{const d=parseDate(r[4]);return !d||d>=start;}):all, dateWarn=false;
  if(!lines.length&&all.length){lines=all;dateWarn=true;console.warn("Pallet date filter matched no lines; counting all lines");} // never show an empty pallet because of a date-format change
  const undated=dated?lines.filter(r=>!parseDate(r[4])).length:lines.length, excluded=all.length-lines.length;
  const items=lines.reduce((a,r)=>a+num(r[2]),0);
  const spend=lines.reduce((a,r)=>a+(num(r[3])||0),0);
  const stores=new Set(lines.map(r=>String(r[0]).trim())).size;
  const byProd={}; lines.forEach(r=>{const p=String(r[1]).trim();byProd[p]=byProd[p]||{q:0,v:0};byProd[p].q+=num(r[2]);byProd[p].v+=num(r[3])||0;});
  /* v4.1: US$ always uses the partner rate (CONFIG.brlPerUsd); v4 derived it from the first SUMMARY row (avg R$ ÷ avg US$), which only happened to be 5.14 */
  const fx=CONFIG.brlPerUsd>0?CONFIG.brlPerUsd:null,fxSrc=null;
  return {orders:lines.length,lines:lines.length,items,spend,stores,byProd,fx,fxSrc,commission:spend*CONFIG.commissionRate,palletItems:items,palletSpend:spend,dated,undated,excluded:dateWarn?0:excluded,dateWarn,onPallet:null,rows:lines};
}
function findDateCol(labels){ return labels.findIndex(l=>/\b(date|data)\b/i.test(String(l||""))); }
const SHEET_TIMEOUT_MS=12000, GVIZ_SLICE_MS=7000; // v3.1.3 N2: ONE deadline shared by gviz and the CSV fallback
function loadJSONP(deadline){ return new Promise((res,rej)=>{ const cb="__gviz"+Date.now(); const s=document.createElement("script"); const to=setTimeout(()=>{cleanup();rej(new Error("timeout"));},Math.max(0,deadline-Date.now()));
  /* v3.1.2 M1: a late gviz response must not hit an undefined callback: leave a no-op behind instead of deleting it */
  function cleanup(){clearTimeout(to);window[cb]=()=>{};setTimeout(()=>{try{delete window[cb];}catch(e){}},120000);s.remove();}
  window[cb]=data=>{cleanup(); try{ if(data.status==="error")throw new Error("gviz error");
      const di=findDateCol(data.table.cols.map(c=>c.label)); const rows=[],summary=[];
      data.table.rows.forEach(r=>{const c=r.c||[];const v=i=>c[i]?c[i].v:null;
        if(v(0)!=null&&v(2)!=null) rows.push([v(0),v(1),v(2),v(3),di>=0?v(di):null]);
        if(v(5)!=null) summary.push([v(5),v(6),v(7),v(8),v(9)]); });
      res({rows,summary}); }catch(e){rej(e);} };
  s.onerror=()=>{cleanup();rej(new Error("script load failed"));};
  s.src=`https://docs.google.com/spreadsheets/d/${CONFIG.sheetId}/gviz/tq?tqx=out:json;responseHandler:${cb}&headers=1&_=${Date.now()}`;
  document.head.appendChild(s); }); }
function parseCSV(t){const out=[];let row=[],f="",q=false;for(let i=0;i<t.length;i++){const ch=t[i];if(q){if(ch=='"'){if(t[i+1]=='"'){f+='"';i++;}else q=false;}else f+=ch;}else if(ch=='"')q=true;else if(ch==","){row.push(f);f="";}else if(ch=="\n"){row.push(f);out.push(row);row=[];f="";}else if(ch!="\r")f+=ch;}if(f||row.length){row.push(f);out.push(row);}return out;}
async function loadCSV(deadline){ const left=deadline-Date.now(); if(left<=0)throw new Error("deadline passed"); const ctl=window.AbortController?new AbortController():null,to=setTimeout(()=>ctl&&ctl.abort(),left); let r; try{ r=await fetch(`https://docs.google.com/spreadsheets/d/${CONFIG.sheetId}/export?format=csv&_=${Date.now()}`,ctl?{signal:ctl.signal}:{}); }finally{clearTimeout(to);} if(!r.ok)throw new Error("HTTP "+r.status);
  const all=parseCSV(await r.text()), di=findDateCol(all[0]||[]), t=all.slice(1);
  return {rows:t.filter(x=>x[0]&&x[2]).map(x=>[x[0],x[1],x[2],x[3],di>=0?x[di]:null]),summary:t.filter(x=>x[5]).map(x=>[x[5],x[6],x[7],x[8],x[9]])}; }
let RETRY_T=null, REFRESHING=false;
/* v4.1 owner MUST (instant money): the last live tracker read is kept in this browser; first paint and the offline fallback use whichever is newer,
   that cache or the snapshot embedded at build time. The early script under the top card reads the same cache (texts only). */
function v41Best(){const c=LS.get("money41",null),sa=asDate(SNAPSHOT.takenAt);
  if(c&&c.rows&&c.rows.length&&(!sa||c.at>sa.getTime()))return {rows:c.rows,summary:c.summary||[],takenAt:new Date(c.at).toISOString()};
  return {rows:SNAPSHOT.rows,summary:SNAPSHOT.summary,takenAt:SNAPSHOT.takenAt};}
function v41SaveMoney(data){try{LS.set("money41",{at:Date.now(),rows:data.rows,summary:data.summary,t:null});V41_SAVE_PENDING=true;}catch(e){}}
let V41_SAVE_PENDING=false,V41_TITLE="",V41_READAT=null;
function v41SaveTexts(){if(!V41_SAVE_PENDING)return;V41_SAVE_PENDING=false;const c=LS.get("money41",null);if(!c)return;const t={};
  ["bounty","bountyUsd","mSpend","mSpendUsd","mAsOf"].forEach(k=>{const e=$(k);if(e&&e.textContent&&e.textContent!=="–")t[k]=e.textContent;});c.t=t;LS.set("money41",c);}
async function refresh(first){
  if(REFRESHING)return; REFRESHING=true; clearTimeout(RETRY_T);
  const pill=$("dataPill");
  if(first||!pill.classList.contains("live")){ pill.className="pill load"; pill.textContent=first?"◌ CONNECTING TO TRACKER…":"◌ RETRYING TRACKER…"; }
  /* v4.1 (Law C1): on a slow connection the money shows the embedded snapshot right away (labelled "as of"), then the live numbers replace it */
  if(first&&!stats){ const B=v41Best(); if(B&&B.rows&&B.rows.length){ try{ V41_READAT=B.takenAt; stats=compute(B.rows,B.summary); pill.textContent="◌ CONNECTING… · NUMBERS AS OF "+fmtTime(B.takenAt,true).toUpperCase(); renderStats(); }catch(e){ console.warn(e); } } }
  try{ await refreshInner(first,pill); }catch(e){ console.warn("refresh failed",e); } finally{ REFRESHING=false; }
}
async function refreshInner(first,pill){
  let data=null,live=false;
  const deadline=Date.now()+SHEET_TIMEOUT_MS;
  /* v4.1 (Law carry-over): a HUNG gviz request gets its own 7 s slice, so the CSV backup still gets the rest of the shared 12 s deadline */
  try{ data=await loadJSONP(Math.min(deadline,Date.now()+GVIZ_SLICE_MS)); live=true; }catch(e){ try{ data=await loadCSV(deadline); live=true; }catch(e2){} }
  if(!live||!data.rows.length){ const B=v41Best(); data={rows:B.rows,summary:B.summary}; live=false; }
  V41_READAT=live?new Date().toISOString():v41Best().takenAt;
  stats=compute(data.rows,data.summary);
  if(live) v41SaveMoney(data);
  if(live){ pill.className="pill live"; pill.textContent="● LIVE FROM TRACKER · "+fmtTime(new Date()); $("dataNote").textContent="auto-refresh every "+CONFIG.refreshMinutes+" min"; }
  else { pill.className="pill snap"; pill.textContent="○ OFFLINE · NUMBERS AS OF "+fmtTime(v41Best().takenAt,true).toUpperCase(); $("dataNote").textContent="live tracker unreachable, showing embedded snapshot · retrying in 1 min"; RETRY_T=setTimeout(()=>refresh(false),60000); }
  renderStats(); // numbers appear together with the pill (M1: never LIVE next to "–")
  if(first) addLog("System", live?`Loaded live tracker: ${stats.items} items over ${stats.lines} purchase lines`:`Live tracker unreachable, using snapshot (${stats.items} items)`);
  else if(lastItems!=null && stats.items>lastItems){ const d=stats.items-lastItems; addLog("Jinbe",`New loot! +${d} items logged in the tracker`); celebrate(d); }
  await loadFeeds(live);
  if(CREW_SYNC){const st=okDate(CREW_SYNC.synced_at)?" "+fmtTime(CREW_SYNC.synced_at):""; if(CREW_STALE)pill.textContent+=" · CREW SYNC STALE"+st; else if(st)pill.textContent+=" · CREW SYNCED"+st;} // v3.1.3 N4
  lastItems=stats.items; renderStats(); HOOK.data.forEach(f=>{try{f(stats,live);}catch(e){console.warn(e);}}); v41SaveTexts();
}
/* v4.1: the Orders tab (cargo product list + order table) was removed by the owner (22:34); the money totals are unchanged */
function renderStats(){ const s=stats; if(!s)return;
  V41_TITLE=`Current pallet = PURCHASES lines dated on/after ${fmtDay(CONFIG.palletStartDate)} (${s.lines} lines, ${s.stores} stores). Same source as the spend and the 5% commission.`+(s.dated?"":" The sheet has no purchase dates, so every line is counted.")+(s.dated&&s.undated?` ${s.undated} line(s) have no date and are included.`:"")+(s.excluded?` ${s.excluded} older line(s) excluded.`:"")+(s.dateWarn?" Warning: no line matched the start date, so all lines are counted.":"");
  /* v4.1 Money tab (owner 22:51): Bounty and Spent so far, R$ with US$ = R$ ÷ 5.14 under each; the "read" time = when these numbers were read */
  $("bounty").textContent=fmtBRL(s.commission); $("bountyUsd").textContent=s.fx?`≈ ${fmtUSD(s.commission/s.fx)}`:"";
  $("mSpend").textContent=fmtBRL(s.spend); $("mSpendUsd").textContent=s.fx?`≈ ${fmtUSD(s.spend/s.fx)}`:"";
  if(V41_READAT)$("mAsOf").textContent="· read "+fmtTime(V41_READAT,true);
}
