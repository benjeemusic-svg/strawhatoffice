/* ================= v4 "NEW LOOK" (stage 1): portrait Thousand Sunny cutaway =================
   Art: in-house pack from /workspace/pixel-office-art (copied to art/v4/, credits in art/v4/CREDITS-art.md), inlined by build.py.
   Helpers below are ports of the v4 API in pixel-office-art/sprites.js (anim/frameAt/route/recolor/fitInteger idea),
   rewritten for this single classic <script>. The v3 landscape renderer stays in the file but is bypassed (frame/fit/portrait branch on V4.on).
   Draw order (INTEGRATION-v4.md §2): water -> fish/sea-king shadows -> ship_<phase> -> crew behind the front props -> front_<phase>
   -> crew in front of them -> glow_<phase> -> emotes -> particles. Speech bubbles stay DOM (6_loop.js updateBubbles). */
const V4P=__V4PACK__;
const V4={oy:0,EH:0,on:true,ready:false,img:{},orig:{},phase:null,want:"day",cv:$("world4"),g:null,water:[],waterKind:null,fish:[],k:1,
  lastKey:"",busy:false,frames:0,drawn:0,drawMs:0,drawCalls:0};
V4.g=V4.cv.getContext("2d",{alpha:false});V4.g.imageSmoothingEnabled=false;
const V4M=V4P.m, V4S=V4P.spots, WW=V4M.world.w, WH=V4M.world.h;V4.EH=WH;
document.body.classList.add("v4");
/* ---------- assets ---------- */
function v4Load(){return Promise.all(Object.entries(V4P.files).map(([f,u])=>new Promise(ok=>{const i=new Image();i.onload=()=>ok([f,i]);i.onerror=()=>{console.warn("v4 art failed",f);ok([f,null]);};i.src=u;})))
  .then(list=>{list.forEach(([f,i])=>{if(i){V4.img[f]=i;V4.orig[f]=i;}});});}
function v4Recolor(img,table){const c=document.createElement("canvas");c.width=img.width;c.height=img.height;const g=c.getContext("2d",{willReadFrequently:true});g.drawImage(img,0,0);
  const d=g.getImageData(0,0,c.width,c.height),p=d.data,lut=new Map(Object.entries(table).map(([k,v])=>[parseInt(k.slice(1),16),parseInt(v.slice(1),16)]));
  for(let i=0;i<p.length;i+=4){if(!p[i+3])continue;const v=lut.get((p[i]<<16)|(p[i+1]<<8)|p[i+2]);if(v!=null){p[i]=v>>16;p[i+1]=(v>>8)&255;p[i+2]=v&255;}}
  g.putImageData(d,0,0);return c;}
const v4Cache={};
/* phase change: LUT-recolour crew sheets, water and shadows once (cached per phase), off the hot path; the world layers are pre-baked */
/* v4.3 brightness fix (owner 22:02 "crew look nicer/brighter in the previews"): the crew used to get the FULL phase LUT (night maps
   skin->skinD, white->parch, navy->navyD ...), and "dusk" covers ~16:30-19:30 BRT, so for much of the day they read dark and muddy next to
   the previews (day pixels were already identical). Crew now keep their day colours at dusk and get only the light dusk table at night and
   in storms (the cabins are lamp-lit); water, shadows and the baked world layers still follow the full phase. */
const V4_CREWTINT={day:null,dusk:null,night:"dusk",storm:"dusk"};
function v4TableFor(f,ph){const isCrew=Object.values(V4M.characters).some(c=>c.file===f);const p=isCrew?V4_CREWTINT[ph]:ph;return p&&p!=="day"&&V4M.palette.phases[p]?[p,V4M.palette.phases[p]]:null;}
function v4SetPhase(ph){if(!V4.ready||V4.phase===ph||V4.pending===ph)return;V4.pending=ph;
  const files=[V4M.water.file,V4M.shadows.file,...Object.values(V4M.characters).map(c=>c.file)];
  const done=()=>{if(V4.pending!==ph)return;files.forEach(f=>{const T=v4TableFor(f,ph);V4.img[f]=T?v4Cache[T[0]+f]:V4.orig[f];});V4.phase=ph;V4.pending=null;
    try{ambSetPhase(ph);}catch(e){console.warn(e);}v4BuildWater();V4.lastKey="";};
  const todo=files.filter(f=>{const T=v4TableFor(f,ph);return T&&!v4Cache[T[0]+f]&&V4.orig[f];});let i=0;
  if(!todo.length){done();return;}
  const step=()=>{if(V4.pending!==ph)return;const t0=performance.now();while(i<todo.length&&performance.now()-t0<8){const f=todo[i++],T=v4TableFor(f,ph);v4Cache[T[0]+f]=v4Recolor(V4.orig[f],T[1]);}
    if(i<todo.length)(window.requestIdleCallback||setTimeout)(step);else done();};step();}
/* the 4 water frames are cached as full-size canvases at phase change (1 drawImage per frame instead of 260 tiles) */
/* calm water (owner feedback 18:57): the art tile reads as high-contrast static at 3x, so the sea is painted procedurally from the tile's own
   (phase-recoloured) average colour: flat turquoise base, a few large soft swells, sparse low-contrast crests that drift slowly (2 fps, 4 frames) */
const V4_WFPS=2;
function v4Mix(a,b,t){return a.map((v,i)=>Math.round(v+(b[i]-v)*t));}
function v4Rgb(c,al){return al==null?`rgb(${c[0]},${c[1]},${c[2]})`:`rgba(${c[0]},${c[1]},${c[2]},${al})`;}
function v4BuildWater(){const W=V4M.water,kind=(V4.phase==="night"||V4.phase==="storm")?"deep":"sea",im=V4.img[W.file];if(!im)return;
  const [sx,sy]=W.kinds[kind].frames[0],tc=document.createElement("canvas");tc.width=tc.height=W.tile;const tg=tc.getContext("2d",{willReadFrequently:true});tg.drawImage(im,sx,sy,W.tile,W.tile,0,0,W.tile,W.tile);
  const d=tg.getImageData(0,0,W.tile,W.tile).data;let r=0,gg=0,b=0,n=0;for(let i=0;i<d.length;i+=4){if(d[i+3]<128)continue;r+=d[i];gg+=d[i+1];b+=d[i+2];n++;}
  const avg=n?[r/n,gg/n,b/n].map(Math.round):[43,130,136],base=kind==="deep"?avg:v4Mix(avg,[52,156,156],.4),hi=v4Mix(base,[167,216,203],kind==="deep"?.18:.26),lo=v4Mix(base,[20,38,54],.14);
  let seed=7;const rnd=()=>((seed=(seed*16807)%2147483647)/2147483647);
  /* v4.3.1 (owner 00:16): the frames are as tall as the canvas (ship + sea above/below, V4.EH rows); the ship sits at row V4.oy */
  const EH=V4.EH||WH,nf=EH/WH;
  const swells=[];for(let i=0;i<Math.round(34*nf);i++)swells.push({x:rnd()*WW,y:rnd()*EH,w:40+rnd()*60,h:5+rnd()*5});
  const crests=[];for(let i=0;i<Math.round(120*nf);i++)crests.push({x:rnd()*WW,y:Math.floor(rnd()*EH),l:5+Math.floor(rnd()*6),ph:Math.floor(rnd()*4)});
  V4.water=[0,1,2,3].map(f=>{const c=document.createElement("canvas");c.width=WW;c.height=EH;const g=c.getContext("2d");g.imageSmoothingEnabled=false;
    g.fillStyle=v4Rgb(base);g.fillRect(0,0,WW,EH);
    swells.forEach(s=>{const x=Math.round((s.x+f*1.5)%(WW+s.w))-s.w/2|0,y=Math.round(s.y);g.fillStyle=v4Rgb(lo,.35);g.fillRect(x+3,y+s.h-2|0,s.w-6|0,2);g.fillStyle=v4Rgb(hi,.12);g.fillRect(x+4,y,s.w-8|0,1);g.fillRect(x,y+1,s.w|0,s.h-3|0);g.fillRect(x+4,y+s.h-2|0,s.w-8|0,1);});
    crests.forEach(k=>{const vis=(f+k.ph)%4;if(vis===3)return;const x=Math.round((k.x+f)%WW),len=k.l-(vis===2?2:0);g.fillStyle=v4Rgb(hi,vis===0?.6:.4);g.fillRect(x,k.y,len,1);g.fillRect(x+1,k.y-1,Math.max(1,len-2),1);});
    return c;});V4.waterKind=kind;try{ambBakeSea();}catch(e){console.warn(e);}}
/* ---------- time of day / weather -> phase ---------- */
const V4_FORCE=(/[?&]phase=(day|dusk|night|storm)\b/.exec(location.search)||[])[1]||null; // QA: ?phase=night
function v4PhaseNow(){if(V4.force||V4_FORCE)return V4.force||V4_FORCE;let k="clear";try{k=wxKind();}catch(e){}if(k==="storm"||k==="rain")return "storm";
  const P=dayPhase();return P.dark>.4?"night":(P.tint>.05||P.dark>.12)?"dusk":"day";}
/* ---------- spots: the v3 spot names mapped onto the portrait ship (feet positions inside spots.json room floors) ---------- */
const V4N=V4S.nodes, V4ST=V4S.stations;
const V4_ROOMNODE={helm:"helm_c",charts:"charts_c",galley:"galley_c",library:"library_c",sickbay:"sickbay_c",qa:"qa_c",lounge:"lounge_c",workshop:"workshop_c",cargo:"cargo_c",lawn:"lawn_c",figurehead:"bow",crows_nest:"st_usopp"};
const ST_LABEL={luffy:"on the lion figurehead",usopp:"on lookout in the crow's nest",jinbe:"keeping the ledger at the helm",nami:"drawing charts at the map table",sanji:"cooking in the galley",
  robin:"reading in the library",chopper:"scanning listings in the sickbay",law:"running QA tests at the QA desk",brook:"playing violin in the lounge",frankie:"hammering at the workbench",zoro:"hauling crates in the cargo hold"};
const V4SPOT={ // name: [x,y,label,dir,work?]
  helm:[96,214,"at the helm wheel","left",1], board:[226,192,"checking new jobs in the chart room","up",1], maptable:[244,194,"at the map table","down",1],
  grove:[128,128,"by the tangerine grove","down",0], bowdeck:[272,128,"on the lawn deck","down",0], lion:[224,80,"by the lion figurehead","up",0], mastfoot:[218,132,"at the foot of the mast","down",0],
  nest:null, nest2:null, galley:[156,266,"at the galley counter","down",1], stove:[86,300,"at the stove","up",1],
  library:[322,302,"at the reading table","up",1], shelves:[228,262,"browsing the shelves","up",1],
  dealdesk:null, dealboard:[168,396,"checking the listing screen","up",1], meds:[106,352,"at the medicine cabinet","up",1],
  cargo:null, crates:[234,524,"counting crates","down",1], chest:[322,560,"checking the cargo boxes","up",1], pallet:[236,566,"checking the USA pallet","down",1], vault:[300,532,"guarding the cargo hold","down",1],
  ledger:null, aquarium:[306,444,"by the aquarium windows","up",0],
  b1:[176,452,"on break in the lounge","down",0], b2:[300,452,"on break in the lounge","down",0], b3:[322,474,"on break in the lounge","left",0], b4:[236,450,"on break in the lounge","down",0],
  b5:[270,444,"at the aquarium windows","up",0], b6:[150,132,"on break on the lawn deck","down",0],
  ideaboard:[246,446,"sharing ideas in the lounge","up",0], rest1:[110,482,"napping on the lounge sofa","down",0], rest2:[138,482,"resting on the lounge sofa","down",0],
  meal1:[140,290,"eating at the galley table","right",0], meal2:[160,312,"eating at the galley table","up",0], meal3:[182,312,"eating at the galley table","up",0], meal4:[140,308,"eating at the galley table","right",0],
  c1:[236,124,"hanging out on deck","right",0], c2:[262,124,"hanging out on deck","left",0],
  m0:[201,478,"leading the crew meeting","down",0],
  workbench:null, blueprints:[76,522,"checking the blueprints","up",1], qadesk:null, qanotes:[240,396,"writing up a bug report","up",1]};
[[172,450],[230,450],[258,450],[286,450],[314,452],[170,482],[236,482],[266,482],[296,482],[322,482]].forEach(([x,y],i)=>V4SPOT["m"+(i+1)]=[x,y,"at the crew meeting in the lounge","down",0]);
const V4_HOMEALIAS={nest:"usopp",nest2:"usopp",dealdesk:"chopper",cargo:"zoro",ledger:"jinbe",workbench:"frankie",qadesk:"law"};
const V4_VISITS={luffy:["grove","bowdeck","galley","aquarium","mastfoot","maptable"],zoro:["crates","pallet","chest","mastfoot","grove"],nami:["maptable","grove","library","pallet"],
  usopp:["mastfoot","bowdeck","lion","grove"],sanji:["stove","galley","grove","maptable"],chopper:["dealboard","meds","library","galley"],robin:["shelves","library","aquarium"],
  frankie:["blueprints","lion","bowdeck","galley","aquarium"],brook:["aquarium","grove","bowdeck","galley"],jinbe:["helm","pallet","library","aquarium"],law:["qanotes","meds","library","bowdeck"]};
function v4Room(p){for(const k of ["crows_nest","figurehead"]){const r=V4S.rooms[k];if(p.x>=r.x&&p.x<r.x+r.w&&p.y>=r.y&&p.y<r.y+r.h)return k;}
  for(const [k,r] of Object.entries(V4S.rooms)){if(k==="crows_nest"||k==="figurehead")continue;if(p.x>=r.x&&p.x<r.x+r.w&&p.y>=r.y&&p.y<r.y+r.h)return k;}return "lawn";}
function v4InstallSpots(){
  Object.keys(SPOTS).forEach(k=>delete SPOTS[k]);
  Object.entries(V4ST).forEach(([id,s])=>{SPOTS["st_"+id]={x:s.x,y:s.y,label:ST_LABEL[id]||"at the station",dir:"down",node:"st_"+id,work:1,station:id};});
  Object.entries(V4SPOT).forEach(([k,v])=>{if(v)SPOTS[k]={x:v[0],y:v[1],label:v[2],dir:v[3],work:v[4]};else{const id=V4_HOMEALIAS[k];SPOTS[k]=Object.assign({},SPOTS["st_"+id]);}});
  Object.values(SPOTS).forEach(s=>{if(!s.node)s.node=v4NearestNode(s);});
  // the nest-side spot (only Usopp uses it) is the crow's nest itself
  agents.forEach(a=>{const st=V4ST[a.id];a.home="st_"+a.id;a.visits=V4_VISITS[a.id]||["grove"];a.x=st.x;a.y=st.y;a.at=a.home;a.target=a.home;a.path=[];a.dir="down";a.walking=false;
    const c=V4M.characters[a.id];if(c&&LOOKS[a.id])LOOKS[a.id].ht=c.height+1;});
  const spots={};Object.keys(MEETING.spots||{}).forEach(k=>spots[k]=MEETING.spots[k]);}
function v4NearestNode(p){const room=v4Room(p);let best=null,bd=1e9;for(const [n,q] of Object.entries(V4N)){if(q.room!==room&&!(room==="crows_nest"&&n==="st_usopp"))continue;const d=Math.hypot(q.x-p.x,q.y-p.y);if(d<bd){bd=d;best=n;}}
  return best||V4_ROOMNODE[room]||"lawn_c";}
const V4ADJ={};V4S.edges.forEach(([a,b,via])=>{(V4ADJ[a]=V4ADJ[a]||[]).push([b,via]);(V4ADJ[b]=V4ADJ[b]||[]).push([a,via]);});
const V41_NOTRANSIT=new Set(["sickbay"]); // v4.1 (Law A2): the sickbay desk fills the room between its two doors, so it is not a corridor
function v4Route(from,to){if(from===to)return [];const ends=new Set([V4N[from]&&V4N[from].room,V4N[to]&&V4N[to].room]);
  const prev={[from]:null},q=[from];while(q.length){const n=q.shift();if(n===to)break;for(const [m,via] of V4ADJ[n]||[]){if(m in prev)continue;const rm=V4N[m]&&V4N[m].room;if(m!==to&&V41_NOTRANSIT.has(rm)&&!ends.has(rm))continue;prev[m]=[n,via];q.push(m);}}
  if(!(to in prev))return null;const out=[];for(let n=to;n!==from;n=prev[n][0])out.unshift({x:V4N[n].x,y:V4N[n].y,via:prev[n][1],node:n});return out;}
/* replaces the landscape router: walk straight to the nearest graph node, BFS over spots.json edges, then to the spot */
routeTo=function(a,spot){const s=SPOTS[spot];if(!s)return;if(!s.node)s.node=v4NearestNode(s);
  const from=v4NearestNode(a),fn=V4N[from],pts=[];if(Math.hypot(fn.x-a.x,fn.y-a.y)>0.5)pts.push({x:fn.x,y:fn.y});
  const r=v4Route(from,s.node);if(r===null){pts.length=0;}else r.forEach(p=>pts.push(p));
  const last=pts.length?pts[pts.length-1]:{x:a.x,y:a.y};if(Math.hypot(last.x-s.x,last.y-s.y)>0.5)pts.push({x:s.x,y:s.y});
  a.path=pts;a.at=null;a.target=spot;};
areaOf=function(p){return v4Room(p);};
/* big-deal fireworks, confetti and the "+N items" sparkle in portrait-world coordinates */
spawnFirework=function(){const x=50+Math.random()*300,y=20+Math.random()*110,c=["#e9b84c","#b8342f","#a7d8cb","#8ba45f","#f6f2e7"][Math.floor(Math.random()*5)];
  for(let i=0;i<22;i++){const an=i/22*Math.PI*2,v=26+Math.random()*16;WORLD.fireworks.push({x,y,vx:Math.cos(an)*v,vy:Math.sin(an)*v,life:900+Math.random()*400,c});}beep(300+Math.random()*300,.05,"triangle");};
confetti=function(){for(let i=0;i<90;i++)WORLD.confetti.push({x:120+Math.random()*160,y:120+Math.random()*40,vx:(Math.random()-.5)*40,vy:Math.random()*10,life:3500+Math.random()*1500,c:["#e9b84c","#b8342f","#4fa7a1","#8ba45f","#f6f2e7"][i%5]});banner("cf","🎉",2000);};
celebrate=function(n){beep(523,.1);setTimeout(()=>beep(659,.1),110);setTimeout(()=>beep(784,.15),220);const p=SPOTS.pallet||{x:236,y:566};floaty(`+${n} items!`,p.x,p.y-44);for(let i=0;i<24;i++)sparkles.push({x:p.x,y:p.y-14,vx:(Math.random()-.5)*60,vy:-30-Math.random()*40,life:1500});};
dropCoins=function(n){const p=SPOTS.pallet||{x:236,y:566};for(let i=0;i<n;i++)setTimeout(()=>WORLD.confetti.push({x:p.x-10+Math.random()*20,y:p.y-60-Math.random()*16,vx:(Math.random()-.5)*24,vy:0,life:1600+Math.random()*600,c:i%3?"#e9b84c":"#f6d77a"}),i*60);}; // replay / new purchase: gold rain over the cargo hold (v3 vault is not drawn in v4)
/* ---------- animation choice from the existing app states (INTEGRATION-v4.md §3) ---------- */
const EV_ANIM={deal_found:"celebrate_jump",release_found:"telescope",margin_report:"count_berries",growth_idea:"cheer",shipment_update:"lift_crate",books_updated:"write_ledger",
  supplier_deal:"flip_pan",community_pulse:"violin",summary_sent:"cheer",ui_shipped:"super_pose",qa_report:"check_clipboard"};
const Q_ANIM={meat:"eat_meat",stretch:"stretch",nap:"yawn",lift:"lift_weights",count:"count_berries",tinker:["tinker","hammer"],tale:"talk",swoon:"expr_happy",read:"read_book",violin:"violin",tea:"sip_tea"};
const EMO4={"!":"surprised","?":"question","♥":"heart","♪":"music","💡":"idea","z":"sleepy","…":"focused","$":"happy","★":"happy","💧":"sleepy","💢":"surprised"};
function v4Anim(id,state,dir){const A=V4M.characters[id].animations;let a=A[state+"_"+dir]||A[state]||null;if(a&&a.alias)a=A[a.alias];return a;}
function v4Pick(a,t){const id=a.id,c=V4M.characters[id];let st,dir="down";
  if(a.walking){st="walk";dir=a.dir||"down";}
  else if(a.anim){st=EV_ANIM[a.anim.type]||"cheer";if(!v4Anim(id,st,"down"))st="cheer";}
  else if(a.resting)st="sleep";
  else if(a.eating)st=id==="luffy"?"eat_meat":"sit";
  else if(a.combo)st=(t-a.combo.t0>a.combo.dur-900)?"highfive":"talk";
  else if(a.say&&t<a.say.until&&(MEETING.active||(typeof CONVO!=="undefined"&&CONVO)))st="talk";
  else if(a.quirk&&Q_ANIM[a.quirk.k]){const q=Q_ANIM[a.quirk.k];st=(Array.isArray(q)?q:[q]).find(s=>v4Anim(id,s,"down"))||"stretch";}
  else{const s=SPOTS[a.at];
    if(a.at===a.home&&!isOnBreak(a)){st=V4ST[id].anim;}
    else if(a.at==="rest1"||a.at==="rest2")st="sit";
    else if(s&&s.work&&!isOnBreak(a)){st="work";dir=s.dir==="up"?"up":"down";}
    else{st="idle";dir=(s&&s.dir)||a.dir||"down";}}
  let A=v4Anim(id,st,dir);if(!A){A=v4Anim(id,"idle",dir)||c.animations.idle_down;st="idle";}
  const key=st+"_"+dir;if(a._v4k!==key){a._v4k=key;a._v4t0=t;}
  const fr=A.frames,e=REDUCED&&st!=="walk"?0:(t-a._v4t0),i=A.loop===false?Math.min(fr.length-1,Math.floor(e/1000*A.fps)):Math.floor((st==="walk"?e:t)/1000*A.fps)%fr.length;
  return fr[i];}
/* ---------- fish and sea-king shadows (app-side motion paths, wrap at the edges) ---------- */
function v4Fish(){const S=V4M.shadows.sprites,mk=(n,y,dirn)=>({n,x:Math.random()*WW,y,v:S[n].speed*dirn});
  V4.fish=[mk("fish_s",30,1),mk("fish_l",250,-1),mk("fish_s",400,1),mk("fish_l",590,-1),mk("fish_s",520,-1),mk("seaking",612,1)];}
/* ---------- draw ---------- */
function v4Shadow(g,name,t,x,y,flip){const e=V4M.shadows.sprites[name],im=V4.img[V4M.shadows.file];if(!e||!im)return;const [sx,sy]=e.frames[Math.floor(t/1000*e.fps)%e.frames.length];
  const dx=Math.round(x)-e.anchor[0],dy=Math.round(y)-e.anchor[1];V4.drawCalls++;
  if(!flip){g.drawImage(im,sx,sy,e.w,e.h,dx,dy,e.w,e.h);return;}g.save();g.translate(dx+e.w,dy);g.scale(-1,1);g.drawImage(im,sx,sy,e.w,e.h,0,0,e.w,e.h);g.restore();}
function v4OnClimb(a){const r=v4Room(a);return r==="figurehead"||r==="crows_nest";}
function v4EmoteAt(a,t){if(ringing(a)&&Math.floor(t/400)%2)return "surprised";const E=a.emote;if(E&&t<E.until)return EMO4[E.k]||"happy";if(a.brain&&t-a.brain<2500)return "idea";return null;}
function drawV4(t,dt){const g=V4.g,ph=V4.phase||"day";V4.drawCalls=0;AMB.calls=0;if(!REDUCED)ambSchedule(t);
  // fish move continuously but are drawn at 8 fps steps (cheap, still reads as drifting)
  if(!REDUCED)V4.fish.forEach(f=>{f.x+=f.v*dt/1000;const w=V4M.shadows.sprites[f.n].w;if(f.x>WW+w)f.x=-w;if(f.x<-w)f.x=WW+w;});
  const wi=REDUCED?0:Math.floor(t/1000*V4_WFPS)%4,ft=REDUCED?0:Math.floor(t/125)*125;
  const crew=agents.map(a=>({a,f:v4Pick(a,t),x:Math.round(a.x),y:Math.round(a.y),e:v4EmoteAt(a,t)}));
  const fx=WORLD.confetti.length+WORLD.fireworks.length+sparkles.length;
  const rain=!REDUCED&&/rain|drizzle|storm/.test((()=>{try{return wxKind();}catch(e){return "";}})());
  const key=ph+wi+"|"+V4.fish.map(f=>Math.round(f.x/2)).join(",")+"|"+crew.map(c=>c.x+","+c.y+","+c.f[0]+","+c.f[1]+","+(c.e||"")).join(";")+"|"+(fx?t:0)+(rain?"|"+Math.floor(t/100):"")+ambKey(t);
  V4.busy=fx>0||rain||AMB.busy||agents.some(a=>a.walking||a.anim||a.combo);
  if(key===V4.lastKey)return false;V4.lastKey=key;const t0=performance.now();const OYA=V4.oy;g.setTransform(1,0,0,1,0,OYA); // v4.3.1: world coords stay 402x620; the sea fills the rows above/below
  const wc=V4.water[wi]||V4.water[0];if(wc){g.drawImage(wc,0,-OYA);V4.drawCalls++;}else{g.fillStyle="#1f5e6e";g.fillRect(0,-OYA,WW,V4.EH);}
  V4.fish.forEach(f=>v4Shadow(g,f.n,ft,f.x,f.y,f.v<0));
  /* v4.3 ambient (6_v4amb.js, AMBIENT-v4.2.md): sea events under the hull; the hull + everything on it bobs 0/1 px (4 s) via one translate */
  let ta=performance.now();ambSea(g,t);let am=performance.now()-ta;const dy=ambBob(t);BOB=dy;g.save();g.translate(0,dy);
  const L=V4M.world.layers;g.drawImage(V4.img[L.ship[ph]],0,0);V4.drawCalls++;
  ta=performance.now();ambDeck(g,t,0);am+=performance.now()-ta;
  crew.sort((p,q)=>p.y-q.y);
  const drawC=c=>{const C=V4M.characters[c.a.id],im=V4.img[C.file];if(!v4OnClimb(c.a)){v4Shadow(g,"drop",0,c.x,c.y,false);}
    g.drawImage(im,c.f[0]*C.frameW,c.f[1]*C.frameH,C.frameW,C.frameH,c.x-C.anchor[0],c.y-C.anchor[1],C.frameW,C.frameH);V4.drawCalls++;};
  // ambient inside the depth pass: aquarium fish + resting butterflies after the wall glow and before any sprite; the flag y-sorted on its pole base
  const flag=ambFlag(t),under=()=>{const a=performance.now();ambAquarium(g,t,0);ambAir(g,t,"ground");am+=performance.now()-a;};
  v41DepthPass(g,ph,crew,drawC,under,flag?[{k:flag.y,draw:()=>flag.draw(g,0)}]:null); // v4.1: crew + furniture in one y-sorted pass (6_v41d.js) — replaces FRONT_BANDS and the glow-over-crew layer
  const EM=V4M.emotes,emi=V4.img[V4M.emotesFile];
  crew.forEach(c=>{if(!c.e||!EM[c.e])return;const e=EM[c.e],h=V4M.characters[c.a.id].height,ex=c.x+6,ey=Math.max(e.h,c.y-h-1);g.drawImage(emi,e.x,e.y,e.w,e.h,ex-e.anchor[0],ey-e.anchor[1]+e.h-1,e.w,e.h);V4.drawCalls++;});
  g.restore();
  if(rain){g.fillStyle="#a7d8cb";const n=Math.round(70*V4.EH/WH),s=Math.floor(t/100);for(let i=0;i<n;i++){const x=(i*97+s*13)%WW,y=(i*53+s*29)%V4.EH-OYA;g.fillRect(x,y,1,4);}}
  WORLD.fireworks.forEach(p=>{g.fillStyle=p.c;g.fillRect(p.x|0,p.y|0,p.life>500?2:1,p.life>500?2:1);});
  WORLD.confetti.forEach(p=>{g.fillStyle=p.c;g.fillRect(p.x|0,p.y|0,2,Math.floor(t/120+p.x)%2?2:1);});
  for(let i=sparkles.length-1;i>=0;i--){const s=sparkles[i];s.life-=dt;s.vy+=60*dt/1000;s.x+=s.vx*dt/1000;s.y+=s.vy*dt/1000;if(s.life<=0){sparkles.splice(i,1);continue;}g.fillStyle=["#e9b84c","#f6f2e7","#a7d8cb"][i%3];g.fillRect(s.x|0,s.y|0,2,2);}
  ta=performance.now();ambAir(g,t);am+=performance.now()-ta;
  V4.ambMs=(V4.ambMs||0)*0.9+am*0.1;V4.ambLast=am;V4.drawCalls+=AMB.calls;
  g.setTransform(1,0,0,1,0,0);V4.drawMs=V4.drawMs*0.9+(performance.now()-t0)*0.1;V4.drawn++;return true;}
/* ---------- loop: 30 fps while anyone walks or effects play, 10 fps otherwise, 15 fps cap with reduced motion; unchanged frames are not redrawn ---------- */
function frameV4(now){rafId=0;if(document.hidden)return;
  const minDt=REDUCED?66:(V4.busy?33:100);if(now-lastDraw<minDt-2){schedule();return;}
  const dt=Math.min(100,now-lastT);lastT=now;lastDraw=now;const t=now;V4.frames++;
  if(V4.want!==(V4.want=v4PhaseNow())||(!V4.phase&&!V4.pending))v4SetPhase(V4.want);
  HOOK.tick.forEach(f=>f(dt,t));
  agents.forEach(a=>{if(a.anim){if(performance.now()-a.anim.t0>a.anim.dur)a.anim=null;}else if(!a.combo)updateAgent(a,dt);});
  if(V4.ready&&V4.phase)drawV4(t,dt);
  updateBubbles(t,OX,OY);
  for(let i=floaties.length-1;i>=0;i--){const f=floaties[i];f.life-=dt;f.y-=12*dt/1000;f.e.style.left=(OX+f.x*SCALE)+"px";f.e.style.top=(OY+f.y*SCALE)+"px";f.e.style.opacity=Math.min(1,f.life/600);if(f.life<=0){f.e.remove();floaties.splice(i,1);}}
  schedule();}
/* integer device-pixel scale (3 on iPhone 16 Pro): backing store stays 402x620, CSS size = 402*k/dpr */
try{document.fonts&&document.fonts.ready.then(()=>agents.forEach(a=>a._bw=0));}catch(e){}
function fitV4(){const wrap=$("stageWrap"),dpr=window.devicePixelRatio||1,cv=V4.cv;const aw=Math.max(1,wrap.clientWidth);
  let k=Math.max(1,Math.floor(aw*dpr/WW+1e-6)),EH=WH;
  const wide=window.matchMedia("(min-width:900px)").matches;if(wide){const ah=window.innerHeight-24-(($("crewStrip")||{}).offsetHeight||0)-(($("topCard")||{}).offsetHeight||0);k=Math.max(Math.min(k,Math.max(1,Math.floor(dpr))),Math.min(k,Math.floor(ah*dpr/WH+1e-6)));} /* v4.1: never below 1 CSS px per art px on a wide screen (the page scrolls a little on short ones) */
  /* v4.1 (owner 23:00/23:05): the phone Ship tab is the ship + the whole CREW STATUS strip above the tab bar, at a whole-number pixel scale
     (k device px per art px, the largest that fits both the width and the height left over) */
  if(!wide&&window.matchMedia("(max-width:640px)").matches&&window.innerHeight>window.innerWidth){const tb=$("tabbar"),cs=$("crewStrip"),top=wrap.getBoundingClientRect().top+window.scrollY;
    const ah=window.innerHeight-((tb&&tb.offsetHeight)||0)-top-((cs&&cs.offsetHeight)||0)-6;if(ah>0)k=Math.max(1,Math.min(k,Math.floor(ah*dpr/WH+1e-6)));
    /* v4.3 (owner 23:48): the Ship tab is only the ship, centred in the space between the safe area and the tab bar */
    /* v4.3.1 (owner 00:16): same ship size, but the canvas now fills that whole space and the rows above/below the ship are sea */
    EH=Math.max(WH,Math.floor((ah+6)*dpr/k+1e-6));} /* v4.3.2: sea right down to the tab bar */
  if(wrap.style.paddingTop)wrap.style.paddingTop="";
  if(EH!==V4.EH||cv.height!==EH){V4.EH=EH;cv.height=EH;V4.g.imageSmoothingEnabled=false;V4.lastKey=null;if(V4.phase&&V4.water.length)v4BuildWater();}
  V4.oy=Math.floor((EH-WH)/2);
  V4.k=k;const cw=WW*k/dpr,ch=EH*k/dpr;if(cv.style.width!==cw+"px"||cv.style.height!==ch+"px"){cv.style.width=cw+"px";cv.style.height=ch+"px";}
  SCALE=cw/WW;STAGE_W=$("stage").clientWidth;v4Snap();agents.forEach(a=>a._bw=0);document.body.classList.remove("tiny");}
/* v4.3 crisp pixels: the world canvas sat at a fractional device-pixel y under the DOM HUD (e.g. 74.28 css px = 222.84 device px on
   iPhone 16 Pro), so every art row straddled two device rows. A sub-pixel CSS translate puts it back on the grid; re-checked once a second
   because the HUD height changes after fonts / data arrive. */
function v4Snap(){const Z=typeof V4Z!=="undefined"&&V4Z.s>1;if(Z&&V4Z.anim)return; /* v4.3.2: while zoomed, measure with the stage transform lifted for a moment (not mid-animation) */
  const st=$("stage"),stp=st.style.transform;if(Z){st.style.transition="none";st.style.transform="";}
  const cv=V4.cv,dpr=window.devicePixelRatio||1,prev=cv.style.transform;cv.style.transform="";const r=cv.getBoundingClientRect();if(Z)st.style.transform=stp;
  const fx=((r.left+window.scrollX)*dpr)%1,fy=((r.top+window.scrollY)*dpr)%1,sx=fx>1e-3?(1-fx)/dpr:0,sy=fy>1e-3?(1-fy)/dpr:0;
  const tr=sx||sy?`translate(${sx.toFixed(4)}px,${sy.toFixed(4)}px)`:"";cv.style.transform=tr;if(tr!==prev)V4.snapped=tr;OX=cv.offsetLeft+sx;OY=cv.offsetTop+sy+V4.oy*SCALE;}
setInterval(()=>{if(!document.hidden&&V4.ready)v4Snap();},1000);
/* canvas taps / hover (hit box widened to 44 css px on touch) */
function v4XY(ev){const r=V4.cv.getBoundingClientRect();return [(ev.clientX-r.left)*WW/r.width,(ev.clientY-r.top)*V4.EH/r.height-V4.oy];}
function v4Hit(ev,pad){const [x,y]=v4XY(ev),half=Math.max(11,(pad||22)/SCALE);let best=null,bd=1e9;
  agents.forEach(a=>{const h=V4M.characters[a.id].height;if(Math.abs(x-a.x)<=half&&y>=a.y-h-4&&y<=a.y+6){const d=Math.abs(x-a.x)+Math.abs(y-(a.y-h/2))*0.5;if(d<bd){bd=d;best=a;}}});return best;}
V4.cv.addEventListener("click",ev=>{const a=v4Hit(ev,ev.pointerType==="mouse"?14:22);if(a){openPanel(a);beep(740);}});
V4.cv.addEventListener("mousemove",ev=>{const h=v4Hit(ev,14);if(!h&&hoverRaw)hoverUntil=performance.now()+500;hoverRaw=h||null;if(h)hoverAgent=h;V4.cv.style.cursor=h?"pointer":"default";});
V4.cv.addEventListener("mouseleave",()=>{if(hoverRaw)hoverUntil=performance.now()+500;hoverRaw=null;});
V4.cv.addEventListener("pointerup",ev=>{if(ev.pointerType!=="mouse"){hoverRaw=null;hoverUntil=0;}});
/* ---------- portraits (crew panel, roster, status strip) ---------- */
function portraitV4(canvas,id,frame){const P=V4M.portraits,i=P.order.indexOf(id),im=V4.img[P.file24];canvas.width=28;canvas.height=28;canvas.classList.add("pt4");canvas.dataset.pid=id;
  const g=canvas.getContext("2d");g.imageSmoothingEnabled=false;g.clearRect(0,0,28,28);const fr=V4M.ui.portrait_frame,hud=V4.img[V4M.uiFile];
  if(hud)g.drawImage(hud,fr.x,fr.y,fr.w,fr.h,0,0,28,28);if(im&&i>=0)g.drawImage(im,i*24,0,24,24,2,2,24,24);if(frame==="blink")v41Blink(g,id);}
/* ---------- HUD (DOM) ---------- */
/* TOP DEAL = a real, current deal only: a deal_found row in CREW STATUS (Chopper / crew feed) with a numeric discount (% below the average buy price),
   dated within the last 24h. Price and product come from its event_text. No current deal -> the card shows MY COMMISSION instead (owner feedback 18:57). */
const V4_DEAL_MAX_AGE=24*3600e3;
function v4TopDeal(){let deal=null;const f=FEEDS.crew;
  if(f&&f.ok)f.rows.forEach(r=>{if(String(r.event_type||"").toLowerCase()!=="deal_found")return;const d=num(r.discount);if(d==null||!(d>0))return;
    const at=parseDate(r.event_at||r.updated_at);if(!at||Date.now()-at.getTime()>V4_DEAL_MAX_AGE||at.getTime()-Date.now()>3600e3)return;
    const txt=String(r.event_text||"").trim(),pm=txt.match(/R\$\s?\d[\d.,]*/),price=pm?numMoney(pm[0].replace(/[.,]+$/,"")):null; /* v4.1 V4-3: BR "R$ 1.234,56" and US "R$1,234.56" */
    const prod=txt.replace(/R\$\s?\d[\d.,]*/g,"").replace(/[-−]?\d+(?:\.\d+)?\s*%[^,;·]*/g,"").replace(/\(\s*\)?/g,"").replace(/\s*[·,;:@|(]\s*$/,"").replace(/\s{2,}/g," ").trim();
    if(!deal||d>deal.d)deal={d,price,prod:prod||txt||"deal",text:txt,who:String(r.crew_id||""),at};});
  return {deal};}
/* v4.1 (Law/owner 20:53): the shown state comes ONLY from the CREW STATUS `state` column: working / idle / resting; blank or anything else = resting.
   (v4 bug: v4State checked the simulated low-energy nap flag `a.resting` first, so a bot whose energy ran down showed "resting" even with state=working.) */
function v4State(a){const s=String(a.state||"").trim().toLowerCase();return s==="working"?"working":s==="idle"?"idle":"resting";}
const STATE_LABEL={working:"Working",idle:"Idle",resting:"Resting"};
function v4Hud(){} // v4.1: the top card is filled in 6_v41.js
function v4Strip(){const row=$("csRow");if(!row)return;if(!row.children.length){agents.forEach(a=>{const sp=document.createElement("span");sp.className="cs";sp.dataset.id=a.id;const c=document.createElement("canvas");portraitV4(c,a.id);const d=document.createElement("i");d.className="dot4";const w=document.createElement("span");w.className="csw";sp.append(c,d,w);row.appendChild(sp);});}
  const live=FEEDS.crew&&FEEDS.crew.ok;
  [...row.children].forEach(sp=>{const a=agents.find(x=>x.id===sp.dataset.id);if(!a)return;const st=v4State(a),d=sp.querySelector(".dot4"),w=sp.querySelector(".csw");if(d.dataset.s!==st){d.dataset.s=st;d.className="dot4 "+st;w.textContent=STATE_LABEL[st];w.className="csw "+st;}sp.title=a.name+": "+STATE_LABEL[st]+(a.status?" · "+a.status:"");sp.classList.toggle("needs",!!crewDecision(a));});
  const cf=FEEDS.crew,stale=cf&&/stale/i.test(cf.note||""),tm=cf&&(cf.note||"").match(/(\d{1,2}:\d{2})/),sync=$("csSync");
  const txt=live?(stale?"stale ":"synced ")+(tm?tm[1]:""):"offline";if(sync&&sync.textContent!==txt){sync.textContent=txt.trim();sync.classList.toggle("off",!live||stale);sync.title=live?(cf.note||""):"crew feed unavailable: showing the built-in status";}}
if($("crewStrip"))$("crewStrip").onclick=()=>{const r=$("roster"),sec=r&&r.closest("section");if(sec){sec.classList.remove("collapsed");sec.scrollIntoView({behavior:REDUCED?"auto":"smooth",block:"start"});}};
const _renderStats=renderStats;renderStats=function(){_renderStats();try{v4Hud();}catch(e){console.warn(e);}};
const _renderRoster=renderRoster;renderRoster=function(){_renderRoster();try{v4Strip();}catch(e){}};
setInterval(()=>{if(!document.hidden)v4Strip();},2000);
/* ---------- a gold coin in front of every money figure (DOM text outside the world canvas) ---------- */
const MONEY_RE=/(?:R\$|US\$)\s?-?\d[\d.,]*(?:\s?(?:k|mil))?/g;
function coinify(root){if(!root||root.nodeType!==1)return;const w=document.createTreeWalker(root,NodeFilter.SHOW_TEXT,{acceptNode:n=>{const p=n.parentElement;if(!p||p.closest(".money,#stage,script,style,textarea,select,option,input,canvas,title"))return NodeFilter.FILTER_REJECT;MONEY_RE.lastIndex=0;return MONEY_RE.test(n.nodeValue)?NodeFilter.FILTER_ACCEPT:NodeFilter.FILTER_REJECT;}});
  const list=[];while(w.nextNode())list.push(w.currentNode);
  list.forEach(n=>{const s=n.nodeValue,frag=document.createDocumentFragment();let i=0;MONEY_RE.lastIndex=0;let m;while((m=MONEY_RE.exec(s))){if(m.index>i)frag.append(s.slice(i,m.index));const sp=document.createElement("span");sp.className="money";sp.textContent=m[0];frag.append(sp);i=m.index+m[0].length;}if(i<s.length)frag.append(s.slice(i));n.replaceWith(frag);});}
/* owner feedback #3: native emoji -> ui/v4 pixel icons (hud.png icons, emotes.png); weather/food emoji with no pixel icon are dropped (the words are already there) */
const EMO_ICON={"🪙":"coin","💰":"coin","💡":"idea","♥":"em heart","❤":"em heart","♪":"em music","🎵":"em music","🎶":"em music","★":"em happy","☆":"em happy","🏆":"em happy","👑":"em happy","🎉":"em happy","🎆":"em happy","🍾":"em happy","⭐":"em happy",
 "💢":"em focused","⚡":"em focused","☎":"em surprised","📞":"em surprised","❗":"em surprised","⚠":"em surprised","❓":"em question","🔍":"em question","📜":"map","🗺":"map","💬":"chat","✉":"send","⚙":"settings","✕":"close","✖":"close","📦":"pallet","🏷":"deal","👥":"crew","😴":"em sleepy","💤":"em sleepy"};
EMO_ICON["💡"]="em idea";
const EMO_KEEP=new Set(["→","↗","↘","↔","▲","▼","▾","●","○","◌","≈","©","®","™","✓","×","↺","⇄"]);
const EMO_RE=/(?:\p{Extended_Pictographic}|[\u2600-\u27BF\u2B00-\u2BFF\u2190-\u21FF\u25A0-\u25FF])\uFE0F?(?:\u200D\p{Extended_Pictographic}\uFE0F?)*/gu;
function iconify(root){if(!root||root.nodeType!==1)return;const w=document.createTreeWalker(root,NodeFilter.SHOW_TEXT,{acceptNode:n=>{const p=n.parentElement;if(!p||p.closest("script,style,textarea,select,option,input,canvas,title,.ic"))return NodeFilter.FILTER_REJECT;EMO_RE.lastIndex=0;let m;while((m=EMO_RE.exec(n.nodeValue)))if(!EMO_KEEP.has(m[0].replace("\uFE0F","")))return NodeFilter.FILTER_ACCEPT;return NodeFilter.FILTER_REJECT;}});
  const list=[];while(w.nextNode())list.push(w.currentNode);
  list.forEach(n=>{const s=n.nodeValue,frag=document.createDocumentFragment();let i=0,m;EMO_RE.lastIndex=0;
    while((m=EMO_RE.exec(s))){const ch=m[0].replace(/\uFE0F/g,"");if(EMO_KEEP.has(ch))continue;if(m.index>i)frag.append(s.slice(i,m.index));const k=EMO_ICON[ch]||EMO_ICON[ch[0]];if(k){const e=document.createElement("i");e.className="ic "+k;e.setAttribute("aria-hidden","true");frag.append(e);}i=m.index+m[0].length;if(!k&&s[i]===" ")i++;}
    if(i<s.length)frag.append(s.slice(i));n.replaceWith(frag);});}
let coinPending=false;const coinObs=new MutationObserver(()=>{if(coinPending)return;coinPending=true;requestAnimationFrame(()=>{coinPending=false;coinObs.disconnect();try{iconify(document.body);coinify(document.body);}finally{coinObs.observe(document.body,{childList:true,subtree:true,characterData:true});}});});
/* ---------- boot ---------- */
v4InstallSpots();v4Fish();
V4.load=v4Load().then(()=>(typeof AMB!=="undefined"&&AMB.load)||null).then(()=>{V4.ready=true;v4SetPhase(V4.want=v4PhaseNow());try{_renderRoster();}catch(e){}try{const a=panelAgent;if(a)portraitV4($("portrait"),a.id);}catch(e){}document.querySelectorAll("#csRow canvas").forEach(c=>portraitV4(c,c.parentElement.dataset.id));v4Strip();fitV4();V4.lastKey="";});
HOOK.boot.push(()=>{iconify(document.body);coinify(document.body);coinObs.observe(document.body,{childList:true,subtree:true,characterData:true});});
