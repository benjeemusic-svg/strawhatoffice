/* ================= OVERLAY: name tags, speech bubbles, room labels ================= */
const stage=$("stage");let SCALE=2, BOB=0, ZOOM=false;
/* each tag = a small name label + a separate speech bubble that fades in/out (never re-created) */
agents.forEach(a=>{a.el=document.createElement("div");a.el.className="tag";a.el.innerHTML='<b class="nm"></b><div class="bub"><b></b><span class="st"></span></div>';a.el.querySelectorAll("b").forEach(b=>b.textContent=a.name);a._bub=a.el.querySelector(".bub");a._stEl=a.el.querySelector(".st");a._stEl.textContent=a.status;a._on=false;a._onAt=-1e9;a._offAt=-1e9;a._sx=0;stage.appendChild(a.el);});
let STAGE_W=0, OX=0, OY=0;
/* motion + battery: honour prefers-reduced-motion, pause the loop while the page is hidden */
const RM_Q=window.matchMedia?window.matchMedia("(prefers-reduced-motion: reduce)"):{matches:false};let REDUCED=!!RM_Q.matches;if(RM_Q.addEventListener)RM_Q.addEventListener("change",e=>REDUCED=e.matches);
const ROOMS=[...Object.values(RM).map(r=>[r.name,r.x+2,r.y+2]),["CROW'S NEST",370,26],["LAWN DECK",404,316],["HALL",44,168],["BOW",540,240]];
const roomEls=ROOMS.map(([n,x,y])=>{const e=document.createElement("div");e.className="room";e.textContent=n;stage.appendChild(e);return {e,x,y};});
const floaties=[], sparkles=[];
function floaty(text,x,y){const e=document.createElement("div");e.className="floaty";v41Num(e,text);stage.appendChild(e);floaties.push({e,x,y,life:2200});}
function celebrate(n){beep(523,.1);setTimeout(()=>beep(659,.1),110);setTimeout(()=>beep(784,.15),220);floaty(`+${n} items!`,108,282);for(let i=0;i<24;i++)sparkles.push({x:108,y:296,vx:(Math.random()-.5)*60,vy:-30-Math.random()*40,life:1500});}
let talkIdx=0, hoverAgent=null, hoverRaw=null, hoverUntil=0; setInterval(()=>{talkIdx=(talkIdx+1)%agents.length;},4200);
/* ===== speech-bubble manager: boolean decisions, priority, cap, min on/off time (hysteresis), fades via CSS ===== */
const BUB_MIN_ON=1600, BUB_MIN_OFF=350, BUB_HARD_MIN=600, BUB_TXT_MIN=600; /* v3.1.2 C5: a shown bubble/text always stays at least 600ms, even when an event preempts it */
function bubbleText(a,t){const saying=!!(a.say&&t<a.say.until);return a.anim?((voiceEvent(a.id,a.anim.type)||EVENTS[a.anim.type].label)+(a.anim.text?" "+a.anim.text:"")+(a.anim.preview?" (preview)":"")):saying?a.say.text:(ringing(a)?"☎ needs a decision! ":"")+a.status;}
function updateBubbles(t,ox,oy){
  const tiny=document.body.classList.contains("tiny"),MAX=(tiny||(typeof V4!=="undefined"&&V4.on))?1:3; /* v4: one bubble at a time, labels never stack on the phone */
  hoverAgent=hoverRaw||(t<hoverUntil?hoverAgent:null);
  const prio=agents.map((a,i)=>a.anim?4:a===hoverAgent?3:(a.say&&t<a.say.until)?2:(i===talkIdx&&!(typeof V4!=="undefined"&&V4.on)?1:0)); /* v4: no ambient status bubbles; only events, spoken lines and the tapped crew */
  const order=agents.map((a,i)=>i).filter(i=>prio[i]>0).sort((x,y)=>prio[y]-prio[x]||(agents[y]._on-agents[x]._on)||((agents[y].say?agents[y].say.until:0)-(agents[x].say?agents[x].say.until:0)));
  const want=new Set(order.slice(0,MAX));
  // keep bubbles that were just shown (min on-time) unless something urgent (event/hover) needs the slot
  agents.forEach((a,i)=>{if(a._on&&!want.has(i)&&t-a._onAt<BUB_MIN_ON&&prio[i]>=0){const urgent=order.slice(0,MAX).some(j=>prio[j]>=3&&!agents[j]._on);if(!urgent||want.size<MAX)want.add(i);}
    if(a._on&&!want.has(i)&&t-a._onAt<BUB_HARD_MIN)want.add(i);});
  let shown=0;
  agents.forEach((a,i)=>{let on=want.has(i);
    if(on&&!a._on&&t-a._offAt<BUB_MIN_OFF&&prio[i]<3)on=false;           // don't re-open a bubble that just closed
    if(on&&!a._on&&shown>=MAX+1)on=false;
    if(on!==a._on){a._on=on;if(on)a._onAt=t;else a._offAt=t;a.el.classList.toggle("talk",on);a._bw=0;}
    if(on){shown++;const stx=bubbleText(a,t);if(a._st!==stx&&(!a._stAt||t-a._stAt>=BUB_TXT_MIN||t-a._onAt<50)){a._st=stx;a._stAt=t;v41Num(a._stEl,stx);a._bw=0;}}
    // integer positions, written only when changed
    const L=Math.round(ox+a.x*SCALE),T=Math.round(oy+(a.y-LOOKS[a.id].ht-3+BOB)*SCALE);
    if(a._L!==L){a._L=L;a.el.style.left=L+"px";}if(a._T!==T){a._T=T;a.el.style.top=T+"px";}
    // keep the bubble inside the stage: measure only when shown/text changed, shift with hysteresis (>3px)
    if(on){if(!a._bw)a._bw=a._bub.offsetWidth||60;const hw=a._bw/2,sw=STAGE_W||stage.scrollWidth;let sx=0;if(L-hw<2)sx=2-(L-hw);else if(L+hw>sw-2)sx=(sw-2)-(L+hw);sx=Math.round(sx);
      if(sx!==a._sx){a._sx=sx; /* v3.1.2 C4: follow the edge exactly (was >3px hysteresis = visible 4px steps) */a._bub.style.setProperty("--sx",sx+"px");}}
  });
}
const isMobile=()=>window.matchMedia("(max-width:640px)").matches;
function fit(){if(V4.on){fitV4();return;}const wrap=$("stageWrap"),mob=isMobile();let aw=wrap.clientWidth-(mob?12:24);
  const ah=mob?9999:Math.max(280,window.innerHeight-(document.querySelector("header").offsetHeight+96));
  let s=Math.min(aw/W,ah/H);if(!mob)s=Math.max(1,s);if(ZOOM)s=Math.max(s*2,2);SCALE=s;cv.style.width=Math.round(W*s)+"px";cv.style.height=Math.round(H*s)+"px";
  $("stage").classList.toggle("zoomed",ZOOM);roomEls.forEach(r=>r.e.style.fontSize=Math.max(5,Math.round(s*3.4))+"px");document.body.classList.toggle("tiny",s<1.2);STAGE_W=$("stage").scrollWidth;OX=cv.offsetLeft+3;OY=cv.offsetTop+3;agents.forEach(a=>a._bw=0);roomEls.forEach(r=>r.L=r.T=null);}
window.addEventListener("resize",fit);if(window.ResizeObserver)new ResizeObserver(()=>fit()).observe($("stageWrap"));window.addEventListener("orientationchange",()=>setTimeout(fit,300));
/* ================= SEA (top-down): shimmer, waves, fish shadows, foam ================= */
const shimmer=Array.from({length:220},()=>({x:Math.random()*W,y:Math.random()*H,p:Math.random(),s:.5+Math.random()}));
const fishes=Array.from({length:9},(_,i)=>({x:Math.random()*W,y:i<5?6+Math.random()*48:340+Math.random()*18,v:(Math.random()<.5?-1:1)*(6+Math.random()*10),sz:3+Math.floor(Math.random()*4),p:Math.random()*6}));
const foam=[];
function band(y0,y1,t,spd,len,col,gap){for(let y=y0;y<y1;y+=5){const off=(t*spd/1000+y*13)%gap;for(let x=-gap;x<W+gap;x+=gap)R(ctx,Math.round(x+((y*7)%gap)-off),y,len,1,col);}}
function drawSea(t){const g=ctx.createLinearGradient(0,0,0,H);g.addColorStop(0,"#2f8fd8");g.addColorStop(.5,"#2a82cc");g.addColorStop(1,"#1d6fb6");ctx.fillStyle=g;ctx.fillRect(0,0,W,H);
  band(0,H,t,7,6,"rgba(255,255,255,.18)",38);band(2,H,t,-4,4,"rgba(10,60,120,.25)",52);
  fishes.forEach(f=>{f.x+=f.v*0.016;if(f.x<-20)f.x=W+20;if(f.x>W+20)f.x=-20;const x=Math.round(f.x),y=Math.round(f.y+Math.sin(t/900+f.p)*2),d=f.v>0?1:-1,tw=Math.floor(t/200+f.p)%2;
    oval(ctx,x,y,f.sz+2,Math.max(1,f.sz>>1),"rgba(8,40,80,.32)");R(ctx,x-d*(f.sz+3),y-1+tw,2,2,"rgba(8,40,80,.32)");});
  shimmer.forEach(s=>{const q=(t/1400*s.s+s.p)%1;if(q<.18)R(ctx,s.x|0,s.y|0,q<.09?2:1,1,"rgba(255,255,255,.75)");});}
/* grass tufts that sway with the wind */
const tufts=[];for(let i=0;i<170;i++){const x=306+Math.random()*182,y=76+Math.random()*248;if(Math.abs(y-198)<6||y<HCY-hullHalf(x)+10||y>HCY+hullHalf(x)-10)continue;tufts.push({x:x|0,y:y|0,p:Math.random()*6,c:Math.random()<.5?"#4e9a36":"#8ee06a"});}
function drawGrass(t){const amp=(typeof WEATHER!=="undefined"&&WEATHER.wind>20)?2:1;tufts.forEach(u=>{const s=Math.round(Math.sin(t/650+u.p+u.x/30)*amp);R(ctx,u.x,u.y-1,1,2,u.c);R(ctx,u.x+s,u.y-3,1,2,u.c);R(ctx,u.x+2,u.y-1,1,2,u.c);R(ctx,u.x+2+s,u.y-2,1,1,u.c);});}
function drawAquariumFish(t){for(let i=0;i<4;i++){const p=((t/(4200+i*1300))+i*.27)%1,dir=i%2?1:-1,fx=Math.round(dir>0?220+p*70:290-p*70),fy=226+i*2,c=["#ffb347","#ff6b6b","#ffd24a","#7fffd4"][i];R(ctx,fx,fy,3,2,c);R(ctx,fx+(dir>0?-1:3),fy,1,2,c);}for(let i=0;i<3;i++){const q=((t/2200)+i/3)%1;R(ctx,236+i*24,233-Math.round(q*9),1,1,"rgba(255,255,255,.8)");}}
function drawPallet(){R(ctx,44,306,44,10,"#a8703a");R(ctx,44,306,44,1,"#c08a4e");R(ctx,44,315,44,1,"#5c3416");[46,64,82].forEach(x=>R(ctx,x,314,4,3,"#5c3416"));
  const boxes=Math.min(9,(stats&&stats.onPallet)?stats.onPallet.orders:0); /* one crate per order actually on the pallet (PALLET # filled), no goal */for(let i=0;i<boxes;i++){const c=i%3,r=Math.floor(i/3),x=45+c*14,y=297-r*8;R(ctx,x,y,13,9,"#d9a066");R(ctx,x,y,13,2,"#f0c890");R(ctx,x+6,y,1,9,"#b8862a");R(ctx,x,y+8,13,1,"#8a5527");}}
/* ================= DAY / NIGHT on São Paulo time ================= */
function dayPhase(){const m=LS.get("timeMode","auto");if(m==="day")return {dark:0,tint:0,label:"day (preview)"};if(m==="night")return {dark:.55,tint:0,label:"night (preview)"};if(m==="dusk")return {dark:.25,tint:.16,label:"dusk (preview)"};
  const n=spNow(),h=n.h+n.mi/60;let dark=0,tint=0;if(h<5||h>=20)dark=.55;else if(h<7)dark=.55*(7-h)/2;else if(h>=17.5)dark=.55*Math.min(1,(h-17.5)/2.5);if(h>=16.5&&h<19.5)tint=.16*Math.sin((h-16.5)/3*Math.PI);if(h>=5&&h<7)tint=Math.max(tint,.1*Math.sin((h-5)/2*Math.PI));
  return {dark,tint,label:dark>.4?"night":tint>.05?(h<12?"dawn":"dusk"):"day"};}
const darkCv=mk(W,H),dg=darkCv.getContext("2d");
function drawLighting(t){const P=dayPhase();if(P.tint>0){ctx.fillStyle=`rgba(255,130,50,${P.tint.toFixed(3)})`;ctx.fillRect(0,0,W,H);}if(P.dark<=0.01)return;
  dg.globalCompositeOperation="source-over";dg.clearRect(0,0,W,H);dg.fillStyle=`rgba(6,12,40,${P.dark.toFixed(3)})`;dg.fillRect(0,0,W,H);dg.globalCompositeOperation="destination-out";
  const fl=Math.floor(t/230)%9?1:.85;[...LIGHTS,...HOOK.light.flatMap(f=>f())].forEach(([x,y,r=34])=>{const gr=dg.createRadialGradient(x,y+BOB,2,x,y+BOB,r*fl);gr.addColorStop(0,"rgba(0,0,0,1)");gr.addColorStop(1,"rgba(0,0,0,0)");dg.fillStyle=gr;dg.fillRect(x-r,y+BOB-r,r*2,r*2);});
  ctx.drawImage(darkCv,0,0);ctx.globalCompositeOperation="lighter";LIGHTS.forEach(([x,y])=>{const gr=ctx.createRadialGradient(x,y+BOB,1,x,y+BOB,16);gr.addColorStop(0,`rgba(255,190,90,${(.22*P.dark/.55).toFixed(3)})`);gr.addColorStop(1,"rgba(255,190,90,0)");ctx.fillStyle=gr;ctx.fillRect(x-16,y+BOB-16,32,32);});ctx.globalCompositeOperation="source-over";}
/* ================= EMOTES + IDLE QUIRKS ================= */
const EMO={"!":["#ffd24a",[[3,1,1,4],[3,6,1,1]]],"?":["#7fc8ff",[[2,1,3,1],[4,2,1,1],[3,3,1,1],[3,4,1,1],[3,6,1,1]]],"♥":["#ff6b8a",[[1,2,2,2],[4,2,2,2],[1,3,5,2],[2,5,3,1],[3,6,1,1]]],"♪":["#a6f27c",[[4,1,1,5],[5,1,1,1],[2,5,3,2]]],"💧":["#7fc8ff",[[3,1,1,1],[2,2,3,3],[3,5,1,1]]],"💢":["#e0424f",[[1,1,2,1],[1,2,1,1],[5,1,2,1],[6,2,1,1],[1,5,1,1],[1,6,2,1],[6,5,1,1],[5,6,2,1]]],"💡":["#ffe680",[[2,1,3,3],[3,4,1,1],[2,5,3,1]]],"z":["#ffffff",[[1,1,4,1],[3,2,1,1],[2,3,1,1],[1,4,4,1]]],"…":["#ffffff",[[1,4,1,1],[3,4,1,1],[5,4,1,1]]],"$":["#ffd24a",[[2,1,3,1],[1,2,2,1],[2,3,3,1],[4,4,1,1],[1,5,4,1],[3,0,1,7]]],"★":["#ffd24a",[[3,0,1,2],[0,2,7,1],[1,3,5,1],[2,4,3,1],[1,5,2,1],[4,5,2,1]]]};
function drawEmote(a,t){const E=a.emote;if(!E||t>E.until)return;const D=EMO[E.k];if(!D)return;const x=Math.round(a.x)-4,y=Math.round(a.y-LOOKS[a.id].ht-14-Math.min(3,(t-E.t0)/60));R(ctx,x-1,y-1,10,10,OUTL);R(ctx,x,y,8,8,"#fffaf0");R(ctx,x+3,y+8,2,2,OUTL);D[1].forEach(([dx,dy,w,h])=>R(ctx,x+dx,y+dy,w,h,D[0]==="#ffffff"?"#555":D[0]));}
const QUIRKS={luffy:[["meat","♥"],["stretch","!"]],zoro:[["nap","z"],["lift","💢"]],nami:[["count","$"]],usopp:[["tinker","★"],["tale","!"]],sanji:[["swoon","♥"]],chopper:[["read","?"],["hop","♪"]],robin:[["read","…"]],frankie:[["tinker","★"],["stretch","!"]],law:[["read","…"],["tea","…"]],brook:[["violin","♪"],["tea","…"]],jinbe:[["tea","…"]]};
setInterval(()=>{agents.forEach(a=>{if(a.walking||a.anim||a.combo||a.quirk||a.resting||(typeof MEETING!=="undefined"&&MEETING.active))return;if(Math.random()<.18){const q=QUIRKS[a.id][Math.floor(Math.random()*QUIRKS[a.id].length)];a.quirk={k:q[0],t0:performance.now(),dur:4500};emote(a,q[1],2500);}});},3000);
function quirkDy(a,t){const Q=a.quirk;if(!Q)return 0;if(Q.k==="hop")return -Math.round(Math.abs(Math.sin((t-Q.t0)/150))*3);if(Q.k==="stretch")return Math.floor((t-Q.t0)/400)%2?-1:0;return 0;}
function drawQuirk(a,t){const Q=a.quirk;if(!Q)return;if(t-Q.t0>Q.dur){a.quirk=null;return;}const x=Math.round(a.x),y=Math.round(a.y),e=t-Q.t0,hy=y-12,ht=LOOKS[a.id].ht;
  switch(Q.k){case "meat":R(ctx,x+5,hy-4,2,6,"#f4f0e4");disc(ctx,x+7,hy-5,3,"#a8402a");R(ctx,x+6,hy-7,2,1,"#d06040");break;
   case "stretch":line(ctx,x-5,hy,x-6-Math.round(Math.sin(e/300)*6),hy-14,"#f7c9a0");break;
   case "nap":break;
   case "lift":{const ly=y-ht-2+Math.round(Math.abs(Math.sin(e/350))*4);R(ctx,x-9,ly,18,1,"#555");R(ctx,x-10,ly-2,3,5,"#333");R(ctx,x+7,ly-2,3,5,"#333");break;}
   case "count":for(let i=0;i<3;i++){disc(ctx,x+7,hy-2-i*2,2,"#ffd24a");}R(ctx,x+5,hy-9+((e/200|0)%3),3,2,"#ffd24a");break;
   case "tinker":R(ctx,x+5,hy-3,1,5,"#7a4a22");R(ctx,x+4,hy-4+(Math.floor(e/150)%2),4,2,"#888");if(Math.floor(e/150)%2)R(ctx,x+9,hy+1,1,1,"#ffd24a");break;
   case "tale":if(Math.floor(e/250)%2)line(ctx,x-5,hy,x-9,hy-6,"#c98a5a");break;
   case "swoon":break;
   case "read":R(ctx,x-4,hy-1,8,5,"#7a2e3a");R(ctx,x-3,hy-1,6,4,"#f3ecd6");R(ctx,x,hy-1,1,4,"#b8a080");break;
   case "violin":R(ctx,x-8,hy-6,4,5,"#a8582a");line(ctx,x-10+Math.round(Math.sin(e/110)*3),hy,x-2,hy-8,"#e9d3a0");break;
   case "tea":R(ctx,x+5,hy-2,4,3,"#fff");R(ctx,x+6,hy-1,2,1,"#7fb07a");if(Math.floor(e/300)%2)R(ctx,x+6,hy-5,1,2,"rgba(255,255,255,.7)");break;}}
function faceOf(a,t){if(a.resting||(a.quirk&&a.quirk.k==="nap"))return "sleep";if(a.emote&&t<a.emote.until&&"♥!★♪$".includes(a.emote.k))return "happy";if(a.combo&&a.combo.type==="goof")return "happy";return null;}
/* ================= RENDER LOOP ================= */
let lastT=performance.now(), rafId=0, lastDraw=0;
function schedule(){if(!rafId&&!document.hidden)rafId=requestAnimationFrame(frame);}
document.addEventListener("visibilitychange",()=>{if(document.hidden){if(rafId){cancelAnimationFrame(rafId);rafId=0;}}else{lastT=performance.now();schedule();}});
function frame(now){if(V4.on){frameV4(now);return;}rafId=0;if(document.hidden)return;
  if(REDUCED&&now-lastDraw<66){schedule();return;}lastDraw=now; // reduced motion: ~15 fps, no bob/foam/shimmer
  const dt=Math.min(100,now-lastT);lastT=now;const t=now;
  HOOK.tick.forEach(f=>f(dt,t));
  agents.forEach(a=>{if(a.anim){if(performance.now()-a.anim.t0>a.anim.dur)a.anim=null;}else if(!a.combo)updateAgent(a,dt);});
  BOB=REDUCED?0:Math.round(Math.sin(t/1300)*(WORLD.bobAmp>2?1.6:0.6));
  drawSea(REDUCED?0:t);HOOK.horizon.forEach(f=>f(t));
  if(!REDUCED&&Math.random()<dt/50)foam.push({x:22+Math.random()*6,y:80+Math.random()*240,vx:-14-Math.random()*8,vy:0,life:2400,max:2400});
  if(!REDUCED&&Math.random()<dt/90){const s=Math.random()<.5?-1:1;foam.push({x:600+Math.random()*10,y:200+s*(10+Math.random()*30),vx:6,vy:s*8,life:900,max:900});}
  for(let i=foam.length-1;i>=0;i--){const f=foam[i];f.life-=dt;if(f.life<=0){foam.splice(i,1);continue;}f.x+=f.vx*dt/1000;f.y+=f.vy*dt/1000;R(ctx,f.x|0,f.y|0,2,1,`rgba(255,255,255,${(f.life/f.max).toFixed(2)})`);}
  ctx.save();ctx.translate(0,BOB);
  for(let x=24;x<620;x+=3){const h=hullHalf(x);if(h>0&&Math.floor(t/400+x/9)%3===0)R(ctx,x,Math.round(HCY+h+16*(h/138))+2,2,1,"rgba(255,255,255,.6)");}
  ctx.drawImage(ship,0,0);drawAquariumFish(t);drawGrass(REDUCED?0:t);
  HOOK.ship.forEach(f=>f(t));
  const list=props.map(p=>({b:p.base,d:()=>ctx.drawImage(p.img,p.x,p.y)}));
  list.push({b:318,d:drawPallet});
  list.push({b:MAST.base,d:()=>ctx.drawImage(mastImg,MAST.x-10,MAST.top-8)});
  list.push({b:MAST.base+1,d:()=>ctx.drawImage(sailImg,MAST.x-50,66)});
  list.push({b:950,d:()=>ctx.drawImage(nestBack,MAST.x-22,MAST.top-6)});
  list.push({b:1100,d:()=>{ctx.drawImage(nestFront,MAST.x-22,MAST.top+2);for(let i=0;i<12;i++){const yo=Math.round(Math.sin(i/2-t/200));R(ctx,MAST.x+2+i,MAST.top-22+yo,1,9,"#1a1a1a");}R(ctx,MAST.x,MAST.top-24,2,20,"#5c3416");R(ctx,MAST.x+6,MAST.top-20+Math.round(Math.sin(2-t/200)),4,3,"#fff");R(ctx,MAST.x+5,MAST.top-21+Math.round(Math.sin(2-t/200)),6,1,"#f2cc55");}});
  HOOK.depth.forEach(f=>f(t).forEach(o=>list.push(o)));
  agents.forEach(a=>{const top=climbing(a)||levelOf(a.y)===0;list.push({b:top?1000+a.y:a.y,d:()=>{if(a.anim){const P=animPose(a,t);drawActor(ctx,a.id,a.x,a.y+P.dy,P.tt,P.walking,P.dir,!top,P.noHat,"happy");}else drawActor(ctx,a.id,a.x,a.y+comboDy(a,t)+quirkDy(a,t),t,a.walking,a.dir,!top,false,faceOf(a,t));}});});
  list.sort((p,q)=>p.b-q.b).forEach(o=>o.d());
  agents.forEach(a=>{if(a.anim)drawEffect(ctx,a,t);else drawQuirk(a,t);});
  HOOK.fx.forEach(f=>f(t));
  agents.forEach(a=>drawEmote(a,t));
  for(let i=sparkles.length-1;i>=0;i--){const s=sparkles[i];s.life-=dt;s.vy+=60*dt/1000;s.x+=s.vx*dt/1000;s.y+=s.vy*dt/1000;if(s.life<=0){sparkles.splice(i,1);continue;}R(ctx,s.x|0,s.y|0,2,2,["#ffd24a","#fff","#7fc8ff"][i%3]);}
  ctx.restore();
  HOOK.sea.forEach(f=>f(t));
  drawLighting(t);
  HOOK.sky.forEach(f=>f(t));
  HOOK.overlay.forEach(f=>f(t));
  // overlay positions
  const ox=OX,oy=OY; // cached in fit(): reading offsetLeft here forced a layout every frame
  updateBubbles(t,ox,oy);
  roomEls.forEach(r=>{const L=Math.round(ox+r.x*SCALE),T=Math.round(oy+(r.y+BOB)*SCALE);if(r.L!==L){r.L=L;r.e.style.left=L+"px";}if(r.T!==T){r.T=T;r.e.style.top=T+"px";}});
  for(let i=floaties.length-1;i>=0;i--){const f=floaties[i];f.life-=dt;f.y-=12*dt/1000;f.e.style.left=(ox+f.x*SCALE)+"px";f.e.style.top=(oy+f.y*SCALE)+"px";f.e.style.opacity=Math.min(1,f.life/600);if(f.life<=0){f.e.remove();floaties.splice(i,1);}}
  schedule();}
/* ================= CLICK / HOVER → PANEL ================= */
let panelAgent=null;
function canvasXY(ev){const r=cv.getBoundingClientRect();return [(ev.clientX-r.left)*W/r.width,(ev.clientY-r.top)*H/r.height-BOB];}
function hitAt(ev){const [x,y]=canvasXY(ev);return agents.slice().sort((a,b)=>b.y-a.y).find(a=>x>a.x-10&&x<a.x+10&&y>a.y-LOOKS[a.id].ht&&y<a.y+2);}
/* sticky hover: keep the hovered crew while the pointer stays within a padded box, plus a short grace period */
function stillOver(ev,a){const [x,y]=canvasXY(ev);return a&&x>a.x-15&&x<a.x+15&&y>a.y-LOOKS[a.id].ht-8&&y<a.y+6;}
cv.addEventListener("mousemove",ev=>{const h=stillOver(ev,hoverRaw)?hoverRaw:(hitAt(ev)||null);if(!h&&hoverRaw){hoverUntil=performance.now()+500;}hoverRaw=h;if(h)hoverAgent=h;cv.style.cursor=h?"pointer":"default";});
cv.addEventListener("mouseleave",()=>{if(hoverRaw)hoverUntil=performance.now()+500;hoverRaw=null;});
cv.addEventListener("click",ev=>{const hit=hitAt(ev);if(hit){openPanel(hit);beep(740);}});
cv.addEventListener("pointerup",ev=>{if(ev.pointerType!=="mouse"){hoverRaw=null;hoverUntil=0;}}); /* touch has no mouseleave: never leave a hover behind */
function portrait(canvas,id){if(V4.on){portraitV4(canvas,id);return;}const g=canvas.getContext("2d");g.imageSmoothingEnabled=false;g.clearRect(0,0,canvas.width,canvas.height);const big=outlined(mk(BW,BH,gg=>drawBody(gg,id,BX,BY,"down",500,false)));g.drawImage(big,Math.round(canvas.width/2)-BX-1,canvas.height-BY-3);}
/* v4.1 (owner via Nami 20:23): crew status = CREW STATUS rows only (crew.json / CREW STATUS tab). No mood, energy or simulated location; never example rows.
   Per bot: one plain line of what it is doing now, its last real event with a BRT time, and a clear flag when it needs a decision from the owner.
   "Needs your decision" = a non-blank `decision` cell (the question); blank = none. `state` is working/idle/resting; `status` is the "doing now" line. */
const STATE_WORD={working:"Working",idle:"Idle",resting:"Resting",offline:"Offline",break:"On a break",on_break:"On a break",needs_decision:"Waiting for your decision"};
function crewRow(a){const f=FEEDS.crew;if(!f||!f.ok||!f.rows)return null;const r=f.rows.filter(x=>String(x.crew_id||"").trim().toLowerCase()===a.id);return r.length?r[r.length-1]:null;}
function crewDecision(a){const r=crewRow(a);if(!r)return null;return String(r.decision==null?"":r.decision).trim()||null;}
function crewNow(a){const r=crewRow(a);if(!r)return null;const st=String(r.status||"").trim();if(st)return st;return STATE_LABEL[v4State({state:r.state})];}
function v41SameDay(at){try{const f=new Intl.DateTimeFormat("en-CA",{timeZone:CONFIG.tz,year:"numeric",month:"2-digit",day:"2-digit"});return f.format(asDate(at))===f.format(new Date());}catch(e){return false;}} // today -> time only
function crewLast(a){const r=crewRow(a);if(!r)return null;const ty=String(r.event_type||"").trim(),tx=String(r.event_text||"").trim();if(!ty&&!tx)return null;
  const E=EVENTS[ty],lbl=(E?E.label.replace(/^[^A-Za-z0-9]+/,"").trim():ty.replace(/_/g," ")).replace(/[.!]+$/,""),at=r.event_at||r.updated_at,tm=okDate(at)?fmtTime(at,!v41SameDay(at)):"time unknown";
  return {text:(lbl?lbl.charAt(0).toUpperCase()+lbl.slice(1):"")+(tx?(lbl?": ":"")+tx:""),time:tm};}
function openPanel(a){panelAgent=a;const live=!!(FEEDS.crew&&FEEDS.crew.ok&&FEEDS.crew.rows&&FEEDS.crew.rows.length);
  $("pName").textContent=a.name;$("pRole").textContent=a.role;
  const now=crewNow(a),last=crewLast(a),dec=crewDecision(a);
  $("pDoing").textContent=now||(live?"No status yet":"Live crew status unavailable");
  $("pEvent").textContent=last?last.text+" · "+last.time:(live?"No events yet":"–");
  $("pDecRow").hidden=!dec;$("pDec").textContent=dec||"";
  portrait($("portrait"),a.id);$("panel").classList.add("show");}
/* v3.1.2 C3: "guarding the treasure vault" -> "heading to the treasure vault" (use the place, not the activity) */
function headingTo(l){const i=l.lastIndexOf(" the ");return i>=0?"heading to the "+l.slice(i+5):"on the way ("+l+")";}
function updatePanelNow(){} // v4.1: no simulated "doing now" (the line comes from CREW STATUS)
setInterval(updatePanelNow,500);
const closeP=()=>{$("panel").classList.remove("show");panelAgent=null;hoverRaw=null;hoverAgent=null;hoverUntil=0;cv.style.cursor="default";}; /* v3.1.2 M5: no sticky hover after a tap + close */


function evText(a){const ev=a.event;if(!ev)return "none";return ev.type+" · "+(ev.id&&ev.at?"last "+fmtTime(ev.at,true)+(ev.text?" ("+ev.text+")":""):"none yet");}
$("pClose").onclick=closeP;$("panel").addEventListener("click",e=>{if(e.target.id==="panel")closeP();});document.addEventListener("keydown",e=>{if(e.key==="Escape")closeP();});
function renderRoster(){const ros=$("roster");if(!ros)return;ros.innerHTML="";const live=!!(FEEDS.crew&&FEEDS.crew.ok&&FEEDS.crew.rows&&FEEDS.crew.rows.length);
  const dec=agents.map(a=>({a,q:crewDecision(a)})).filter(x=>x.q),box=$("decisions");
  if(box){box.innerHTML="";box.hidden=!live;
    if(live){box.append(el("h3",{class:"decH"},"NEEDS YOUR DECISION",...(dec.length?[" (",el("span",{class:"num"},String(dec.length)),")"]:[]))); /* v4.3.2 Law #3: tabular digits */
      if(!dec.length)box.append(el("div",{class:"note decNone"},"Nothing is waiting for you."));
      dec.forEach(({a,q})=>{const b=el("button",{type:"button",class:"decItem","data-id":a.id,onclick:()=>openPanel(a)},el("b",{},a.name),el("span",{},q));box.append(b);});}}
  if(!live)ros.append(el("div",{class:"note crewOff"},"Live crew status is unavailable right now, so only names and roles are shown."));
  agents.forEach(a=>{const d=document.createElement("div");d.className="crew";d.dataset.id=a.id;const c=document.createElement("canvas");c.width=30;c.height=40;portrait(c,a.id);
    const tx=document.createElement("div");tx.className="ctx";const q=crewDecision(a),now=crewNow(a),last=crewLast(a);
    const sw=v4State(a);tx.append(el("div",{class:"nm"},a.name,live?el("span",{class:"stw "+sw},el("i",{class:"dot4 "+sw}),STATE_LABEL[sw]):""),el("div",{class:"rl"},a.role));
    if(live){{const nd=(c,t)=>{const d=el("div",{class:c});v41Num(d,t);return d;};tx.append(nd("now",now||"No status yet"),nd("last",last?"Last: "+last.text+" · "+last.time:"Last: no events yet"));} /* v4.3.2 Law #3: digits in tabular .num spans */
      if(q)tx.append(el("div",{class:"dflag"},"NEEDS YOUR DECISION"));}
    if(q)d.classList.add("needs");
    d.append(c,tx);d.onclick=()=>openPanel(a);ros.appendChild(d);});}

