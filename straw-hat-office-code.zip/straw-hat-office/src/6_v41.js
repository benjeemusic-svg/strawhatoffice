/* ================= v4.1 (owner list 19:25): one top card, live dot, Money / Orders / Crew tabs, real-data gating, stage-2 hooks ================= */
const V41={tab:"ship",pop:false,plq:[],plqDone:false};
const PHONE_MQ=window.matchMedia("(max-width:640px)");
/* ---------- top card + Money tab (all from stats = tracker PURCHASES since CONFIG.palletStartDate) ---------- */
v4Hud=function(){const s=stats;if(!s)return;const rate=Math.round(CONFIG.commissionRate*1000)/10,since=fmtDay(CONFIG.palletStartDate).replace(/ \d{4}$/,"");
  /* v4.1 (owner 23:05): no money card on the Ship tab any more (the TOP DEAL chip went with it); the Money tab carries the title */
  const pm=$("pMoney");if(pm)pm.title=V41_TITLE||"";
  v41Gate();v4Strip();};
/* ---------- LIVE dot: tap (or press and hold) shows source + last refresh; replaces the weather / auto-refresh lines ---------- */
function v41Live(){const p=$("dataPill");if(!p)return;const st=p.classList.contains("live")?"live":p.classList.contains("snap")?"snap":"load";
  const t=st==="live"?"LIVE":st==="snap"?"OFFLINE":"…";
  const ml=$("mLive");if(ml){if(ml.className!=="mLive "+st)ml.className="mLive "+st;if($("mLiveTxt").textContent!==t)$("mLiveTxt").textContent=t;}
  const src=st==="live"?"Source: Google Sheets tracker (PURCHASES tab), refreshed every "+CONFIG.refreshMinutes+" min.":st==="snap"?"Source: embedded tracker snapshot ("+fmtTime(SNAPSHOT.takenAt,true)+")":"Connecting to the tracker…";
  if($("liveSrc").textContent!==src)$("liveSrc").textContent=src;}
new MutationObserver(v41Live).observe($("dataPill"),{attributes:true,childList:true,characterData:true,subtree:true});
/* v4.1 (Law B): a home-screen web app has no reload button; refresh the tracker + crew feed in place */
document.addEventListener("click",e=>{const b=e.target.closest("#refreshNow");if(!b)return;b.disabled=true;b.textContent="REFRESHING…";Promise.resolve(refresh(false)).finally(()=>{b.disabled=false;b.textContent="REFRESH NOW";});});
function v41Pop(on){V41.pop=on;$("livePop").hidden=!on;$("mLive").setAttribute("aria-expanded",on?"true":"false");}
(function(){const d=$("mLive");let held=null,longOpen=false;
  d.addEventListener("pointerdown",()=>{longOpen=false;clearTimeout(held);held=setTimeout(()=>{longOpen=true;v41Pop(true);},450);});
  ["pointerup","pointercancel","pointerleave"].forEach(e=>d.addEventListener(e,()=>clearTimeout(held)));
  d.addEventListener("click",e=>{e.stopPropagation();if(longOpen){longOpen=false;return;}v41Pop(!V41.pop);});
  document.addEventListener("click",e=>{if(V41.pop&&!e.target.closest("#livePop,#mLive"))v41Pop(false);});
  document.addEventListener("keydown",e=>{if(e.key==="Escape"&&V41.pop)v41Pop(false);});})();
/* ---------- hide panels that only have example / placeholder data until their real tab has rows ---------- */
const realRows=k=>{const f=FEEDS[k];return !!(f&&f.ok&&f.rows&&f.rows.length);};
function v41Gate(){const crew=realRows("crew");document.body.classList.toggle("crewlive",crew);
  // v4.1: Bounty Board removed (owner 20:31). Brainstorms stay (owner 20:23): the board itself says "No brainstorms yet" when the tab is empty
  /* v4.1 (owner 23:00): one heading line, "CREW STATUS · synced 22:50" (the h2 already says CREW STATUS) */
  {const cf=FEEDS.crew,stale=cf&&/stale/i.test(cf.note||""),tm=cf&&(cf.note||"").match(/(\d{1,2}:\d{2})/);const e=$("crewSrc"),t=crew?"· "+(stale?"stale ":"synced ")+(tm?tm[1]:""):"· offline";e.textContent=t.trim();e.title=crew?(cf.note||""):"";}}
HOOK.data.push(()=>{v41Gate();});
/* ---------- phone tab bar: Ship / Money / Crew (Orders removed by the owner, 22:34) (desktop + landscape keep the side panels) ---------- */
function v41Tab(t,noScroll){V41.tab=t;document.body.dataset.tab=t;document.querySelectorAll("#tabbar button").forEach(b=>{if(b.dataset.tab===t)b.setAttribute("aria-current","page");else b.removeAttribute("aria-current");});
  if(t==="ship")requestAnimationFrame(()=>{fitV4();V4.lastKey=null;});if(!noScroll)window.scrollTo(0,0);}
document.querySelectorAll("#tabbar button").forEach(b=>b.onclick=()=>{beep(600,.04);v41Tab(b.dataset.tab);});
v41Tab("ship",true);
if($("crewStrip"))$("crewStrip").onclick=()=>{if(PHONE_MQ.matches){v41Tab("crew");return;}const r=$("roster"),sec=r&&r.closest("section");if(sec){sec.classList.remove("collapsed");sec.scrollIntoView({behavior:REDUCED?"auto":"smooth",block:"start"});}};
/* the world canvas is not drawn while another phone tab is showing (perf budget); the life sim keeps ticking */
const _drawV4=drawV4;drawV4=function(t,dt){if(PHONE_MQ.matches&&V41.tab!=="ship")return;return _drawV4(t,dt);};
const _fitV4=fitV4;fitV4=function(){if(!$("stageWrap").clientWidth)return;return _fitV4();};
/* ---------- tab icons: hud.png icons + a small pixel ship (no emoji) ---------- */
(function(){const G=["................","........m.......","........ms......","........mss.....","........msss....","........mssss...","........msssss..","........m.......","..wwwwwwwwwwwww.","..woooooooooow..","...woooooooow...","....wwwwwwww....","..~~..~~..~~..~~","................"],C={m:"#4b3226",s:"#f1e2bb",w:"#4b3226",o:"#b98f5f","~":"#4fa7a1"};
  const c=document.createElement("canvas");c.width=16;c.height=16;const g=c.getContext("2d");G.forEach((r,y)=>[...r].forEach((ch,x)=>{if(C[ch]){g.fillStyle=C[ch];g.fillRect(x,y+1,1,1);}}));
  document.documentElement.style.setProperty("--shipIcon",`url(${c.toDataURL()})`);})();
/* ---------- room plaques fainter: the plaque text is baked into ship_<phase>; tone the plaque face down once at load ---------- */
function v41FadePlaques(){const L=V4M.world.layers.ship,P=V4S.plaques||[];Object.values(L).forEach(f=>{const im=V4.img[f];if(!im||im._faded)return;
  const c=document.createElement("canvas");c.width=im.width;c.height=im.height;const g=c.getContext("2d",{willReadFrequently:true});g.drawImage(im,0,0);
  P.forEach(p=>{const x0=Math.max(0,p.x-34),y0=Math.max(0,p.y-9),w=68,h=18,d=g.getImageData(x0,y0,w,h),D=d.data;let mx=0;const lum=i=>.3*D[i]+.59*D[i+1]+.11*D[i+2];
    for(let i=0;i<D.length;i+=4)mx=Math.max(mx,lum(i));const th=mx*.78;let a=w,b=h,e=-1,f2=-1;
    for(let y=0;y<h;y++)for(let x=0;x<w;x++){if(lum((y*w+x)*4)>=th){a=Math.min(a,x);b=Math.min(b,y);e=Math.max(e,x);f2=Math.max(f2,y);}}
    if(e<0)return;g.fillStyle="rgba(58,40,30,.5)";g.fillRect(x0+a,y0+b,e-a+1,f2-b+1);if(!V41.plqDone)V41.plq.push({name:p.name||p.text||"",x:x0+a,y:y0+b,w:e-a+1,h:f2-b+1});});V41.plqDone=V41.plqDone||V41.plq.length>0;
  c._faded=true;V4.img[f]=c;});V4.lastKey=null;}
/* v4.3 (owner 23:19): the room plaques are painted out of ship_<phase>.png (tools/strip_plaques.py); no runtime toning, V41.plq stays empty */
/* ---------- stage-2 hooks (owner list: "make sure the hooks exist"; nothing is animated for them yet) ----------
   STAGE2.purchase(delta,stats)  new tracker purchase   -> Zoro carries a crate to the hold
   STAGE2.deal(agent,opts)       real Chopper deal      -> crow's nest bell
   STAGE2.summary(lines)         Friday summary meeting -> deck celebration
   STAGE2.crewTap(agent,report)  crew tapped            -> one-line latest real report (SUMMARIES / CREW STATUS) */
const STAGE2={purchase:[],deal:[],summary:[],crewTap:[],fire(k,...a){(this[k]||[]).forEach(f=>{try{f(...a);}catch(e){console.warn(e);}});}};
const _celebrate=celebrate;celebrate=function(n){_celebrate(n);STAGE2.fire("purchase",n,stats);};
const _playEvent=playEvent;playEvent=function(a,type,opts={}){const r=_playEvent(a,type,opts);if(type==="deal_found"&&!opts.preview)STAGE2.fire("deal",a,opts);return r;};
const _startMeeting=startMeeting;startMeeting=function(kind){const ok=_startMeeting(kind);if(ok!==false&&MEETING.active&&kind==="summary")STAGE2.fire("summary",MEETING.lines);return ok;};
function latestReport(a){const L=crewLast(a);if(L)return {text:L.text,at:L.time,src:"CREW STATUS"};const n=crewNow(a);if(n)return {text:n,at:null,src:"CREW STATUS"};
  const s=typeof latestSummary==="function"?latestSummary():null;if(s&&a.id==="luffy")return {text:(String(s.text).match(/^[\s\S]*?[.!?](?=\s|$)/)||[String(s.text)])[0],at:s.date,src:"SUMMARIES"};return null;}
const _openPanel=openPanel;openPanel=function(a){_openPanel(a);STAGE2.fire("crewTap",a,latestReport(a));};

/* ---------- V4-5: a speech bubble never covers a banner (meal/meeting), a room sign or the area above the stage ----------
   The one visible bubble is measured only when its position/text/banners change; candidates: above the head, shifted left/right,
   then flipped below the feet (also shifted). If none is clear the bubble is hidden rather than drawn over a sign. */
function v41Rects(){const cv=$("world4"),st=$("stage");if(!cv||!st)return null;const c=cv.getBoundingClientRect(),k=c.width/402;
  const out=V41.plq.map(p=>({l:c.left+p.x*k-2,t:c.top+p.y*k-2,r:c.left+(p.x+p.w)*k+2,b:c.top+(p.y+p.h)*k+2,why:"sign"}));
  document.querySelectorAll("#stage .banner").forEach(b=>{const r=b.getBoundingClientRect();if(r.width)out.push({l:r.left-4,t:r.top-4,r:r.right+4,b:r.bottom+4,why:"banner"});});
  return {obs:out,c,k,s:st.getBoundingClientRect()};}
const hit=(a,b)=>a.l<b.r&&a.r>b.l&&a.t<b.b&&a.b>b.t;
function v41Avoid(t){const on=agents.filter(a=>a.el&&a.el.classList.contains("talk"));
  agents.forEach(a=>{if(!on.includes(a)&&(a._bx||a._dy||a._bh2)){a._bx=a._dy=0;a._bh2=false;a._avK=null;a._bub.style.removeProperty("--bx");a._bub.style.removeProperty("--dy");a.el.classList.remove("dn","bhide","dock");}});
  if(!on.length)return;const bk=[...document.querySelectorAll("#stage .banner")].map(b=>b.textContent+b.style.top).join("|");
  on.forEach(a=>{const key=[a._L,a._T,a._st,bk,V41.plq.length].join("~");if(a._avK===key&&t-(a._onAt||0)>400)return;
    if(a._avK&&t-(a._avAt||0)<120&&a._avK.split("~")[2]===String(a._st)&&a._avK.split("~")[3]===bk)return; // walking: re-check at most ~8x/s
    a._avK=key;a._avAt=t;const R=v41Rects();if(!R)return;
    const b=a._bub.getBoundingClientRect();if(!b.width)return;const base={l:b.left-(a._bx||0),r:b.right-(a._bx||0),t:b.top-(a._dy||0),b:b.bottom-(a._dy||0)};
    const feet=(LOOKS[a.id].ht+3)*R.k,down=base.b-base.t+feet+16;
    const cands=[[0,0],[-40,0],[40,0],[-80,0],[80,0],[0,down],[-40,down],[40,down],[-80,down],[80,down]];let pick=null;
    for(const [dx,dy] of cands){const r={l:base.l+dx,r:base.r+dx,t:base.t+dy,b:base.b+dy};
      if(r.l<R.s.left+1||r.r>R.s.right-1||r.t<R.c.top+1||r.b>R.c.bottom-1)continue;if(R.obs.some(o=>hit(r,o)))continue;pick=[dx,dy];break;}
    let dock=false,hide=false;
    if(!pick){const W=base.r-base.l,H=base.b-base.t,dx=Math.round(R.c.left+R.c.width/2-(base.l+W/2)),dy=Math.round(R.c.bottom-8-base.b);const r={l:base.l+dx,r:base.r+dx,t:base.t+dy,b:base.b+dy};
      if(!R.obs.some(o=>hit(r,o))){pick=[dx,dy];dock=true;}else{pick=[0,0];hide=true;}} // last resort: dock it as a caption on the keel, below every room sign
    if(pick[0]!==(a._bx||0)){a._bx=pick[0];a._bub.style.setProperty("--bx",pick[0]+"px");}
    if(pick[1]!==(a._dy||0)){a._dy=pick[1];a._bub.style.setProperty("--dy",Math.round(pick[1])+"px");}
    a.el.classList.toggle("dn",pick[1]>0&&!dock);a.el.classList.toggle("dock",dock);a.el.classList.toggle("bhide",hide);a._bh2=hide||dock;});}
const _updateBubbles=updateBubbles;updateBubbles=function(t,ox,oy){_updateBubbles(t,ox,oy);if(V4.on){try{v41Avoid(t);}catch(e){console.warn(e);}}};

/* v4.1 (owner 20:23): the tap/hover bubble shows the real CREW STATUS line (or the role), never an example status */
const _bubbleText=bubbleText;bubbleText=function(a,t){if(a.anim||(a.say&&t<a.say.until))return _bubbleText(a,t);const q=crewDecision(a);if(q||ringing(a))return "Needs your decision: "+(q||a.decision||"");const r=crewRow(a),at=r&&asDate(r.updated_at||r.event_at);if(r&&at&&Date.now()-at.getTime()>24*3600e3)return STATE_LABEL[v4State(a)]; /* Law D.4 #6: a status older than 24 h is not shown in a bubble */
  /* owner via Nami 21:56: the work text is this bot's own CREW STATUS `status` only; blank -> just its state word (from its own `state`), never a role or another bot's text */
  return crewNow(a);};
/* v4.1 (owner 23:00): the top card (deal chip) and the crew strip change height after data arrives; refit so the strip stays above the tab bar */
if(window.ResizeObserver){let _rh={};const ro=new ResizeObserver(es=>{let ch=false;es.forEach(e=>{const h=Math.round(e.contentRect.height);if(_rh[e.target.id]!==h){_rh[e.target.id]=h;ch=true;}});if(ch&&V4.on)requestAnimationFrame(()=>{fitV4();V4.lastKey=null;});});["crewStrip"].forEach(i=>$(i)&&ro.observe($(i)));}
