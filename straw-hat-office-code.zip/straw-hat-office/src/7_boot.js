/* ================= BOOT ================= */
document.title="Pixel Office · "+STATUS.guild;
renderLog(); renderRoster(); fit(); schedule();
if(document.fonts&&document.fonts.ready)document.fonts.ready.then(fit);
checkNewEvents();
HOOK.boot.forEach(f=>{try{f();}catch(e){console.warn(e);}});
refresh(true); setInterval(()=>refresh(false),CONFIG.refreshMinutes*60*1000);
</script>
</body>
</html>
