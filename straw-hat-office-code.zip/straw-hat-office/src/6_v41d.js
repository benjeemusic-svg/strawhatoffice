/* ===== v4.1 depth + footprints (owner iPhone bug 20:27) =====
   1) Crew and furniture are drawn in ONE pass sorted by the feet line. Crew key = a.y (sprite anchor [16,47], so feet = sprite top + 47);
      a furniture piece's key is its baseline y (the floor line of its front edge). Lower on screen = drawn later = in front.
   2) Furniture footprints (V41_FOOT) are blocked: walk legs that would cross one are re-routed with a small grid A* inside the room floor,
      and graph nodes / spots that sat inside a footprint are moved to the nearest free floor point.
   Art is only read: pieces are cut at runtime from the existing ship / front / glow layers. */
const V41_FOOT=[ // [x0,y0,x1,y1) world px, feet may not enter
  ["helm wheel",72,196,95,223],["helm desk",117,218,182,231],["chart table",231,218,317,231],["chart-room plant",322,203,340,218],
  ["galley stove",62,257,106,295],["galley counter",145,270,197,306],
  ["library chair",250,262,302,290],["library armrest L",250,288,261,304],["library armrest R",290,288,301,304],["library side table",310,276,333,298],["library book pile",226,292,243,303],
  ["sickbay bed",62,346,99,392],["sickbay desk",139,362,196,392],["QA desk",216,343,271,392],["QA clipboard stand",280,368,295,390],
  ["lounge sofa",91,437,159,481],["lounge coffee table",251,462,294,481],
  ["workbench",125,532,192,568],["cargo crates",213,528,257,562],["cargo crate stack",305,512,336,554],
  ["tree",147,94,155,107],["tree",254,94,262,107],["tree",106,134,114,147],["tree",292,134,300,147],
  // Law's v4 review A.3 solid rects (inclusive, ±3 px) so his t50_depth "feet inside solid" check agrees with ours
  ["helm wheel (Law)",70,182,99,221],["galley stove (Law)",64,262,105,293],["galley counter (Law)",146,272,197,305],["library sofa (Law)",256,262,297,295],
  ["library side table (Law)",312,275,331,295],["sickbay bed (Law)",64,347,97,390],["QA desk (Law)",218,360,269,390],["lounge sofa (Law)",92,450,158,483],
  ["lounge table (Law)",252,464,293,481],["workbench (Law)",126,535,190,563],["cargo crates (Law)",213,530,255,562],["cargo crate stack (Law)",306,512,334,551],
  ["helm desk (Law)",118,205,180,229],["chart table (Law)",232,205,316,229],
  // Law review A.4 side clearance: a sprite is 18 px wide, so feet keep 9 px off the side of a front-layer piece while they are inside its depth band
  // (otherwise the desk edge or armrest slices the sprite). Behind-the-desk rows (y<203) stay open for the stations.
  ["helm desk side L (clear)",109,203,118,229],["helm desk side R (clear)",180,203,189,229],["chart table side L (clear)",223,203,232,229],["chart table side R (clear)",316,203,325,229],
  ["library post L (clear)",243,280,268,302],["library post R (clear)",283,280,308,302]]; // desk tops start 2 px in: the stations stand right behind them
/* ship-layer furniture that must cover crew walking behind it: rects cut from ship_<phase>; base = baseline (feet y) of its front edge */
const V41_SHIP_PROPS=[
  {id:"sickbay desk + screen",base:392,rects:[[140,363,195,392],[149,341,188,364]]},
  {id:"galley counter",base:306,rects:[[146,270,196,306]]},
  {id:"workbench",base:568,rects:[[126,532,191,568]]}];
function v41InFoot(x,y,m){m=m||0;for(const f of V41_FOOT)if(x>=f[1]-m&&x<f[3]+m&&y>=f[2]-m&&y<f[4]+m)return f;return null;}
function v41Floor(x,y){for(const [k,r] of Object.entries(V4S.rooms)){const f=r.floor;if(!f)continue;if(x>=f.x-3&&x<f.x+f.w+3&&y>=f.y-3&&y<f.y+f.h+3)return k;}return null;}
let V41_PASS=null; // doorway / mid-wall gaps: a small box around every graph node that is outside all room floors
function v41Pass(x,y){if(!V41_PASS)V41_PASS=Object.entries(V4N).filter(([n,q])=>!V41_CLIMB.has(n)&&!v41Floor(q.x,q.y)).map(([n,q])=>[q.x-8,q.y-14,q.x+8,q.y+14]);
  for(const b of V41_PASS)if(x>=b[0]&&x<=b[2]&&y>=b[1]&&y<=b[3])return true;return false;}
function v41Free(x,y){return (!!v41Floor(x,y)||v41Pass(x,y))&&!v41InFoot(x,y,1);}
function v41SegBlocked(p,q){const n=Math.max(1,Math.ceil(Math.hypot(q.x-p.x,q.y-p.y)));for(let i=1;i<n;i++){const t=i/n;if(v41InFoot(p.x+(q.x-p.x)*t,p.y+(q.y-p.y)*t))return true;}return false;}
function v41SegFree(p,q){const n=Math.max(1,Math.ceil(Math.hypot(q.x-p.x,q.y-p.y)));for(let i=0;i<=n;i++){const t=i/n,x=p.x+(q.x-p.x)*t,y=p.y+(q.y-p.y)*t;if(!v41Free(x,y))return false;}return true;}
/* grid A* (2 px) between two free points of the same deck area; returns the inner way-points (line-of-sight smoothed) or null */
const V41_ASTAR={};
function v41AStar(p,q){const key=[p.x,p.y,q.x,q.y].map(Math.round).join(",");if(key in V41_ASTAR)return V41_ASTAR[key];
  const G=2,x0=Math.min(p.x,q.x)-60,y0=Math.min(p.y,q.y)-60,W=Math.ceil((Math.max(p.x,q.x)+60-x0)/G),H=Math.ceil((Math.max(p.y,q.y)+60-y0)/G);
  const id=(i,j)=>j*W+i,cx=i=>x0+i*G,cy=j=>y0+j*G,si=Math.round((p.x-x0)/G),sj=Math.round((p.y-y0)/G),ti=Math.round((q.x-x0)/G),tj=Math.round((q.y-y0)/G);
  const ok=(i,j)=>i>=0&&j>=0&&i<W&&j<H&&((i===si&&j===sj)||(i===ti&&j===tj)||v41Free(cx(i),cy(j)));
  const gS=new Map([[id(si,sj),0]]),prev=new Map(),open=[[Math.hypot(ti-si,tj-sj),si,sj]],done=new Set();let found=false;
  while(open.length){let b=0;for(let k=1;k<open.length;k++)if(open[k][0]<open[b][0])b=k;const [,i,j]=open.splice(b,1)[0],u=id(i,j);if(done.has(u))continue;done.add(u);
    if(i===ti&&j===tj){found=true;break;}
    for(const [di,dj] of [[1,0],[-1,0],[0,1],[0,-1],[1,1],[1,-1],[-1,1],[-1,-1]]){const ni=i+di,nj=j+dj;if(!ok(ni,nj))continue;if(di&&dj&&(!ok(i+di,j)||!ok(i,j+dj)))continue;
      const v=id(ni,nj),gv=gS.get(u)+Math.hypot(di,dj);if(gv<(gS.has(v)?gS.get(v):1e9)){gS.set(v,gv);prev.set(v,u);open.push([gv+Math.hypot(ti-ni,tj-nj),ni,nj]);}}}
  if(!found)return V41_ASTAR[key]=null;
  const cells=[];for(let u=id(ti,tj);u!==undefined;u=prev.get(u))cells.unshift({x:cx(u%W),y:cy(Math.floor(u/W))});
  cells[0]={x:p.x,y:p.y};cells[cells.length-1]={x:q.x,y:q.y};
  const out=[];let a=0;while(a<cells.length-1){let b=cells.length-1;while(b>a+1&&!v41SegFree(cells[a],cells[b]))b--;if(b<cells.length-1)out.push(cells[b]);a=b;}
  return V41_ASTAR[key]=out;}
/* make a path footprint-safe: each walk leg that crosses furniture gets A* detour points */
function v41FixPath(start,pts){const out=[];let prev={x:start.x,y:start.y};
  for(const p of pts){if((!p.via||p.via==="walk")&&v41SegBlocked(prev,p)){const d=v41AStar(prev,p);if(d)d.forEach(w=>out.push({x:w.x,y:w.y,via:"walk"}));}out.push(p);prev=p;}
  // string-pull: skip way-points while a straight walk stays on free floor (no zig-zags through hub nodes); door / climb legs are kept
  const all=[{x:start.x,y:start.y}].concat(out),res=[];let i=0;
  while(i<all.length-1){let j=i+1;for(let k=all.length-1;k>i+1;k--){let ok=true;for(let m=i+1;m<=k;m++)if(all[m].via&&all[m].via!=="walk"){ok=false;break;}if(ok&&v41SegFree(all[i],all[k])){j=k;break;}}
    res.push(all[j]);i=j;}
  return res;}
/* for Law's harness / QA: glow pieces that are drawn AFTER (over) this sprite and overlap it. Wall glow (aquariums, lamps) is drawn under the crew. */
function v41GlowOver(a){const P=V41D[V4.phase||"day"];if(!P)return [];const h=(V4M.characters[a.id]||{}).height||44,x=Math.round(a.x),y=Math.round(a.y);
  return P.items.filter(p=>p.glow&&p.base>y&&p.x<x+9&&p.x1>x-9&&p.y<y&&p.y1>y-h).map(p=>[p.x,p.y,p.x1,p.y1]);}
/* move nodes / spots that sit inside a footprint to the nearest free floor point (same room) */
function v41Nudge(o){if(!v41InFoot(o.x,o.y,1))return false;const room=v41Floor(o.x,o.y);let best=null,bd=1e9;
  for(let dy=-40;dy<=40;dy++)for(let dx=-40;dx<=40;dx++){const x=o.x+dx,y=o.y+dy,d=dx*dx+dy*dy;if(d<bd&&v41Floor(x,y)===room&&!v41InFoot(x,y,2)){bd=d;best=[x,y];}}
  if(best){o.x=best[0];o.y=best[1];return true;}return false;}
/* Jinbe and Nami stand right behind their desks (spots.json behindFront): feet on the floor line just behind the desk top, not on the desk */
[["jinbe",204],["nami",204]].forEach(([id,y])=>{const s=V4ST[id];if(!s)return;s.y=y;if(V4N["st_"+id])V4N["st_"+id].y=y;const sp=SPOTS["st_"+id];if(sp)sp.y=y;
  Object.values(SPOTS).forEach(o=>{if(o.station===id)o.y=y;});const a=agents.find(q=>q.id===id);if(a&&a.at===a.home)a.y=y;});
const V41_CLIMB=new Set();V4S.edges.forEach(([a,b,via])=>{if(via==="climb"){V41_CLIMB.add(a);V41_CLIMB.add(b);}});
/* door1L_out sat 1 px beside the helm desk (sprite edge under the desk top): moved 3 px right, still on the stair head */
if(V4N.door1L_out&&V4N.door1L_out.x<190)V4N.door1L_out.x=190;
const V41_MOVED=[];
Object.entries(V4N).forEach(([n,q])=>{if(V41_CLIMB.has(n)||n.startsWith("st_"))return;const o=[q.x,q.y];if(v41Nudge(q))V41_MOVED.push("node "+n+" "+o+" -> "+q.x+","+q.y);});
Object.entries(SPOTS).forEach(([k,s])=>{if(s.station)return;const o=[s.x,s.y];if(v41Nudge(s))V41_MOVED.push("spot "+k+" "+o+" -> "+s.x+","+s.y);s.node=v4NearestNode(s);});
Object.entries(V4SPOT).forEach(([k,v])=>{if(v&&SPOTS[k]){v[0]=SPOTS[k].x;v[1]=SPOTS[k].y;}});
const _routeTo41=routeTo;routeTo=function(a,spot){_routeTo41(a,spot);if(a.path&&a.path.length)a.path=v41FixPath(a,a.path);};
/* ---------- depth pieces, cut once per phase ---------- */
const V41D={};
function v41Pieces(ph){if(V41D[ph])return V41D[ph];const L=V4M.world.layers,bg=[],items=[];
  const cut=(im,rects)=>{const x0=Math.min(...rects.map(r=>r[0])),y0=Math.min(...rects.map(r=>r[1])),x1=Math.max(...rects.map(r=>r[2])),y1=Math.max(...rects.map(r=>r[3]));
    const c=document.createElement("canvas");c.width=x1-x0;c.height=y1-y0;const g=c.getContext("2d");rects.forEach(r=>g.drawImage(im,r[0],r[1],r[2]-r[0],r[3]-r[1],r[0]-x0,r[1]-y0,r[2]-r[0],r[3]-r[1]));return {c,x:x0,y:y0,x1,y1};};
  const props=V41_SHIP_PROPS.map(p=>Object.assign(cut(V4.img[L.ship[ph]],p.rects),{base:p.base,id:p.id}));props.forEach(p=>items.push(p));
  // split an overlay layer into connected opaque pieces (8-neighbour flood fill on alpha)
  const split=(im)=>{if(!im)return [];const c=document.createElement("canvas");c.width=WW;c.height=WH;const g=c.getContext("2d");g.drawImage(im,0,0);
    let d;try{d=g.getImageData(0,0,WW,WH).data;}catch(e){return [{c:im,x:0,y:0,x1:WW,y1:WH,whole:true}];}
    const seen=new Uint8Array(WW*WH),out=[];
    for(let s=0;s<WW*WH;s++){if(seen[s]||!d[s*4+3])continue;let x0=WW,y0=WH,x1=0,y1=0;const st=[s];seen[s]=1;
      while(st.length){const u=st.pop(),x=u%WW,y=(u-x)/WW;if(x<x0)x0=x;if(x>x1)x1=x;if(y<y0)y0=y;if(y>y1)y1=y;
        for(let dy=-1;dy<=1;dy++)for(let dx=-1;dx<=1;dx++){const nx=x+dx,ny=y+dy;if(nx<0||ny<0||nx>=WW||ny>=WH)continue;const v=ny*WW+nx;if(!seen[v]&&d[v*4+3]){seen[v]=1;st.push(v);}}}
      out.push(cut(c,[[x0,y0,x1+1,y1+1]]));}
    return out;};
  // front layer (desk tops, chart table edge, armrests): baseline = one row under the piece
  split(V4.img[L.front[ph]]).forEach(p=>{p.base=p.whole?232:p.y1+1;items.push(p);});
  // glow layer (lamps, aquarium light, screen light): pieces on a ship prop share its baseline; wall pieces go behind everyone
  if(L.glow[ph])split(V4.img[L.glow[ph]]).forEach(p=>{p.glow=true;const pr=props.find(q=>p.x<q.x1&&p.x1>q.x&&p.y<q.y1&&p.y1>q.y);if(pr){p.base=pr.base;items.push(p);}else bg.push(p);});
  return V41D[ph]={bg,items};}
function v41DepthPass(g,ph,crew,drawC,under,extra){const P=v41Pieces(ph);
  P.bg.forEach(p=>{g.drawImage(p.c,p.x,p.y);V4.drawCalls++;});
  if(under)under(); // v4.3: ambient wall/floor details (aquarium fish, resting butterflies) sit above the wall glow, below every sprite
  const list=P.items.map(p=>({k:p.base,o:0,p})).concat(crew.map(c=>({k:c.y,o:1,c})),(extra||[]).map(x=>({k:x.k,o:0,x})));
  list.sort((u,v)=>u.k-v.k||u.o-v.o); // same line: furniture first, crew in front
  list.forEach(e=>{if(e.x){e.x.draw();return;}if(e.p){g.drawImage(e.p.c,e.p.x,e.p.y);V4.drawCalls++;return;}
    // A11: a sprite never pokes into the room above; its room's top wall line is the ceiling (doorways: the head goes behind the lintel)
    const rm=V4S.rooms[v4Room({x:e.c.x,y:e.c.y})];if(rm&&rm.floor&&v432Clips(e.c)){g.save();g.beginPath();g.rect(0,rm.y,WW,WH-rm.y);g.clip();drawC(e.c);g.restore();}else drawC(e.c);});}
/* compatibility for Law's v4 harness (t50_depth.py reads v4InFront): true when the sprite is drawn after every front piece it overlaps */
function v4InFront(a){const P=V41D[V4.phase||"day"];if(!P)return false;const h=(V4M.characters[a.id]||{}).height||44,x=Math.round(a.x),y=Math.round(a.y);
  return P.items.filter(p=>!p.glow&&p.x<x+9&&p.x1>x-9&&p.y<y&&p.y1>y-h).every(p=>y>=p.base);}
/* ===== v4.1 (owner via Law 20:53): subtle eye blink on the crew faces =====
   Each face blinks every 2.5–7 s on its own random timer (140 ms closed). The top eye pixel is painted with the skin next to it, so the eye
   reads as a closed line. Frankie (sunglasses) and Brook (skull) have no visible eyes, so they don't blink. Nothing else animates on a face.
   Off with reduced motion and while the tab is hidden. Eye pixels are measured on portraits24.png (x,y inside the 24x24 portrait). */
const V41_EYES={luffy:[[7,17],[15,17]],zoro:[[7,11],[15,11]],nami:[[7,11],[15,11]],usopp:[[7,14],[15,14]],sanji:[[15,11]],chopper:[[7,14],[15,14]],
  robin:[[7,11],[15,11]],jinbe:[[6,15],[16,15]],law:[[7,17],[15,17]]};
function v41Blink(g,id){const E=V41_EYES[id];if(!E)return;try{E.forEach(([x,y])=>{const X=x+2,Y=y+2,n=g.getImageData(X+1,Y,1,1).data,m=g.getImageData(X-1,Y,1,1).data;
  const lum=d=>d[0]*.3+d[1]*.59+d[2]*.11,s=lum(n)>=lum(m)?n:m;g.fillStyle=`rgb(${s[0]},${s[1]},${s[2]})`;g.fillRect(X,Y,1,1);});}catch(e){}}
const V41_BLINK=new WeakMap();
setInterval(()=>{if(REDUCED||document.hidden||!V4.ready)return;const now=performance.now();
  document.querySelectorAll("canvas.pt4").forEach(c=>{const id=c.dataset.pid;if(!V41_EYES[id]||!c.getClientRects().length)return;let s=V41_BLINK.get(c);
    if(!s){s={next:now+2500+Math.random()*4500,shut:0};V41_BLINK.set(c,s);return;}
    if(s.shut&&now>=s.shut){s.shut=0;portraitV4(c,id);s.next=now+2500+Math.random()*4500;}
    else if(!s.shut&&now>=s.next){portraitV4(c,id,"blink");s.shut=now+140;}});},70);
