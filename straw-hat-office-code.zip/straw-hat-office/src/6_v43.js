/* ================= v4.3 (owner 23:48): Crew tab = crew status + the BRAINSTORMS view ================= */
/* The brainstorm board (openBrainstorms) renders inline in #brainArea instead of a modal; the ship's idea board still opens the modal. */
function v43Brain(){const host=$("brainArea");if(!host||typeof openBrainstorms!=="function")return;const om=openModal;
  openModal=function(title,content){host.innerHTML="";if(typeof content==="string")host.innerHTML=content;else host.appendChild(content);return host;};
  try{openBrainstorms();}catch(e){console.warn(e);}finally{openModal=om;}}
{let sig="";const re=()=>{let s="";try{s=JSON.stringify(brainSessions().map(x=>[x.session_id,x.lines.length]));}catch(e){}if(s!==sig||!$("brainArea").childNodes.length){sig=s;v43Brain();}};
 HOOK.data.push(re);const _t=v41Tab;v41Tab=function(t,n){_t(t,n);if(t==="crew")re();};
 document.querySelectorAll("#tabbar button").forEach(b=>b.onclick=()=>{beep(600,.04);v41Tab(b.dataset.tab);});re();}
/* ================= v4.3 (Law S8, 23:17): no flat-cut heads just inside a doorway =================
   A11 clips a sprite at its room's top wall line, so a bot that walks sideways right after coming through a door (e.g. Nami at
   226,262 in the library) lost the top of her head. Coming out of a door the bot now steps straight down until its whole sprite
   fits under the wall line, then turns; walking to a door it lines up below the door first. The head is only hidden while the
   bot is inside the door column (behind the lintel), never out in the room. */
const V43_H=Math.max(...Object.values(V4M.characters).map(c=>c.height||44));
const V43_DX=[...new Set(Object.entries(V4N).filter(([n])=>/^door\d[LR]_(in|out)$/.test(n)).map(([,q])=>q.x))]; // door columns after v4.1 nudges (door2R_in sits at 213)
function v43Knees(a,P){if(!P||!P.length)return P;const out=[];let prev={x:Math.round(a.x),y:Math.round(a.y)};
  const high=p=>{const r=V4S.rooms[v4Room(p)];return (r&&r.floor&&p.y-r.y<V43_H+1&&V43_DX.some(x=>Math.abs(x-p.x)<=1))?r:null;};
  const knee=(d,r,q)=>{const k={x:d.x,y:Math.min(r.floor.y+r.floor.h-3,r.y+V43_H+1),via:"walk"};
    return (k.y>d.y&&v4Room(k)===v4Room(d)&&!v41InFoot(k.x,k.y,1)&&v41SegFree(d,k)&&v41SegFree(k,q))?k:null;};
  const walk=p=>!p.via||p.via==="walk";
  P.forEach((p,i)=>{let r;
    if(walk(p)&&(r=high(prev))&&Math.abs(p.x-prev.x)>3&&v4Room(p)===v4Room(prev)){const k=knee(prev,r,p);if(k)out.push(k);}            // leaving a door sideways
    const nx=P[i+1];
    if(walk(p)&&(r=high(p))&&Math.abs(p.x-prev.x)>3&&v4Room(p)===v4Room(prev)&&nx&&!walk(nx)){const k=knee(p,r,prev);if(k)out.push(k);} // walking to a door
    out.push(p);prev=p;});
  return out;}
{const _rt=routeTo;routeTo=function(a,spot){_rt(a,spot);try{if(a.path&&a.path.length)a.path=v43Knees(a,a.path);}catch(e){console.warn(e);}};}
