import base64,glob,os,json,re
os.chdir(os.path.dirname(os.path.abspath(__file__)))
parts=sorted(glob.glob('src/[0-9]_*'))
parts=[p for p in parts if not p.endswith('.whl')]
t=''.join(open(p).read() for p in parts)
b64=lambda p: base64.b64encode(open(p,'rb').read()).decode()
# ---- v4 art pack (copied from /workspace/pixel-office-art, see art/v4/CREDITS-art.md) ----
def local(p):
    for a,b in (('ambient/v4.2/','ambient/'),('sprites/v4/chars/','chars/'),('sprites/v4/',''),('world/v4/','world/'),('ui/v4/css/','ui/css/'),('ui/v4/','ui/')):
        if p.startswith(a): return 'art/v4/'+b+p[len(a):]
    raise SystemExit('unmapped art path '+p)
uri=lambda p:'data:image/png;base64,'+b64(local(p))
m=json.load(open('art/v4/manifest-v4.json'))
files={m['uiFile'],m['emotesFile'],m['water']['file'],m['shadows']['file'],m['portraits']['file24'],m['portraits']['file16']}
files|={c['file'] for c in m['characters'].values()}
for L in m['world']['layers'].values(): files|=set(L.values())
keep={k:m[k] for k in ('version','palette','characters','portraits','world','water','shadows','uiFile','ui','icons','iconsFile','emotes','emotesFile')}
for c in keep['characters'].values(): c.pop('rows',None)
# v4.3 ambient pack (pixel-office-art ambient-v4.2.json, AMBIENT-v4.2.md): sheets + sprite table + placements + motion
amb=json.load(open('art/v4/ambient/ambient-v4.2.json'))
files|={s['file'] for s in amb['sheets'].values()}
amb={k:amb[k] for k in ('sheets','sprites','placements','motion')}
for s in amb['sprites'].values(): s.pop('note',None)
pack={'m':keep,'spots':json.load(open('art/v4/world/spots.json')),'amb':amb,'files':{f:uri(f) for f in sorted(files)}}
t=t.replace('__V4PACK__',json.dumps(pack,separators=(',',':')))
t=re.sub(r'\{\{V4IMG:([^}]+)\}\}',lambda mo:uri(mo.group(1)),t)
t=t.replace('__STATUS__',open('src/status.json').read().strip()).replace('__SNAPSHOT__',open('snapshot.json').read())  # v4.1: no example brainstorms are embedded any more (BRAINSTORMS tab only)
# v4.1 owner MUST: pre-rendered top-card texts from the embedded snapshot (same rules as compute()/renderStats(): pallet lines since
# palletStartDate (undated kept, all lines if none match), 5% commission, US$ at the partner rate 5.14)
def _rt(iso):  # same text as fmtTime(x,true) in BRT: "18 Oct 2026, 13:10 BRT"
  import datetime
  d=datetime.datetime.fromisoformat(iso).astimezone(datetime.timezone(datetime.timedelta(hours=-3)))
  return d.strftime('%d %b %Y, %H:%M')+' BRT'
def _presnap():
  import datetime
  S=json.load(open('snapshot.json')); rows=[r for r in S['rows'] if r and r[0] and len(r)>2 and r[2]]
  start=datetime.date(2026,10,8)
  def pdt(v):
    v=str(v or '').strip()
    for f in ('%Y-%m-%d','%d/%m/%Y','%m/%d/%Y'):
      try: return datetime.datetime.strptime(v[:10],f).date()
      except Exception: pass
    return None
  dated=any(len(r)>4 and pdt(r[4]) for r in rows)
  L=[r for r in rows if not(len(r)>4 and pdt(r[4])) or pdt(r[4])>=start] if dated else rows
  if not L: L=rows
  num=lambda v: float(v) if isinstance(v,(int,float)) else float(str(v).replace(',','') or 0)
  items=sum(num(r[2]) for r in L); spend=sum(num(r[3] or 0) for r in L); stores=len({str(r[0]).strip() for r in L})
  rnd=lambda x:int(x+0.5)
  brl0=lambda n:'R$ '+f"{rnd(n):,}"; brl=lambda n:'R$ '+f"{n:,.2f}"; usd=lambda n:'US$ '+f"{rnd(n):,}"
  ta=datetime.datetime.fromisoformat(S['takenAt']).timestamp()*1000
  t={'bounty':brl(spend*0.05),'bountyUsd':f"≈ {usd(spend*0.05/5.14)}",'mSpend':brl(spend),'mSpendUsd':f"≈ {usd(spend/5.14)}",'mAsOf':'· read '+_rt(S['takenAt'])}
  return json.dumps({'at':ta,'t':t},ensure_ascii=False)
t=t.replace('__PRESNAP__',_presnap())
# v4.1 (Law B): home-screen icon (Luffy portrait from the art pack, 180x180) + a data: manifest, both inline (single-file app)
_ic='data:image/png;base64,'+b64('src/icon180.png')
_mf={'name':'Straw Hat Office','short_name':'Straw Hat','display':'standalone','background_color':'#0b2a4a','theme_color':'#0b2a4a','start_url':'./','icons':[{'src':_ic,'sizes':'180x180','type':'image/png'}]}
import urllib.parse
t=t.replace('__ICON180__',_ic).replace('__MANIFEST__','data:application/manifest+json,'+urllib.parse.quote(json.dumps(_mf,separators=(',',':'))))
t=t.replace('__FONT_PIX__',b64('fonts/pixelify-bold-sub.woff2')).replace('__FONT_VT__',b64('fonts/vt323-sub.woff2'))
left=re.findall(r'__[A-Z0-9_]+__|\{\{V4IMG',t)
if left: raise SystemExit('unreplaced tokens: '+str(sorted(set(left))[:5]))
open('index.html','w').write(t); print('built',len(t.encode()),'bytes from',parts)
